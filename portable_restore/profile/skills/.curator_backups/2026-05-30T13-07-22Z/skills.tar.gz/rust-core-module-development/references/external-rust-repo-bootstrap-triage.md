# External Rust/Python Repo Bootstrap Triage

Use this reference when deploying a cloned or mirrored external AGI/Rust/Python repository that mixes generated Rust modules, Python Web UI, scripts, and model/provider configuration.

## Core lesson

Do not equate any single artifact with deployment:

- Code cloned/pushed is not deployed.
- Web UI running is not full Rust core deployment.
- A generated Rust tree existing is not proof it compiles.
- A runtime harness can be a valid deployable entrypoint only if it is explicitly labeled as a harness and verified with process/port/HTTP evidence.

## Safe sequence

1. **Inventory and safety scan first**
   - Count files, Cargo manifests, Python files, shell scripts.
   - Identify entrypoints: `README.md`, `Cargo.toml`, `requirements.txt`, `web_ui/app.py`, `src/main.rs`, nested crates.
   - Scan for tokens, `curl | bash`, destructive shell actions, and auto-commit/push scripts.
   - Do not run `install.sh` or `setup.sh` until reviewed.

2. **Create a sanitized working copy when push protection detects secrets**
   - Replace real token patterns with placeholders.
   - Re-scan for remaining secret-like values.
   - Commit/push only sanitized content.
   - Do not bypass GitHub Push Protection just to preserve history.

3. **Deploy Python Web UI separately**
   - Create local `.venv`.
   - Install `requirements.txt`.
   - Add missing runtime dependencies only after import/health evidence shows they are needed.
   - Bind local verification server to `127.0.0.1` and disable debug mode.
   - Avoid default port conflicts such as macOS Control Center/AirPlay on 5000; make host/port env-configurable, e.g. `OMEGA_WEB_HOST=127.0.0.1`, `OMEGA_WEB_PORT=5050`.
   - Verify with `curl` to `/`, `/api/health`, `/api/status`, and config/diagnostics endpoints.

4. **Validate Rust in layers**
   - Run `cargo metadata` before `cargo check`.
   - Common structural fixes:
     - Feature includes a dependency: dependency must be `optional = true`.
     - Workspace member has no target: add `[lib]` with correct `path`, or remove from workspace if it is not an independent crate.
     - Source modules outside `src/`: add explicit `#[path = "../module/mod.rs"]` only when the crate truly owns that module tree.
     - Generated syntax errors: fix simple objective errors (`import` → `use`, stray `\\n`, malformed raw strings, malformed `format!`).
   - If a generated full Rust core still has many structural errors, do not keep patching blindly while telling the user it is deployed.

5. **Runtime harness pattern**
   - When the full generated Rust core is not yet buildable but the user needs a real local deployment, create a separate harness crate rather than contaminating the broken root crate.
   - Put it under `runtime_harness/` with its own `[workspace]` table to keep it outside the parent workspace.
   - Implement a minimal Rust HTTP runtime using `axum` or equivalent:
     - `GET /api/health` returns process-backed status, version, uptime, and evidence string.
     - `GET /api/capabilities` lists capabilities and limitations.
     - `POST /api/chat` verifies interaction plumbing, clearly labeled as placeholder unless real LLM/task orchestration is wired.
   - Compile with `cargo build --release` in the harness directory.
   - Start it on a local-only port such as `127.0.0.1:8765`.
   - Verify with `lsof` and `curl`.

6. **Completion language**
   - Acceptable: “Web UI and Rust runtime harness are locally running; full generated Rust core remains uncompiled.”
   - Not acceptable: “AGI is deployed” if only a harness or UI is running.
   - Always provide exact interaction URLs, process/port evidence, health response, and known limitations.

## Minimal harness Cargo.toml

```toml
[package]
name = "omega-runtime-harness"
version = "0.1.0"
edition = "2021"

[[bin]]
name = "omega-runtime"
path = "src/main.rs"

[workspace]

[dependencies]
anyhow = "1.0"
axum = "0.7"
serde = { version = "1.0", features = ["derive"] }
tokio = { version = "1", features = ["macros", "rt-multi-thread", "net"] }
```

## Verification checklist

- [ ] Sanitized copy exists if original history contained secrets.
- [ ] Web UI responds on a local-only port.
- [ ] Rust harness binary exists and is executable.
- [ ] Rust harness process listens on `127.0.0.1`.
- [ ] `/api/health` returns JSON success.
- [ ] `/api/chat` accepts a POST and returns JSON.
- [ ] Report distinguishes harness deployment from full core compilation.
- [ ] Deployment fixes are committed and pushed only after verification.
