# Apple↔Omega bounded cron 与 R031 范围隔离

## 适用场景

当用户要求“继续”“不要让我催”并且 Apple↔Omega 互学链路已经存在时，下一步可以推进为有界持续 tick 或 R031 scope isolation（范围隔离），但不得扩大成无界自演化。

## 有界 cron 接入模式

可采用 Hermes no-agent cron 调用一个小脚本，而不是启动长期 daemon：

- 脚本先检查 Omega runtime health；离线则输出 skipped/blocked，不自动启动服务。
- 单次 tick 只执行：co-evolution report → PGG score gate → idempotent `/api/learn`。
- `deliver='local'` 适合静默证据链；若用户要求每次看结果才用 `origin`。
- cron 成功只证明 tick 脚本执行成功；仍需检查 score、learn record、报告和日志读回。

硬边界：不 git push、不 deploy/install/launcher、不启动无 stop condition daemon、不读写 secret。

## R030 后的 R031 范围隔离步骤

当 R030 modification surface audit 显示工作区混杂历史/非本轮修改时，不要直接提交或继续混合吸收。应先生成 R031 scope isolation manifest：

1. 从真实 `git status --short` 或等价状态收集 changed paths。
2. 分类为 approved_change_set、quarantine_change_set、blocked_change_set。
3. 输出 JSON + Markdown 证据；`commit_allowed` 必须为 false。
4. 同步 runtime wrapper，并补测试覆盖分类逻辑。
5. 跑 `py_compile` 和目标 pytest。
6. 写入 PGG gene DB 并读回验证。
7. 报告中明确：未删除、未暂存、未提交、未推送。

## 关键口径

- scope isolation 是“范围证据”，不是清理完成、提交完成或历史改动归属确认。
- outside allowed roots 可以被隔离记录，但不能被混入 approved set。
- 后续 R032 只能引用 approved set；quarantine/blocked set 需要单独任务或人工授权处理。
