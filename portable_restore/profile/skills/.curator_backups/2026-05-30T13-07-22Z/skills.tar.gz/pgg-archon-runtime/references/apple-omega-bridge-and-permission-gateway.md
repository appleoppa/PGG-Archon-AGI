# Apple Hub ↔ Omega Bridge and Permission Gateway Progression

## Trigger

Use this when Apple Hub ↔ Omega co-evolution reports keep pointing to local state, permissioned execution, receipts, or bridge protocols, especially phrases like:

- `Intent→Plan→Confirm→Execute→Receipt→Evaluate`
- permission gateway / confirmation contract / receipt replay
- `omega_bridge_v0`, `state.json → plan.json → metrics.json`
- schema registry, schema drift, negative replay

## Class-level pattern

Do not keep generating co-evolution reports after the same shortcoming repeats. Convert each repeated gap into a bounded dry-run gene, then verify, persist to Omega `/api/learn`, insert/dedupe in PGG gene DB, read back, and generate a compact confirmation report.

Progression used successfully:

1. **Permissioned intent harness**
   - Generate 10 dry-run `Intent→Plan→Confirm→Execute→Receipt→Evaluate` samples.
   - Require permission minimized, confirmation gate present, no device side effect, receipt schema ready, credential not accessed.

2. **Permission gateway**
   - Add `confirmation_state`, least privilege check, authorization decision hash, failure taxonomy, and gateway blocking when no confirmation exists.

3. **Receipt replay evaluator**
   - Replay existing dry-run receipts and compute aggregate metrics: success rate, blocked rate, least privilege score, confirmation gate score, receipt schema score, no-side-effect score, failure distribution.

4. **Confirmation contract**
   - Upgrade boolean confirmation to auditable fields: `confirmation_id`, `confirmation_scope`, `allowed_action`, `required_permissions`, `expiration_policy`, `replay_nonce`, `contract_hash`, plan/receipt binding.

5. **Omega bridge v0**
   - Create read-only `state → plan → metrics` bridge.
   - State includes goal/context/allowed_actions/blocked_actions/runtime/execution_mode.
   - Plan includes risk/steps/rollback/confirmation requirement/device and credential flags.
   - Metrics verifies state hash binding, allowed actions only, no blocked actions, rollback declared, confirmation required, no device API, no credential access.

6. **Bridge negative replay**
   - Test bad contracts are blocked: overreach action, missing rollback, hash mismatch, no confirmation, credential request, device API request.

7. **Bridge schema registry**
   - Register versioned schemas for `state`, `plan`, `metrics`, and `negative_replay`.
   - Check required fields and stable constraints to catch schema drift before future execution.

## Verification gate

Before reporting a gene as absorbed:

- Run the dry-run script and require all positive samples pass.
- Run negative replay when adding a gate and require all bad cases block.
- Run syntax/build tests available for the repo, e.g. `py_compile` and `cargo test`.
- POST a compact lesson to Omega `/api/learn` using `source`, `lesson`, `evidence_path`, and `genes`.
- Insert or dedupe the PGG gene DB record and read back `id/name/pattern_type/quality_score`.
- Generate a Markdown confirmation report with status, samples, pass/block counts, learn record, gene id, total genes, and boundaries.

## Boundary language

Say:

- `dry-run verified`
- `read-only bridge`
- `no device API, no credential access, no real execution`
- `future real execution requires explicit confirmation and device API binding`

Do not say:

- real Apple devices were controlled
- calendar/reminder/shortcut actions happened
- autonomous AGI execution is complete

## Practical pitfall

Omega `/api/learn` expects the compact payload shape already used by the co-evolution learner: `source`, `lesson`, `evidence_path`, `genes`. If richer JSON causes validation failure, keep the detailed metrics in the evidence file and send only a concise lesson plus evidence path to `/api/learn`.
