# Omega Controlled Absorption R031-R033

## Trigger

Use this reference when the user says “继续/继续进化/不要让我催” after R030 modification surface audit, or when an Omega/PGG Archon absorption chain has mixed worktree changes and needs to keep moving without polluting commit scope.

## Durable learning

R031-R033 convert a blocked/mixed modification surface into a safe continuation lane without deleting or committing anything:

1. R031 — scope isolation manifest（范围隔离清单）
   - Input: current changed path list, usually from git status converted to absolute paths.
   - Output: approved_change_set / quarantine_change_set / blocked_change_set.
   - Rule: status may be `isolated` even when blocked/outside paths exist, because they are isolated rather than acted on.
   - Hard boundary: classification only; no deletion, no staging, no commit, no push.

2. R032 — rollback manifest replay（回滚清单回放）
   - Input: R031 scope manifest JSON.
   - Output: existence + sha256 + future rollback action metadata for approved paths.
   - Rule: this is read-only replay. Never restore/delete/reset files during replay.
   - `restore_requires_explicit_future_authorization` must remain true.

3. R033 — artifact index compaction（证据索引压缩）
   - Input: evidence directory containing `omega_round_*.json`, `omega_round_*.md`, and user-visible R reports.
   - Output: compact metadata/hash index with path, suffix, bytes, sha256.
   - Rule: do not read large artifact bodies into the final answer and do not rewrite historical evidence files.

## Implementation surfaces

Expected functions in `agent/pgg_archon_omega_absorption_core.py` and runtime wrapper:

- `build_scope_isolation_manifest`
- `write_round_031_scope_isolation_package`
- `build_rollback_manifest_replay`
- `write_round_032_rollback_replay_package`
- `build_artifact_index_compaction`
- `write_round_033_artifact_index_package`

After adding functions, always sync `/Users/appleoppa/.hermes/agent/pgg_archon_omega_absorption_core.py` wrapper exports.

## Verification checklist

- Run `python3 -m py_compile` on both canonical core and runtime wrapper.
- Run targeted pytest for `tests/agent/test_pgg_archon_omega_absorption_core.py`.
- Generate JSON + Markdown evidence package for the round.
- Insert a compact gene row into PGG Archon SQLite gene DB.
- Read back the inserted gene with `build_gene_lineage_readback`.
- Generate a user-visible `.md` completion report.

## Reporting format

For Feishu/mobile, report fields not wide tables:

- status
- evidence_level
- pytest result
- gene_id / readback status
- evidence paths
- hard boundaries preserved
- next round candidate

## Pitfalls

- Do not treat R030 `blocked` as a reason to stop if a scope isolation round can safely isolate the blocker.
- Do not put historical/legacy paths into commit scope.
- Do not claim rollback was performed; R032 only proves rollback references are replayable.
- Do not say artifact compaction reduced actual disk usage unless files were truly deleted or compressed. R033 only creates a metadata/hash index.
- Do not update or create narrow one-round skills for R031/R032/R033; keep these as references under the PGG Archon runtime umbrella.
