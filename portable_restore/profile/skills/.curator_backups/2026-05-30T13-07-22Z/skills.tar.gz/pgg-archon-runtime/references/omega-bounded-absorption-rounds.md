# Omega bounded absorption rounds: R028-R030 pattern

## Trigger

Use this reference when the user says to continue PGG Archon / Omega / AGI absorption without further prompting, especially after a previous round has produced a readiness or quality gate.

## Durable pattern

1. Do not stop at a status report if the latest verified gate says the next bounded stage is allowed.
2. Convert the previous round's evidence into the next explicit gate:
   - R028 style: pre-absorption readiness gate reads R027 package, gene readback, namespace registry, pytest result, and hard-block integrity.
   - R029 style: bounded absorption queue planner ranks next candidates but does not execute candidate code.
   - R030 style: modification surface audit separates current-round Omega surfaces from unrelated worktree surfaces before any commit/add/promotion.
3. Always keep the hard boundary explicit:
   - no unbounded loop;
   - no deploy/install/launcher;
   - no git push;
   - no secret read/write;
   - no mixing unrelated worktree modifications into the current absorption lineage.
4. If a gate finds unrelated or outside-allowed-root modifications, the round can still be completed as an audit with verified tests and gene readback, but the next execution step must first isolate scope rather than pretending the tree is clean.

## Evidence bundle checklist

Each round should produce, then read back:

- JSON evidence package under `~/.hermes/workspace/evolution/...`;
- Markdown report under the same evidence directory;
- gene DB insert or deduped existing gene record;
- `PGGArchonOmegaGeneLineageReadback/v1` readback file;
- `py_compile` plus focused pytest output.

## User-facing reporting rule

For Feishu/mobile output, summarize only:

- completed round IDs;
- status fields (`ready`, `verified`, `blocked`);
- gene IDs and total gene count;
- test result;
- exact report paths;
- current hard boundary or blocker.

Do not dump long JSON or tool logs unless the user asks.
