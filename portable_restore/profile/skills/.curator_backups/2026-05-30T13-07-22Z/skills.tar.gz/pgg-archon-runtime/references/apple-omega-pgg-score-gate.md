# Apple-Omega PGG 评分门禁脚本模板

用途：把 Apple Hub ↔ Omega 共同进化报告转成可审计评分，并在通过门槛后写入本地 PGG Archon gene DB。

## 触发条件

- 用户要求“继续进化”“共同学习”“补短”“写入基因库”；
- 已有 `evolution_logs/apple_omega_coevolution_*.json` 报告；
- runtime 已有真实 LLM 调用证据。

## 关键设计

1. 输入：共同进化 JSON 报告。
2. 输出：`apple_omega_pgg_score_gate_<timestamp>.json/.md`。
3. 评分：HTTP 成功、真实 LLM mode、latency、短板分析、基因候选、反越级宣称。
4. 入库：`~/.hermes/data/pgg_archon.db` → `genes` 表。
5. 幂等：按 gene name 查询，存在则 skipped，不重复插入。

## 最小命令形态

```bash
python scripts/pgg_score_and_gene_gate.py \
  --source evolution_logs/apple_omega_coevolution_<timestamp>.json \
  --out-dir evolution_logs \
  --threshold 75
```

## 验证

```bash
python -m py_compile scripts/pgg_score_and_gene_gate.py
python scripts/pgg_score_and_gene_gate.py --source <report.json> --threshold 75
sqlite3 ~/.hermes/data/pgg_archon.db \
  "select id,name,pattern_type,quality_score from genes where pattern_type='apple_omega_coevolution';"
```

## 注意

- 不把评分报告当成 AGI 证明；它只证明互学证据达到入库门槛。
- 不写入密钥；只记录 provider/model/mode/key 是否 configured。
- 如果第二次运行出现 `inserted=[]` 且 `skipped=[...]`，说明幂等去重正常。
