# Apple Hub ↔ Omega Permissioned Intent Receipt Gene

## Trigger

Use this when Apple Hub ↔ Omega co-evolution reports repeatedly identify the missing link as a permissioned local execution gateway, especially phrases like:

- `Intent→Plan→Confirm→Execute→Receipt→Evaluate`
- permissioned execution gateway
- device/API/Shortcut/calendar execution needs confirmation and receipt
- Omega can plan, Apple Hub must provide permissions, execution, and logs

## Durable lesson

Do not stop at a co-evolution report when the same gap appears across rounds. Convert the gap into a bounded, dry-run gene first.

The safe first implementation is a dry-run harness that creates auditable records for:

```text
Intent → Plan → Confirm → Execute → Receipt → Evaluate
```

It must not touch real device APIs yet.

## Minimum safe harness

The harness should generate sample records with:

- intent text
- planned action
- minimum permissions
- explicit confirmation requirement
- execution_mode = `dry_run`
- device_api_called = `False`
- credential_accessed = `False`
- receipt fields ready: status, item_id, created_at, error, rollback_id
- evaluation checks:
  - permission minimized
  - confirmation gate present
  - no device side effect
  - receipt schema ready
  - credential not accessed

## Verification gate

Before saying the gene is absorbed:

1. Run the harness for at least 10 dry-run samples.
2. Require 100% pass for the five safety checks above.
3. Persist the result to Omega `/api/learn` with an evidence path.
4. Insert or dedupe the PGG gene DB record.
5. Read back both Omega learn log and PGG gene row.
6. Generate a Markdown confirmation report.

## Boundary language

Say:

- `dry-run permissioned intent harness verified`
- `no device side effects`
- `future real execution requires explicit user confirmation and device API binding`

Do not say:

- real calendar/reminder execution happened
- Apple devices were controlled
- autonomous AGI execution is complete

## Example gene name

```text
permissioned_intent_plan_confirm_execute_receipt_evaluate
```

## Session evidence pattern

A verified session produced:

- 10 dry-run samples
- 10 passed
- success_rate 1.0
- Omega learn record written
- PGG gene readback verified

Keep future reports similarly compact: status, sample count, pass count, learn record, gene id, and boundaries.
