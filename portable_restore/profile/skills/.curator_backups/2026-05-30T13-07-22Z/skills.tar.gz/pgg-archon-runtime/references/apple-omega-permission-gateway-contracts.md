# Apple Hub ↔ Omega Permission Gateway Contracts

## Trigger

Use this when Apple Hub ↔ Omega co-evolution moves beyond a dry-run `Intent→Plan→Confirm→Execute→Receipt→Evaluate` harness and needs a safer permission gateway layer before any future real device/API execution.

Typical phrases:

- `继续` after the permissioned intent harness is verified
- permission gateway
- receipt replay evaluator
- confirmation contract
- contract-bound execution
- negative replay for expired / over-scoped / nonce-replayed confirmations

## Durable lesson

Do not jump from a dry-run permissioned intent harness directly to real Calendar / Reminder / Shortcut / device APIs. Insert two dry-run contract layers first:

1. **Receipt replay evaluator** — replay existing receipts and aggregate safety metrics.
2. **Confirmation contract** — convert user confirmation from a boolean into an auditable contract bound to plan hash, action, scope, nonce and receipt.

Only after these pass should a future session consider real API binding, and that still requires explicit user confirmation and a separate permission gateway.

## Receipt replay evaluator

The replay evaluator should:

- read the latest dry-run harness JSON
- recompute evaluation for each receipt
- produce aggregate metrics:
  - `total_receipts`
  - `passed`
  - `success_rate`
  - `blocked_rate`
  - `least_privilege_score`
  - `confirmation_gate_score`
  - `receipt_schema_score`
  - `no_side_effect_score`
  - `failure_distribution`
- generate JSON + Markdown evidence
- persist to Omega `/api/learn`
- insert/dedupe a PGG gene and read it back

Expected safe pattern when no live user confirmation exists:

```text
blocked_rate: 1.0
failure_distribution: {"confirmation_missing_or_denied": 10}
```

This is a PASS condition, not a failure, because the gateway correctly blocks execution without confirmation.

## Confirmation contract

The confirmation contract should include:

- `confirmation_id`
- `confirmation_scope`
- `allowed_action`
- `required_permissions`
- `confirmation_state`
- `denied_reason`
- `issued_at`
- `expiration_policy`
- `replay_nonce`
- `contract_hash`
- plan hash binding
- receipt / gateway hash binding

Verification checks:

- confirmation id present
- scope is single planned action only
- allowed action matches the plan
- expiration policy present
- replay nonce present
- receipt is bound to the gateway decision hash
- dry-run forbids device API
- dry-run forbids credential access

## Negative replay should follow

After a positive confirmation contract passes, the next safe round is **negative replay**. It should generate deliberately invalid contracts and confirm all are blocked:

- expired contract
- allowed action mismatch
- plan hash mismatch
- replay nonce reuse
- over-broad permission scope
- credential/device API permission escalation

## Verification gate

Before reporting success:

1. Run `py_compile` for the harness script.
2. Run the positive or negative replay command.
3. Re-run the base harness and receipt replay if the evaluator logic changed.
4. Run Omega-side tests if inside the Omega repo.
5. Persist the verified artifact to Omega `/api/learn` with `evidence_path`.
6. Insert or dedupe the PGG gene DB record.
7. Read back the Omega learn record and PGG gene row.
8. Generate a compact Markdown confirmation report.

## Boundary language

Say:

- `dry-run confirmation contract verified`
- `no device side effects`
- `gateway correctly blocked missing/invalid confirmation`
- `future real execution still requires explicit user confirmation and device API binding`

Do not say:

- real Calendar / Reminder / Shortcut execution happened
- Apple devices were controlled
- autonomous AGI execution is complete

## Evidence pattern from verified session

A verified session produced:

- receipt replay evaluator: `10/10 passed`, `blocked_rate=1.0`, failure distribution `confirmation_missing_or_denied: 10`
- confirmation contract: `10/10 passed`, `success_rate=1.0`
- Omega learn records written
- PGG genes inserted and read back
- no device/calendar/reminder/shortcut API calls
- no credential access
