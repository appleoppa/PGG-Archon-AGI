# Apple Hub ↔ Omega AGI 共同进化链路模式

## 适用场景

用户要求把本机 AGI/runtime 项目与苹果中枢“链接、互学、补短、共同进化”，且该项目已经有本地 HTTP runtime 与 LLM provider 配置。

## 关键原则

- 连接必须是真实 HTTP/API 调用，不用角色扮演冒充另一个 AGI。
- 互学必须产生可读回证据：JSON/Markdown 报告、轮次、latency、mode、短板、下一步。
- 进化必须区分三种状态：可运行部署、LLM 交互、真实自主 AGI；禁止越级宣称。
- 如果 runtime 只有 `/api/chat`，优先补一个 `/api/learn` 持久化接口，将学习记录写入 JSONL。
- 每轮报告要包含“苹果中枢能补 Omega 什么、Omega 能补苹果中枢什么、下一条可执行基因”。

## 推荐闭环

1. 验证 runtime：`GET /api/health`，确认 `llm_configured=true`。
2. 验证真实 LLM：`POST /api/chat`，让对方只回复固定校验词。
3. 执行 3 轮互学：
   - Round 1：建立连接与互补边界。
   - Round 2：把互补边界转为模块。
   - Round 3：形成闭环指标与下一步基因。
4. 生成证据：
   - `evolution_logs/apple_omega_coevolution_<timestamp>.json`
   - `evolution_logs/apple_omega_coevolution_<timestamp>.md`
5. 如可行，调用 `/api/learn` 写入：
   - `source`
   - `lesson`
   - `evidence_path`
   - `genes`
6. 读回 JSONL，运行 `cargo check/test/build` 或相应部署验证。
7. 接入 PGG 评分门禁：对每轮互学按 HTTP/LLM 成功、真实 LLM mode、latency、短板分析、基因候选、反越级宣称打分；门槛建议 ≥75。
8. 门禁通过后写入 `~/.hermes/data/pgg_archon.db` 的 `genes` 表；写入前按 gene name 去重，复跑应返回 skipped 而不是重复插入。
9. 提供可重复入口（如 `scripts/run_co_evolution_cycle.sh`）：检查 runtime → 跑互学 → 生成报告 → 评分门禁 → 合格入库。
10. 提交前只 add 本轮代码、脚本、证据日志；不要混入 target、venv、临时 payload。

## Rust runtime 最小接口

- `GET /api/health`：返回 service、version、llm_provider、llm_configured、learn_log。
- `GET /api/capabilities`：列出 real-llm-provider-adapter、persistent-learning-log 等能力与 limitations。
- `POST /api/chat`：真实调用 LLM；失败时可返回本地 fallback，但必须标明 `success=false` 或 mode。
- `POST /api/learn`：append JSONL，字段至少含 record_id、created_at、source、lesson、evidence_path、genes。

## PGG 评分门禁建议

评分字段建议总分 100：
- HTTP/LLM round succeeded：30
- real LLM mode used（`mode` 以 `llm:` 开头）：25
- latency within 20s：15
- mutual gap analysis present：10
- gene candidate present：10
- no obvious AGI overclaim：10；若把部署/LLM交互越级说成自主AGI，扣 20。

通过条件：overall_score ≥75 且所有轮次 `ok=true`。通过后可入库基因；失败只保存报告，不写入 gene DB。

## 典型基因候选

- `omega_runtime_real_llm_link`：runtime 必须暴露 health/capabilities/chat 并报告 `llm_configured`。
- `apple_omega_co_learning_loop`：互学必须形成 JSON/MD 证据，包含轮次、latency、mode、短板、下一步。
- `anti_overclaim_gate`：共同进化报告必须区分可运行部署/LLM交互/自主AGI，禁止过度宣称。

## 踩坑

- 不要把 Web UI 可访问当成 runtime/LLM 链路完成。
- 不要把 LLM 回复当成 Omega 已经有长期记忆；必须有 `/api/learn` 或其他持久化读回证据。
- 不要保存 API key；报告中只写 provider/model/mode/key 是否存在。
- 复跑共同进化循环时，要验证幂等性：已入库的 gene 应显示 skipped，不能重复写入。
- 如果连续多轮回复都指向同一个互补短板（例如 Apple 需要权限执行网关、Omega 需要本地状态/执行回执），不要只继续生成互学报告；应把短板转成一个 bounded dry-run gene。权限执行类短板的标准首轮形态见 `references/apple-omega-permissioned-intent-gene.md`：`Intent→Plan→Confirm→Execute→Receipt→Evaluate`，10 样本、无设备副作用、/api/learn、PGG gene DB 读回。
- 如果 shell/curl 因 JSON/中文 quoting 表现异常，改用 payload 文件或 Python requests；记录的是稳定调用模式，不是“curl 不可用”。
- 旧版 `scripts/run_co_evolution_cycle.sh` 可能只完成互学报告 + PGG 评分 + gene 去重入库，不一定自动调用 `/api/learn`。当前版本已接入 `scripts/learn_from_latest_coevolution.py`：每轮评分通过后自动幂等 POST `/api/learn`；复跑同一 evidence_path 应返回 `status=skipped`。每次声称“Omega 已持久学习”前，仍必须 tail/readback `evolution_logs/omega_runtime_learnings.jsonl` 的最新 record_id。
- PGG 入库是本地事实：必须用 SQLite 读回 gene id/name/pattern_type/quality_score 后再汇报。
