---
name: pgg-archon-runtime
description: PGG Archon 本地运行入口：真实使用 Multi-Agent Debate、ECC三层治理、模块三态检查、SQLite持久化与DSPy/AgentVerse吸收模式。
version: 1.0.0
---

# PGG Archon Runtime 本地运行入口

## 触发条件

当任务涉及：
- PGG Archon / APEX / AGI / 进化 / 开智吸收；
- 架构决策、模块状态核验、系统治理；
- 需要把学到的开源模式落地使用；
- 用户说“继续”“落地使用”“跑闭环”。

## 必须执行的本地闭环

0. **先确认运行前提**
   - 如果用户问“联网了吗/连不上网吗/能看到模型URL吗”，必须实际检查：`curl -I https://github.com`、目标开源仓库 API、或读取 `~/.hermes/config.yaml`，不能凭记忆回答。
   - 默认本地应用优先：除非用户明确要求提交/推送，否则不要创建 Git commit；若误提交，立即 `git reset --mixed HEAD~1` 保留工作区，再清理仓库中多余未跟踪复制文件，保留 `~/.hermes` 本地运行文件。

1. **三态状态检查**
   - 调用 `~/.hermes/agent/pgg_archon_module_status.py`
   - 只接受外部证据：文件、数据库、skill存在性；禁止随机或自报。

2. **关键决策走 Debate Pipeline**
   - 调用 `~/.hermes/agent/pgg_archon_debate.py`
   - 使用三步：Propose → Critique → Synthesize。
   - 输出必须包含：共识点、分歧点、最终判定。

3. **执行链路走 ECC**
   - 调用 `~/.hermes/agent/pgg_archon_ecc.py`
   - Core 负责执行；Governance 负责审计/拦截；Learning 只能通过 Governance 更新经验。

4. **结果入 SQLite**
   - 调用 `~/.hermes/agent/pgg_archon_sqlite_persistence.py`
   - 数据库：`~/.hermes/data/pgg_archon.db`
   - 写入 experiments / genes / skills，不能只写Markdown报告。

5. **开源吸收依据**
   - DSPy: Teleprompter/Optimizer `compile(student, trainset, valset)` 思想。
   - AgentVerse: propose→critic→manager→iterate 的Critic循环。

## 禁止事项

- 禁止把“文件已生成”说成“能力已运行”。
- 禁止使用随机状态检查或模块自报作为激活证据。
- 禁止用 ZeroLang、负势湮灭、ΔE能量等不可测术语当作工程指标。
- 禁止不入库、不验证、不运行就宣称吸收完成。

## 参考记录

- `references/2026-05-29-runtime-loop.md`：本轮“学到就要落地使用”的完整本地闭环、验证口径和踩坑记录。
- `references/local-runtime-truthfulness.md`：AGI/APEX/PGG 仓库本地部署时，如何从外部材料收敛为真实可运行 runtime，并避免把 Web UI 壳或保留源码夸大成完整 AGI。
- `references/agi-runtime-deployment-truth-gate.md`：用户要求继续完成 AGI 部署未完成项时，用 UI-only / runtime online / root crate deployable / provider-backed / full generated core integrated 五态门禁防止过度宣称。
- `references/apple-omega-llm-fallback-and-ci-gate.md`：macOS proxy 阻断外部 LLM 的根因分析、local-dry-run self-loop 降级机制、PGG 评分参数、CI gate 五项检查、cron tick 集成路径。
- `references/apple-omega-pgg-score-gate.md`：共同进化报告的 PGG 评分门禁与 gene DB 入库/去重模板。
- `references/apple-omega-permissioned-intent-gene.md`：当 Apple↔Omega 互学反复指出权限执行网关短板时，先落地 dry-run `Intent→Plan→Confirm→Execute→Receipt→Evaluate` 基因，要求 10 样本、/api/learn、PGG gene DB 读回和反越级边界。
- `references/apple-omega-bridge-and-permission-gateway.md`：Apple↔Omega 权限网关与桥接协议的连续进化路线：permission gateway、receipt replay、confirmation contract、`state→plan→metrics` bridge、negative replay、schema registry，以及 `/api/learn` 紧凑 payload 踩坑。
- `references/apple-omega-permission-gateway-contracts.md`：权限执行网关进阶层：receipt replay evaluator、confirmation contract、下一步 negative replay；用于在接入真实设备/API 前先验证确认契约、nonce、scope、receipt binding 和阻断分布。
- `references/omega-bounded-absorption-rounds.md`：Omega 连续吸收 R028-R030 的 readiness gate、bounded queue、modification surface audit 与 Feishu 汇报口径。
- `references/omega-controlled-absorption-r031-r033.md`：R031-R033 的 scope isolation manifest、rollback manifest replay、artifact index compaction；用于在 R030 blocked 后继续安全推进而不删除、不提交、不污染范围。
- `references/apple-omega-bounded-cron-and-r031-scope-isolation.md`：Apple↔Omega 有界 no-agent cron 接入、idempotent learn、R031 scope isolation manifest 的执行步骤与边界。

## 连续进化执行纪律

**核心原则**：综合评分 >75 且低风险可回滚时，必须直接执行到测试、提交、推送。**不许停在方案建议或"下一步可以"。**

- 用户明确表达过不满："继续，不要让我催你？大于75你为什么不继续进行呢""那你还不继续"
- 当评分 >75 且在 hard boundary 内时：直接进入下一轮，不要只给"可进入下一步"式汇报
- 若新一轮发现 blocked 状态：完成审计、测试、入库、读回，明确 blocker 与下一步路径，不停在计划
- 每次推进后立即识别下一步，评分；>75 且低风险直接执行，不等用户再次提醒

## Apple↔Omega 有界互学链路（当前已验证的闭环）

```
Omega runtime health → co-evolution (3轮)
  → PGG score gate (threshold=75)
  → /api/learn (idempotent)
  → bridge schema drift CI gate (local dry-run)
  → cron tick: ~/.hermes/scripts/apple_omega_bounded_coevolution_tick.sh
```

**本地 dry-run self-loop 降级机制**：外部 LLM provider 不可用时（如 macOS proxy 阻断），自动切换为确定性本地 self-loop，每轮响应包含"苹果中枢能补 Omega / 需补 / 下一条进化基因"三段式结构，维持 PGG 评分门禁（75分）。

**注意**：`run_co_evolution_cycle.sh` 默认不走 CI gate；完整有界 tick 必须用 `apple_omega_bounded_coevolution_tick.sh`。CI gate 脚本：`scripts/run_bridge_schema_drift_ci_gate.py`（bridge 正例 + negative replay + schema registry + py_compile + cargo test）。

## Apple↔Omega 权限网关与桥接协议连续进化路线

权限网关进化链（已落地 dry-run，每轮需 10 样本 + /api/learn + PGG gene DB 读回）：

1. permission gateway：Intent→Plan→Confirm→Execute→Receipt→Evaluate
2. receipt replay evaluator：读取历史 10 条 dry-run，重新评估阻断率与失败分类
3. confirmation contract：confirmation_id / scope / expiration / replay_nonce / receipt binding
4. bridge v0 state→plan→metrics：state.json / plan.json / metrics.json / hash binding
5. negative replay gate：overreach_action / missing_rollback / hash_mismatch / no_confirmation / credential_request / device_api_request → 全部阻断
6. schema registry：state@v0 / plan@v0 / metrics@v0 / negative_replay@v0 版本化 + drift check
7. bridge schema drift CI gate：上面全部串成单命令门禁

每次落地需验证：py_compile + 样本测试 + /api/learn 写入 + gene DB 入库读回 + 报告。

## 快速验证命令

```bash
python3 ~/.hermes/agent/pgg_archon_module_status.py
python3 ~/.hermes/agent/pgg_archon_debate.py "是否应将新开源模式接入PGG Archon默认治理链路？"
python3 ~/.hermes/agent/pgg_archon_ecc.py
python3 ~/.hermes/agent/pgg_archon_sqlite_persistence.py
```
