# Omega controlled absorption R027 note

## Context

R027 follows R026 bounded execution permission. Its class-level purpose is to make prior Omega absorption rounds replayable and namespace-stable before any later expansion.

## Durable workflow lesson

When continuing an AGI / Omega evolution sequence after a prior explicit authorization, distinguish three completion states:

1. code/test complete: implementation, runtime wrapper, and tests pass;
2. evidence package complete: round package and registry/report files are generated and read back;
3. lineage complete: gene DB insert and readback are verified.

Do not collapse these states into “complete”. If a security gate blocks package generation, gene DB insert, or report generation, stop immediately and ask for plain-text authorization for the exact blocked side effect. Do not retry the blocked outcome through a different wrapper or phrasing.

## R027 capability pattern

R027 should remain a bounded, read-only replay plus registry persistence step:

- quality gate replay: verify prior round artifact existence, JSON schema fields, content hashes, and R026 hard blocks;
- namespace registry persistence: write a deterministic `omega/*` registry to prevent namespace drift and duplicate capability names;
- runtime wrapper drift check: every new public function in the repo implementation must be exported by the runtime wrapper;
- tests: include happy-path replay, duplicate namespace detection, and package writer smoke tests.

## Boundaries

R027 does not execute hooks, launch daemons, deploy, push git, read/write secrets, or weaken R026 hard blocks. It is an audit-and-persistence round, not a broader execution-permission round.
