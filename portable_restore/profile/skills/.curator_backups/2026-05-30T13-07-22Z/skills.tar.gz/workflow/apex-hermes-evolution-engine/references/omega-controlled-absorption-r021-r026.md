# Omega controlled absorption R021-R026 session note

## Context

A later Omega AGI absorption session continued from R020 bounded watchdog into R021-R026. The durable learning is not the one-off file list; it is the class-level pattern for safely absorbing powerful external AGI-style frameworks while the user asks for maximum speed and broader execution rights.

## Durable pattern

1. Treat "expand execution permissions" as an expanded bounded profile, not an unlimited permission grant.
2. Preserve non-negotiable hard blocks:
   - unbounded loop
   - git push
   - deploy/install/launcher scripts
   - secret read/write
   - writes outside allowed roots
   - daemons without stop condition
3. Safe expansion may include local, reversible, evidence-producing actions:
   - read
   - report
   - verify
   - score
   - workspace_write
   - py_compile
   - pytest
   - sqlite_gene_insert
4. Every new permission tier needs an explicit request validator with:
   - allowed_actions
   - allowed_roots
   - max_steps
   - max_runtime_seconds
   - write_allowed flag
   - hard_blocks
5. Before claiming completion, produce and read back:
   - Markdown report
   - JSON evidence package
   - focused tests
   - gene DB insert
   - gene lineage readback
6. If a tool times out or the system reports a blocked write, do not count it as completed. First inspect for actual artifacts and DB rows, then rerun only after explicit authorization or by using a safer atomic tool path.

## Applied modules

- R021 namespace isolation: Omega imports under omega/* namespace; executor_binding=false.
- R022 context reference gate: @file/@url/@commit/@symbol resolver metadata only; network off by default.
- R023 scheduler/executor gate: static plan validation only; no daemon start.
- R024 final absorption report gate: completion requires dual-model review, tests, lineage readback, and Markdown report.
- R025 event hook + checkpoint replay: append-only audit, payload redaction, replay verification; no hook execution and no state restore.
- R026 bounded execution permission: expanded local execution profile with hard blocks retained.

## Reporting wording

Use "已扩大为有界执行权限" rather than "权限完全放开". Make the expansion visible, but state the red lines in the same report so future sessions do not accidentally convert a high-trust authorization into unsafe autonomy.
