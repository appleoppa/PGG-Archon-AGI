# Omega AGI R011-R019 受控自演化评分与续轮记录

## 适用场景

当用户要求“开启自演化”“对当前 AGI 进程评分”“继续，若必要性 >75% 自动进入下一轮”时，使用本记录作为 Omega AGI 受控 staged sequence 的参考。

## 核心学习

1. “开启自演化”只能开启受控 staged 自演化，不得解释为无界后台循环。
2. 当前 AGI 进程评分是工程进程评分，不是意识、通用智能或 AGI 觉醒证明。
3. 每轮必须先评分：`score > 75` 且无 blocker 才能自动进入下一轮。
4. 自动续轮仍必须保留 allowlist、secret scan、测试、读回、rollback、lineage。
5. wrapper drift 是真实风险：主实现新增能力后，`~/.hermes/agent/` runtime wrapper 必须同步导出，否则 PGG runtime 入口会落后。
6. 自演化过程中要做 modification surface audit：区分 Omega 本轮文件、用户既有改动、运行副产物和 workspace 证据，不混入提交或后续处理。
7. 运行副产物（如 debate_result.json）应归档到 evidence/workspace，不留在 repo 根目录；归档优先于删除。

## R011-R019 摘要

- R011：当前 AGI 进程评分，score=95，开启 `active_bounded_staged`。
- R012：candidate gap scan，找到可继续候选，最高 score=91。
- R013：将 `verified` 作为评分器一等成功状态，并新增 stop-case 测试。
- R014：把 gene lineage readback 函数化，新增连续 ID 与缺失 ID 测试。
- R015：同步 PGG runtime wrapper，导出 R005-R014 新增函数/类。
- R016：执行 modification surface audit，区分本轮 Omega 文件与既有用户改动。
- R017：归档运行副产物 `debate_result.json` 到 evidence 目录，不删除用户文件。
- R018：生成阶段面板，读回 gene ID 50-55 连续性。
- R019：闭合检查，pytest 22 passed，wrapper smoke score=100。

## 推荐执行模板

```text
1. 核验：pytest / py_compile / wrapper smoke / git status / evidence files / gene DB。
2. 评分：生成 `PGGArchonCurrentAGIProcessScore` 或 `RoundContinuationScore`。
3. 决策：score > 75 且无 blocker → 自动进入下一轮；否则停止并报告。
4. 执行：仅 bounded staged；不 git push、不部署、不 secret、不白名单外写入。
5. 读回：报告文件、测试结果、gene DB 新增 ID。
6. hygiene：归档副产物，审计修改面。
7. 汇报：字段化说明分数、轮次、证据、边界和下一轮状态。
```

## 禁止措辞

- 不写“已开启无限自演化”。
- 不写“AGI 已觉醒”。
- 不把工程评分说成智能水平证明。
- 不把 wrapper 导出同步说成核心能力全面上线。

## 验证要点

- 至少一次 `pytest tests/agent/test_pgg_archon_omega_absorption_core.py -q` 通过。
- wrapper smoke 必须证明 `score_next_round`、`verify_round_artifact`、`build_gene_lineage_readback` 可从 runtime wrapper 访问。
- gene lineage 必须读回新增 ID。
- git status 中用户既有改动不得被混入 Omega 自演化处理。