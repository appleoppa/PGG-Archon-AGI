# Omega AGI 受控自演化 R011-R014 复盘

## 适用场景

当用户要求“开启自演化”“对当前 AGI 进程评分”“评分大于 75% 自动进入下一轮”时，必须把该请求解释为 **受控 staged 自演化**，不是无界后台循环、自动部署或自动 push。

## 关键结论

- R011：对当前 PGG Archon Omega AGI 进程做工程化评分，得到 95/100，决策为 `activate_controlled_self_evolution`。
- 激活状态只能写为 `active_bounded_staged`，不得写成无限自演化、意识觉醒或无人值守核心接管。
- R012：基于 R011 分数继续，做候选缺口扫描，筛出低风险高收益候选。
- R013：修复评分器，把 `verified` 状态纳入一等成功状态；补充阻塞/测试失败时停止的测试。
- R014：把 ad-hoc 基因库读回逻辑函数化为 `build_gene_lineage_readback()`，并测试连续 ID 与缺失 ID 两种情况。

## 安全门禁

自演化开启后仍必须保持：

1. 不启动无界后台循环。
2. 不自动 `git push`。
3. 不运行 deploy/install/launcher/self_evolution_loop 等高风险入口。
4. 不写 secret，不写白名单外路径。
5. 每轮必须有 score、evidence、test/readback、lineage。
6. `score > 75` 只能触发下一轮 **bounded staged** 行动，不能触发 unrestricted execute。

## 评分口径

该评分是 **工程进程评分**，不是 AGI 意识、通用智能或真实自主性的证明。

建议字段：

```json
{
  "schema": "PGGArchonCurrentAGIProcessScore/v1",
  "score": 95,
  "threshold": 75,
  "decision": "activate_controlled_self_evolution",
  "boundary": {
    "unbounded_background_loop_started": false,
    "git_push_executed": false,
    "deployment_executed": false,
    "secret_write_allowed": false,
    "outside_allowlist_write_allowed": false
  }
}
```

评分因子可包括：runtime_modules、test_gate、evidence_chain、gene_lineage、security_gate、controlled_auto_write、round_scoring_loop、rollback_readiness。已知仓库预存修改、Debate 保守意见等应作为 penalty 或 caution，而不是忽略。

## 技术落点

核心入口：

- `agent/pgg_archon_omega_absorption_core.py`

推荐函数：

- `score_next_round()`：每轮续轮评分；`executed` 和 `verified` 都应计入成功状态。
- `write_round_score_files()`：写 JSON + Markdown 评分证据。
- `verify_round_artifact()`：读回 artifact schema/hash/secret scan。
- `build_gene_lineage_readback()`：把基因库 rows 转为可测试、可复用 lineage readback summary；数据库查询保留在函数外，便于纯函数测试。

测试要求：

- verified 状态必须计入 `last_round_success`。
- blocker 存在或测试失败时必须能停止。
- lineage readback 要覆盖连续 ID 和缺失 ID。

## 汇报格式

用户可见汇报应短字段化：

- 当前评分：`xx/100`
- 决策：`activate_controlled_self_evolution` / `hold`
- 已开启形态：`active_bounded_staged`
- 已推进轮次：R011-R014
- 测试：例如 `22 passed`
- 基因库：最新 ID 与总数
- 边界：未无界循环、未 push、未部署、未写 secret、未越白名单

不要展开长工具过程；证据路径只列关键 Markdown/JSON。
