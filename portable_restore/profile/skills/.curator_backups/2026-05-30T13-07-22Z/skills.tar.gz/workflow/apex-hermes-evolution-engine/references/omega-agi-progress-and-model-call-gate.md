# Omega AGI 吸收任务：进度汇报与双模型调用门禁

适用场景：用户要求把外部 AGI/进化框架全量拆解、吸收进 PGG Archon/Hermes，并明确要求 GPT/Claude 共同参与。

## 进度汇报模板

飞书/手机端优先短字段清单，不用宽表格：

```text
当前结论：完整完成 / 部分完成 / 阻塞 / 未验证
已完成：只列有证据的动作
证据路径：报告、JSON、日志、读回文件
阻塞/风险：真实失败、未验证点、权限边界
未完成：按任务节点列出
下一步选项：等待通道 / 修复通道 / 降级审查 / 继续低风险落地
```

## AGI/Omega 吸收六段状态

不要把任一阶段冒充全量完成：

1. 预检完成：证据目录、git 状态、输入目录存在性、风险边界。
2. 双模型审查完成：GPT/Claude 均有真实响应或明确失败记录。
3. 全量矩阵完成：源模块、风险、吸收类型、目标位置、验证、回滚。
4. 核心入口写入：sidecar/核心文件实际存在并通过语法检查。
5. 基因/技能入库：写入后读回验证。
6. 测试通过：py_compile/单测/报告读回均有证据。

## GPT/Claude 调用证据字段

保存到 JSON 或 Markdown 证据卡：

```yaml
model_call:
  provider: ""
  model: ""
  api_mode: "responses/chat/anthropic_messages/..."
  called_at: ""
  status: "ok/error/timeout/blocked/missing_key"
  response_file: ""
  error_summary: ""
```

## 失败或阻断处理

- 调用失败不等于任务失败，但必须降级为“未取得有效双模型审查”。
- 系统阻断或超时保护出现时，不继续绕路重复同类调用。
- 可交付给用户的下一步是三选一：等待外部通道恢复；修复 provider/proxy/TLS 通道；授权使用本地 Debate+ECC 作为降级审查。
- 任何情况下不得写“GPT/Claude 已共同完成”，除非 response 文件中确有有效文本。
