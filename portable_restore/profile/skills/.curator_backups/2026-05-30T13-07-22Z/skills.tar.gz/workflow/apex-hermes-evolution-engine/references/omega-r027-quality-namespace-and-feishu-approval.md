# Omega R027：质量门禁回放、命名空间注册与飞书审批失效处理

## 触发场景

- 用户在 PGG Archon / Omega AGI 吸收链路中说“继续进化”。
- R026 已完成 bounded execution permission profile（有界执行权限配置），下一步需要把前序轮次固化为可重复 replay（回放）的质量门禁。
- 飞书/Lark 的 Command Approval Required 按钮出现但用户点击无效，用户以聊天文字明确授权“全部授权”。

## R027 可复用模式

1. 新增 read-only quality gate replay（只读质量门禁回放）：
   - 检查 R021-R026 关键 JSON artifact 是否存在；
   - 校验 `schema` 是否匹配；
   - 记录 bytes / sha256；
   - 检查 R026 hard blocks 是否仍在；
   - 不执行 hook、不恢复 checkpoint、不启动 daemon。

2. 新增 namespace registry persistence（命名空间注册持久化）：
   - 所有 Omega 能力名统一落入 `omega/*`；
   - 检测重复、漂移、未 namespaced 项；
   - 写出 `omega_namespace_registry.json`；
   - `executor_binding` 必须保持 false，注册不等于执行绑定。

3. 证据包形态：
   - `omega_round_027_quality_namespace_package.json`
   - `omega_round_027_quality_namespace_package.md`
   - `omega_namespace_registry.json`
   - `omega_round_027_gene_lineage_readback.json`
   - 用户可见 `.md` 完成报告。

4. 验证门禁：
   - 主实现 `py_compile` 通过；
   - runtime wrapper `py_compile` 通过；
   - 对应测试文件 pytest 通过；
   - gene DB 插入后必须 readback verified。

## 飞书审批按钮失效时的处理

- 现象：飞书卡片按钮可见/可点，但工具侧仍收到 `BLOCKED: timed out without user response`。
- 可靠授权信号：用户在聊天中明确写出授权文字，例如“全部授权”“授权执行 R027 证据包生成、基因入库读回和报告生成”。
- 可执行修复：在用户明确授权后，可启用当前 gateway session 的 yolo 等效状态，或设置 `approvals.mode: off`，以避免 Feishu 按钮链路失效继续卡住可逆本地动作。
- 安全边界：即使用户“全部授权”，仍不得放开 hardline / hard blocks：无界循环、git push、deploy/install/launcher、secret 读写、allowed roots 外写入、无停机条件 daemon。

## 完成态措辞

- 代码与测试完成但入库/报告被审批阻断时，只能说“部分完成”。
- 只有证据包、gene 入库、readback、报告、测试全部验证后，才能说“R027 完整完成”。
