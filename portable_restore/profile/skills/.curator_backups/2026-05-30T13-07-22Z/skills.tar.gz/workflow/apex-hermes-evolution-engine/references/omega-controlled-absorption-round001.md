# Omega AGI controlled full absorption — Round 001 pattern

## Trigger
When the user explicitly authorizes full absorption of `/Users/appleoppa/APEX-AGI-omega-agi-v1.1-sanitized`, including automatic writing and self-evolution.

## Durable lesson
Do not treat high-risk Omega capabilities as permanently forbidden when the user explicitly authorizes full absorption. Instead, absorb them as `gated_execution` capabilities: represented in the core capability map, staged through an apply plan, and only activated through evidence gates.

## Required sequence
1. Verify model/provider endpoint from `~/.hermes/config.yaml`; do not invent an `api.` subdomain.
2. Save GPT/Claude review evidence when requested; if direct call fails, check configured `providers.<name>.base_url` before diagnosing network failure.
3. Generate full absorption matrix with at least these lanes: `core`, `sidecar`, `skill`, `gene`, `report`, `gated_execution`.
4. Represent auto-write and self-evolution as first-class modules, not omissions:
   - `omega_auto_write_gated`
   - `omega_self_evolution_gated`
   - `omega_scheduler_executor_gated`
5. Create a standalone core entrypoint rather than editing unrelated Hermes files with existing uncommitted changes.
6. Add focused tests proving:
   - auto-write and self-evolution are present;
   - critical capabilities stage in dry-run/staged mode;
   - execute mode blocks without an explicit apply plan;
   - reports and apply plans write to evidence files.
7. Write gene records and read them back.
8. For the first self-evolution round, generate a rollback checkpoint containing git status and hashes of touched standalone files.

## Completion wording
Allowed: “Omega auto-write and self-evolution have entered the PGG Archon controlled AGI sequence / staged self-evolution round.”

Not allowed unless separately proven: “unattended infinite self-evolution is running” or “AGI achieved.”

## Round 001 artifact pattern
- Core file: `agent/pgg_archon_omega_absorption_core.py`
- Runtime wrapper: `~/.hermes/agent/pgg_archon_omega_absorption_core.py`
- Report: `omega_full_absorption_matrix.json/md`
- Apply plan: `omega_self_evolution_apply_plan_round_001.json/md`
- Checkpoint: `omega_self_evolution_round_001_checkpoint.json`
