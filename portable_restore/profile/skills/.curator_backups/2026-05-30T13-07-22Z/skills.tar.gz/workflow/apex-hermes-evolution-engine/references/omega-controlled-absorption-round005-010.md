# Omega AGI 受控自演化 R005-R010 经验

## 触发场景

用户要求在 Omega / PGG Archon AGI 受控序列中“每一轮进行评分，如果进入下一轮的必要性大于75%，则立刻继续进入下一轮”。

## 本轮沉淀规则

1. 每轮结束后必须生成显式 continuation score（下一轮必要性评分），字段至少包括：`round_id`、`score`、`threshold=75`、`decision`、`factors`、`rationale`、`next_round`。
2. 当 `score > 75` 且无未解决 blocker（阻塞项）时，不停在汇报，直接进入下一轮低风险、可回滚动作。
3. 下一轮动作仍必须受控：allowlist（白名单）、secret scan（密钥扫描）、readback verification（读回验证）、lineage（谱系入库）、rollback manifest（回滚清单）不能退化。
4. “继续”不等于无界自演化；只能推进 bounded staged sequence（有界分阶段序列）。
5. 每轮入库后必须读回关键 gene ID 或生成 lineage readback 文件；不能只写报告。

## R005-R010 可复用序列

- R005：实现 `score_next_round()` 和 `write_round_score_files()`，生成评分证据；评分 100，进入 R006。
- R006：写入可验证 artifact 并执行 schema/readback/secret scan 验证；状态 verified。
- R007：生成 rollback manifest，只列独立 workspace 证据文件；禁止自动删除核心、自动 git reset、静默删除 DB lineage。
- R008：生成 sequence status panel（序列状态面板），汇总 R001-R008、全局门禁和最新评分。
- R009：读回基因库 lineage，检查目标 ID 区间连续性、缺失 ID、质量分。
- R010：生成阶段 closure report（终态核验报告），明确覆盖轮次、证据存在性、边界和下一轮规则。

## 测试与验证

- 新增核心函数后运行 `py_compile`。
- 使用项目 venv 跑聚焦 pytest；不要用系统 Python 假设已安装 pytest。
- 若系统 Python 缺 pytest，这是环境状态，不写成工具不可用；直接切换项目 venv。

## 禁止夸大

- R005-R010 证明的是“受控 AGI 序列治理闭环继续推进”，不是无界后台自演化。
- 未执行 git push、部署、白名单外写入或 secret 写入时，必须明确说明未执行。
- 评分器是工程门禁，不是 AGI 智能程度评测。