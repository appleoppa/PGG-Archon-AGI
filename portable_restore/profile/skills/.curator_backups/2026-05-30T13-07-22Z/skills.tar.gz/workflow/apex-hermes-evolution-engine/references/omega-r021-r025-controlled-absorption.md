# Omega AGI R021-R025 Controlled Absorption Pattern

## Trigger
Use when the user asks to continue/full-force absorb `APEX-omega-agi` / Omega AGI into PGG Archon AGI after earlier gated rounds already exist.

## Durable workflow learned
1. Keep the user’s “maximum authorization” inside PGG Archon hard gates: no unbounded loops, no `git push`, no deployment scripts, no secret read/write, no writes outside allowlist.
2. If the user requests GPT + Claude collaboration, make real provider calls and persist evidence with provider/model/api_mode/status/response_id or error. Do not claim dual-model review from role-play or subagent naming.
3. Convert Omega mechanisms into bounded capability surfaces rather than executing Omega source:
   - R021 namespace isolation: import Omega names under `omega/*`; detect collisions; `executor_binding=false`.
   - R022 context reference gate: `@file/@url/@commit/@symbol` resolver metadata only; allowlist local files; network off by default.
   - R023 scheduler/executor gate: static job plan only; no daemon start; action allowlist such as read/report/verify/score; cap steps/runtime.
   - R024 final absorption report gate: require dual-model evidence, pytest, gene lineage readback, and Markdown report.
   - R025 event hook + checkpoint replay: append-only audit records, payload redaction, cross-round artifact replay; do not execute hooks or restore state.
4. For every round, write both human-readable Markdown and machine JSON evidence under the workspace evolution directory.
5. Insert promoted/staged capability genes into `pgg_archon.db`, then read back the inserted IDs. Do not count insertion alone as completion.
6. Sync the runtime wrapper whenever the canonical Hermes Agent implementation exports new functions/classes.
7. Add focused pytest tests for every new gate and rerun `py_compile` plus the focused test file.

## Pitfalls
- A final report generation attempt may be blocked if it is bundled with other actions after an interrupted turn. If the user explicitly authorizes report generation, do the report write as a small, isolated file write and then read it back.
- Do not let “maximum authorization” override safety boundaries; phrase the status as “安全吸收链已落地” rather than “Omega has taken over Hermes”.
- Avoid copying or running Omega code directly when license/security state is unclear; self-write minimal compatible gate logic instead.

## Evidence shape
Minimum completion evidence:
- dual model review summary JSON;
- round package Markdown + JSON;
- focused pytest output;
- gene lineage readback JSON;
- final Markdown report with explicit completion boundary.
