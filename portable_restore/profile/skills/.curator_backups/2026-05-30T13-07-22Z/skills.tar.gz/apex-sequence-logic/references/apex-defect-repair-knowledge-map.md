# APEX 10短板外部知识吸收映射

## 背景

用于“对标自我短板→外部学习→补齐机制→固化”的开智进化类任务。该参考不是一次性报告，而是可复用的短板-知识-门禁映射。

## 10个短板与补齐机制

| # | 短板 | 外部知识来源 | 补齐机制 |
|---:|---|---|---|
| 1 | 把反思误当验证 | OpenAI Evals、Phoenix、Ragas、DeepEval | 反思只能作为解释，验证必须外部化为 eval、metric、测试集、评判器 |
| 2 | 把发现问题误当已修复 | Phoenix iterative eval、DeepEval CI、promptfoo GitHub Action | 状态机：detected → diagnosed → patched → evaluated → regression_checked → closed |
| 3 | 固化边界不清 | A2A、MCP、LangGraph Memory、MemGPT | 区分 agent/tool/resource/human/memory/workflow 边界 |
| 4 | 公式口号化 | ReAct、Graph of Thoughts、LangSmith、AutoGen | 公式变成可执行状态机：Generate/Score/Act/Observe/Reflect/Prune |
| 5 | 证据等级高估 | Phoenix anti-patterns、TruLens、Ragas faithfulness | A-E证据等级；faithfulness只证明上下文支持，不证明世界事实绝对正确 |
| 6 | 早期规划锚定 | ReAct、Tree of Thoughts、CrewAI planning | 计划随 observation 更新；关键节点多候选评分并允许回溯 |
| 7 | 多轮运行形式重复 | Reflexion、GoT、AutoGen termination、LangSmith trajectory eval | 多轮必须有 feedback、memory、termination、去重指标 |
| 8 | 权重/阈值/评分表缺失 | promptfoo threshold、DeepEval strict mode、ToT/GoT scoring | 每个指标定义 metric、threshold、pass/fail、severity、failure_action |
| 9 | 跨规则冲突处理不足 | A2A Agent Card、MCP security、LangGraph interrupt、AutoGen handoff | 冲突优先级：安全 > 用户当前目标 > 审批 > 证据 > 协议 > 工作流 > 记忆 > 效率 |
| 10 | 复用闭环不足 | OpenAI private evals、AgentEvals trajectory、LangGraph checkpoint、Generative Agents memory | 失败样例、轨迹、审批、工具调用、修复结果沉淀为可复跑资产 |

## EVAL-BRIDGE 框架

| 模块 | 含义 | 主要解决 |
|---|---|---|
| Evidence grading | 证据分级 | 1、5 |
| Verification eval | 外部验证 | 1、2、8 |
| Agent/tool boundary | 边界协议 | 3、9 |
| Loop control | 循环控制 | 6、7 |
| Branch search | 多路径搜索 | 6、8 |
| Regression suite | 回归测试 | 2、10 |
| Interrupt approval | 人类审批 | 3、9 |
| Dedup/prune | 去重剪枝 | 7 |
| Graph memory | 图式记忆 | 4、7、10 |
| Evolution registry | 进化资产库 | 10 |

## 证据等级规则

| 等级 | 类型 | 强度 |
|---|---|---|
| A | 确定性检查、代码测试、官方原文、人工标注基准 | 强 |
| B | 可复跑 eval、LLM judge + 明确 rubrics、外部官方资料映射 | 中高 |
| C | 工具轨迹、日志、trace、上下文忠实性评估 | 中 |
| D | embedding 相似度、通用指标 | 中低 |
| E | 模型自我反思、自然语言自评 | 弱 |

## 输出边界

- “已吸收外部知识”不等于“永久能力已提升”。
- “已保存进化基因”不等于“后续行为一定通过验证”。
- 只有经过后续任务可复跑验证和回归检查，才能把验证状态升级。
