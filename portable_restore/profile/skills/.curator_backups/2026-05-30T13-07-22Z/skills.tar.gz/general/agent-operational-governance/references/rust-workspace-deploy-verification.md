# Rust Workspace Deployment Verification Pattern

## Pattern Origin

Session: APEX-AGI omega-agi-v1.1 本地部署（2026-05-29）

## Core Pattern

When deploying a Rust project from GitHub to local, it may have a **root Cargo workspace** with broken/incomplete members alongside a **nested sub-workspace** that actually compiles and runs. Strategy:

1. Identify the true runnable unit — not the root, but the nested workspace (`omega-agi/`)
2. Fix the root Cargo.toml only enough to pass `cargo metadata` for the whole repo
3. Build and run the nested workspace binary — verify with actual command execution
4. Accept that `cargo check --workspace` on the root may still fail for broken members; do not let that block local usage of the working sub-workspace

## Step-by-Step

### Phase 1: Repository Structure Discovery

```bash
# Always start from repo root
cd /path/to/repo

# Check what the README says the entry point is
# (cargo build, python web_ui, docker, etc.)

# Identify the workspace layout
cargo metadata --no-deps --format-version 1 2>&1 | head -5
# If fails: "failed to parse manifest at ... Cargo.toml" → broken member or bad config
```

### Phase 2: Find the Working Sub-Workspace

Many large Rust repos have a pattern like:
```
repo/
├── Cargo.toml          ← root workspace (may have broken members)
├── src/main.rs         ← thin CLI wrapper
├── omega-agi/          ← actual working sub-workspace
│   ├── Cargo.toml
│   ├── src/main.rs
│   └── ...
```

Try:
```bash
cargo metadata --no-deps --format-version 1 2>&1 | head -5
# vs
(cd omega-agi && cargo metadata --no-deps --format-version 1 2>&1 | head -5)
```

### Phase 3: Common Cargo.toml Fixes (Root Workspace)

Fix only enough to make `cargo metadata` pass. Common issues:

**1. Missing `optional = true` on a dep used in a feature:**
```toml
# BEFORE (breaks feature resolution)
redis = { version = "0.24", features = ["tokio-comp"] }

# AFTER
redis = { version = "0.24", features = ["tokio-comp"], optional = true }
```

**2. Sub-crate has no `[lib]` section and no `edition`:**
```toml
[package]
name = "cognitive-core-mcp"
version = "0.1.0"
edition = "2021"   # may be missing entirely, or edition listed twice

[lib]              # likely missing entirely
path = "mod.rs"
```

**3. Sub-crate has no source files (Cargo.toml exists but no lib/main):**
```toml
# In the root Cargo.toml, remove the broken member from workspace.members
# OR add stub src/lib.rs to the sub-crate
```

### Phase 4: Source-Level Syntax Errors

Source files can have Rust syntax errors from bad `format!` string escaping:
```rust
// BROKEN (escaped brace mismatch)
let placeholder = format!("{{{{{}}}}}", key);  // extra } before , key

// FIXED
let placeholder = format!("{{{{{}}}}}", key);
```

Use `cargo check -p <crate>` on individual crates to isolate:
```bash
cargo check -p cognitive-core-mcp 2>&1 | grep "error\[" | head -5
```

### Phase 5: Binary Verification

After `cargo build --release -p <package>`, verify:
```bash
# Binary exists and is correct architecture
ls -lh ./target/release/<binary>
file ./target/release/<binary>

# Run the binary with its own health check
./target/release/<binary> check

# Run --help to see available commands
./target/release/<binary> --help
```

### Phase 6: Python Web App Verification

```python
# Use Flask test client (avoids port conflicts)
from app import app
with app.test_client() as c:
    r = c.get('/api/health')
    print(r.get_json())
    r = c.get('/api/status')
    print(r.get_json())
    r = c.get('/api/diagnostics')
    print(r.get_json()['data']['overall_health'])
```

## APEX-AGI omega-agi-v1.1 Specific Findings

| Item | Value |
|------|-------|
| Repo | `hernandez42/APEX-AGI` branch `omega-agi-v1.1` |
| Working unit | `omega-agi/` sub-workspace |
| Binary | `omega-agi/target/release/omega-agi` (6.6M Mach-O arm64) |
| Root fixes | `redis` → `optional = true`; mcp crate `[lib]` + `edition` |
| Source fixes | 2× `format!("{{{{{}}}}}"` → `format!("{{{{{}}}}}"` (brace escaping) |
| Python deps | flask, psutil, pyyaml, requests (via venv) |
| Web UI port | 5000 (conflicts with macOS AirPlay Receiver — use test client) |
| Config | `.env` at repo root; `web_ui/llm_configs.json` |
| Known limitation | `cognitive_core/mcp` crate has 95 compile errors (nested module paths); does NOT block main binary |
| LLM requirement | `OMEGA_API_KEY` needed for real agent/evolve |

## Anti-Patterns (What NOT to Do)

- **Don't** run `cargo check --workspace` on root and declare failure if broken members exist — find the working sub-workspace instead
- **Don't** fix every compile error in every crate — only fix what's needed to run the target binary
- **Don't** start a Flask app on port 5000 on macOS without checking (AirPlay Receiver conflict); use test client
- **Don't** infer which binary to run from the crate name — read README.md to confirm entry point
