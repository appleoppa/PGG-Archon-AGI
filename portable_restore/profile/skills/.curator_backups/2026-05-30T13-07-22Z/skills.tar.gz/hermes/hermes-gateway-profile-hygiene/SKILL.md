---
name: hermes-gateway-profile-hygiene
description: "Diagnose and clean Hermes gateway/profile drift after upgrades: keep messaging on the default profile, stop/uninstall stray profile gateways, migrate config, repair profile metadata, and restore local tool dependencies."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, gateway, profiles, launchd, doctor, upgrade, hygiene]
    related_skills: [hermes-agent]
---

# Hermes Gateway/Profile Hygiene

## Use When

- After a Hermes upgrade, `hermes doctor`, `hermes gateway status`, or `hermes profile list` shows drift.
- Messaging gateway should be single-channel but multiple profiles show `Gateway running`.
- Department/worker profiles should exist for dispatch, but must not independently connect to Feishu/Lark.
- `config.yaml` version is outdated after upgrade.
- A profile is missing `config.yaml`, `.env`, or an alias.
- Browser/computer-use tools are hidden because local runtime dependencies are missing.

## Principles

1. **Protect secrets**: never print `.env` values; inspect key names only.
2. **Default gateway only**: for this user's architecture, only the `default` profile should run the Feishu/Lark gateway. Department `pgg-*` profiles may exist but should remain gateway-stopped unless explicitly directed otherwise.
3. **Stop before uninstall**: stop stray profile gateways first; uninstall their launchd/systemd services only after verifying the default gateway remains available.
4. **Archive, do not delete**: move obsolete LaunchAgents/backups to an archive directory instead of deleting them blindly.
5. **Backup before migration**: copy `~/.hermes/config.yaml` before running `hermes config migrate`.
6. **Verify with live commands**: final status must include `hermes gateway list`, `hermes profile list`, and relevant `hermes doctor` sections.

## Procedure

### 1. Baseline checks

Run targeted checks and avoid loading huge files:

```bash
hermes --version
hermes gateway status
hermes gateway list
hermes profile list
hermes config check
hermes doctor
```

If `hermes model` requires a TTY, do not force it through non-interactive subprocesses; rely on `profile list`, `config check`, and doctor output.

### 2. Enforce single default gateway

For every non-default profile that should not receive messaging directly:

```bash
hermes --profile <profile> gateway stop || true
hermes --profile <profile> gateway uninstall || true
```

Then restart or start the default gateway:

```bash
hermes gateway start
# or, if already loaded and a config reload is needed:
hermes gateway stop || true
hermes gateway start
```

Verify:

```bash
hermes gateway list
```

Expected shape:

```text
✓ default (current) — PID <pid>
✗ pgg-*            — not running
```

### 3. Clean stale LaunchAgents safely

On macOS, keep only the active default gateway plist under `~/Library/LaunchAgents`. Archive backup plists instead of deleting:

```bash
archive="$HOME/.hermes/archives/launchagents-gateway-backups-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$archive"
for f in "$HOME"/Library/LaunchAgents/ai.hermes.gateway*.plist.bak_*; do
  [ -e "$f" ] || continue
  mv "$f" "$archive/"
done
/bin/ls -1 ~/Library/LaunchAgents | grep '^ai\.hermes\.gateway' || true
```

### 4. Migrate main config version

```bash
cfg="$(hermes config path)"
cp "$cfg" "$cfg.bak-v$(date +%Y%m%d-%H%M%S)"
hermes config migrate
hermes config check
```

Only report that migration succeeded after `hermes config check` shows the new version as current.

### 5. Repair profile consistency

Inventory profile files without exposing secrets:

```bash
python3 - <<'PY'
from pathlib import Path
import re
base=Path.home()/'.hermes/profiles'
for p in sorted(x for x in base.iterdir() if x.is_dir()):
    env=p/'.env'; cfg=p/'config.yaml'
    keys=[]
    if env.exists():
        for line in env.read_text(errors='ignore').splitlines():
            m=re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=', line)
            if m: keys.append(m.group(1))
    risky=[k for k in keys if 'FEISHU' in k.upper() or 'LARK' in k.upper()]
    print(p.name, 'config=', cfg.exists(), 'env=', env.exists(), 'feishu_lark_keys=', risky)
PY
```

If a department profile is missing config/env but clearly contains normal profile state (`SOUL.md`, skills, sessions), seed it from a same-class department profile that is known-good, then verify no Feishu/Lark keys appear in that `.env`.

Create missing aliases with:

```bash
hermes profile alias <profile> --name <profile>
```

### 6. Restore local runtime dependencies when safe

If doctor shows browser hidden because Playwright Chromium is absent:

```bash
cd ~/.hermes/hermes-agent && npx playwright install chromium
```

If `computer_use` is hidden because `cua-driver` is absent:

```bash
hermes computer-use install
hermes computer-use status
```

On macOS, remind the user that first actual screen-control use may still require manual Privacy & Security grants for Accessibility and Screen Recording.

### 7. Final verification gate

Before reporting completion, verify:

```bash
hermes gateway list
hermes profile list
/bin/ls -1 ~/Library/LaunchAgents | grep '^ai\.hermes\.gateway' || true
hermes doctor
```

Report remaining warnings as either:

- **Fixed**: local reversible issue resolved and verified.
- **Requires user/API setup**: missing external token, OAuth login, optional service account, or macOS privacy grant.
- **Intentionally not fixed**: optional feature not required by the user's stated architecture.

## Pitfalls

- Do not claim “gateway fixed” just because a plist exists; verify the launchd service is loaded and `gateway list` shows only default running.
- Do not leave department profile gateway plists installed if the user expects single Feishu/Lark entry; stopped services can be accidentally restarted later.
- Do not expose API keys while checking `.env`; print only key names/counts.
- Do not encode transient missing credentials as permanent tool failure. Capture the install/config step, not “tool is broken.”
- `hermes doctor --fix` may not install Playwright Chromium or `cua-driver`; run the explicit install commands when doctor still reports those dependencies missing.

## Reference Notes

- Session example: `references/gateway-profile-hygiene-2026-05-29.md`
