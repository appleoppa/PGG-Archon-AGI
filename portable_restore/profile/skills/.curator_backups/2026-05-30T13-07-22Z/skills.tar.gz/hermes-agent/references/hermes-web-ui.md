# Hermes Web UI

Hermes Web UI (`hermes-web-ui`) is a separate npm package that provides the web dashboard for Hermes Agent. It is NOT part of the core `hermes-agent` install.

**Homepage:** https://github.com/EKKOLearnAI/hermes-web-ui
**npm:** `npm install -g hermes-web-ui`

## Token / Authentication

The web UI uses a token-based auth. On first startup it auto-generates a 64-char hex token and stores it at:

```
~/.hermes-web-ui/.token
```

To find the token:
```bash
cat ~/.hermes-web-ui/.token
```

To reset (generate a new token):
```bash
rm ~/.hermes-web-ui/.token
# then restart: hermes-web-ui start
```

## Default Port

The web UI runs on **port 8648**: http://127.0.0.1:8648

## Gateway API Server (built-in, port 8642)

The core Hermes Agent also ships with a built-in API server. It runs on **port 8642** (configured in `config.yaml` under `platforms.api_server`). It is separate from the `hermes-web-ui` dashboard and uses a different auth mechanism (API key from `config.yaml`).

## Distinguishing Which Is Running

| Port | Package | Auth |
|------|---------|------|
| 8642 | hermes-agent (built-in API server) | `platforms.api_server.key` in config.yaml |
| 8648 | hermes-web-ui | token in `~/.hermes-web-ui/.token` |

Check what's listening:
```bash
lsof -i :8642 -i :8648
```
