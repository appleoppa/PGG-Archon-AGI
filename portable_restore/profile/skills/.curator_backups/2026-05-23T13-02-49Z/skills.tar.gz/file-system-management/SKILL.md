---
name: file-system-management
description: Hermes文件系统清洁：根目录与工作区分离
---

# File System Management — Compact

## Core Principle

Root is for system/runtime/config. Work product belongs in `~/.hermes/workspace/`. File organization reflects work quality.

## Root Allowed

Config/runtime only: config, env/auth/state DBs, sessions, cron, logs, skills, memories, cache, profiles, hooks, temp, gateway files, source package.

## Workspace Standard

- Core files at workspace root: `AGENTS.md`, `MEMORY.md`, `TOOLS.md`, `SOUL.md`, `USER.md`, `IDENTITY.md`.
- Work directories: 智库、向量库、开智、苹果中枢办案库、config、scripts、tools、workflows、standards、templates、logs、任务队列、审计队列、存档、监控日志。
- No random scratch files, duplicate backups, case folders, hidden config dirs, or abandoned dirs in workspace root.

## Safe Delete Rule

Before deleting anything:
1. Inspect actual content, not just name/path.
2. For DB files, check schema/rows.
3. For multiple copies, decide each copy independently.
4. Archive when uncertain.
5. Verify deletion and stale references afterward.

## Workspace Cleanup / Asset Preservation

Use when the user asks to organize, merge, delete, or clean `workspace`.

1. Establish a protected asset allowlist before moving anything. Default protected classes: vector libraries, guiding-case libraries, legal/regulatory libraries, case-management libraries, evolution gene databases, and gene output directories.
2. Split candidates into three buckets: active assets, historical/archive material, and junk. Do not treat `.py`, `.json`, `.sqlite3`, or folder names as disposable without content or dependency checks.
3. Low-risk deletion: system junk such as `.DS_Store`, temp/swap files, and empty shells may be deleted after confirming they are not business data. Even inside protected directories, `.DS_Store` is not an asset.
4. Archive instead of delete for one-time execution scripts, old dry-run/state-machine prototypes, obsolete migration helpers, and historical rule backups. Preserve relative paths under `workspace/存档/<topic>/<timestamp>/moved/`.
5. Keep workspace root clean: no scattered temporary scripts or task outputs at root. Move reusable scripts to `scripts/`/`tools/`; archive one-off scripts.
6. Verify after cleanup: protected asset existence/counts, important SQLite tables/row counts, root-level clutter, active `.DS_Store` count, and whether archived files are gone from their original locations.
8. For the `开智/` active directory, do not keep per-round process folders long-term. Preserve evolution gene assets, total reports, concise indexes, and current specs in active paths; move per-round raw folders to `workspace/存档/开智逐轮过程材料归档/<timestamp>/moved/逐轮文件夹/` after generating a concise index and verifying the gene DB.

9. For the `开智/` historical APEX formula subdirectories (`开智核心/`, `01-APEX开智/` containing apex-spiral, LLM-Pangu, GeneNexus, CodeGenesis, XuanjiQuant): these are NOT part of the current SPEC_FILE specification and should be archived to `workspace/存档/开智逐轮过程材料归档/<timestamp>-<subdir>/` after confirming zero runtime dependency. Verification: source directory gone from active path (or empty); archive destination contains complete directory tree. The `开智核心/` directory alone typically contains 380+ files (2.8MB) of old formula materials that predate the current SPEC_FILE.

See `references/workspace-cleanup-asset-preservation.md` for a concise pattern from the 2026-05 workspace cleanup session.

## Secret Leak Hygiene

Use when the user asks to inspect system/Hermes files for plaintext keys, tokens, auth headers, or credential leakage.

- Default scope is `~/.hermes` unless the user explicitly asks for full-disk scanning.
- Never print raw secrets. Use path, line number, finding type, and masked/hash-only evidence.
- Treat `.env` with `0600` as the normal secret store; configs, auth snapshots, model profiles, logs, sessions, request dumps, and archive backups are leakage surfaces.
- Before redaction, make timestamped remediation backups under `workspace/安全扫描/remediation_<timestamp>/` preserving relative paths.
- Convert active config values from `api_key: <token>` to env references such as `api_key_env: SOME_API_KEY`; then verify permissions and re-scan.
- Beware false positives: env var names like `GPT55_5YUANTOKEN_API_KEY` and policies like `store_secrets_in_env_only` are not secrets.
- See `references/secret-leak-scan-redaction.md` for the full workflow and pitfalls.

## Archive/Edit Rule

Before rewriting important rules, memory, skills, or config-like files, copy originals to `workspace/存档/<topic>/<timestamp>/`, then verify the new files.

## Token Discipline

- Do not load this skill’s archived long procedures unless the task specifically involves skill library flattening, GitHub repo archiving, or bulk deletion.
- Use targeted file search and short summaries instead of listing entire trees.

## References

- `references/workspace-layout.md`
- `references/github-private-repo-archive.md`
- `references/2026-05-17-skills-flattening.md`

## Verification Checklist

- [ ] Work files stayed under workspace.
- [ ] Root not polluted.
- [ ] Destructive operation had content inspection.
- [ ] Important edits had archive backup.
- [ ] Stale references checked when structure changed.
