# Secret Leak Scan and Redaction Pattern

Use when the user asks to check Hermes/system files for plaintext keys, tokens, or credential leakage.

## Scope

Default scope for Hermes security hygiene is `~/.hermes`, not the whole OS. Whole-disk scans are slow and noisy unless the user explicitly asks.

## Non-disclosure rule

Never print raw secrets. Reports should contain only:
- file path;
- line number;
- finding type;
- length/hash prefix if needed;
- redacted preview only if it cannot reveal the token.

## Practical scan classes

Classify hits into:
1. `正常密钥库`: `~/.hermes/.env` with `0600` permissions.
2. `高风险配置明文`: config/auth/model files containing actual tokens, e.g. `config.yaml`, `auth.json`, `agents/*/agent/auth-profiles.json`, `agents/*/agent/models.json`, profile configs, config backups.
3. `高风险会话/日志泄露`: `logs/`, `sessions/`, `request_dump_*`, agent session jsonl, workspace logs.
4. `待确认`: profile `.env` copies, old OpenClaw files, caches, migration outputs.
5. `源码/示例疑似`: code/docs/examples; usually many false positives.

## Redaction workflow

1. Create a timestamped remediation directory under `~/.hermes/workspace/安全扫描/remediation_<timestamp>/`.
2. Before editing, copy original files to a remediation backup subdirectory preserving relative paths.
3. Redact selected high-risk files in place using placeholders such as `<REDACTED_SECRET>` or `<env>`.
4. Set sensitive file permissions to `0600` for `.env`, `auth.json`, config files, logs, sessions, JSON/YAML credential stores.
5. Convert active config secrets to env references, e.g. `api_key_env: SOME_API_KEY`; do not leave `api_key: <actual-token>` in configs.
6. Re-scan after redaction and separate true positives from env-var-name false positives.

## Common pitfalls found

- `api_key_env: SOME_API_KEY` and `secret_policy: store_secrets_in_env_only` are not secrets; scanners may false-positive on these because of `API_KEY`/`secret` words.
- Redaction can accidentally replace env var names with `<REDACTED_SECRET>`; after bulk redaction, inspect active config sections and restore names such as `GPT55_5YUANTOKEN_API_KEY` and `CLAUDE_OPUS47_5YUANTOKEN_API_KEY`.
- `auth.json` may store env-sourced credentials redundantly in `credential_pool[*].access_token`; prefer `<env>` or equivalent redaction while preserving `source: env:NAME`.
- Provider profiles can contain stale copies of root config. After fixing `~/.hermes/config.yaml`, sync or patch profile configs and `config.yaml.bak` too.
- Logs/session dumps may contain complete request payloads; sanitize `logs/*.log`, `sessions/*`, `agents/*/sessions/*`, and workspace log/archive snapshots.

## Verification evidence

Report before/after counts by class, and exact permission state for:
- `~/.hermes/.env`;
- `~/.hermes/auth.json`;
- `~/.hermes/config.yaml`.

Do not claim complete cleanup if remaining high-risk findings are still actual tokens. If remaining findings are env-var-name false positives, say so explicitly and cite the non-secret line shape, not raw values.