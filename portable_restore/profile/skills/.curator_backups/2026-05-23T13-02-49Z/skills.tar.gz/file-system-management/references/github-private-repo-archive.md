# GitHub Private Repository Archive Pattern

## When to use
Use when the user asks to preserve local project repositories in a private GitHub container, especially when multiple local projects should become subdirectories of one remote repository.

## Durable lessons from the session

- Do not assume the GitHub CLI is installed. The REST API plus `git` is enough to verify identity, repository privacy, contents, and branches.
- When the user names a destination like “z-dashen目录”, resolve it concretely before upload: check whether it is a user, organization, existing repository, or intended subdirectory. If `/users/<name>` and `/orgs/<name>` are 404 but `/<owner>/<repo>` exists, treat it as the repository only after verifying ownership and privacy.
- Treat a user-pasted token as sensitive even when authorized: never print it, redact command output, pass it via environment or a short-lived local helper rather than hard-coding it into persistent files, and remove temporary remotes that embed the token after pushing.
- If the destination repository already exists, verify it instead of recreating it. A repository creation `422 name already exists` can mean the target is already present and usable.
- Existing private archives may contain useful prior state. Do **not** use force-push or destructive overwrite by default. First inspect remote root/tree; use a normal push, merge/update, or a new branch unless the user explicitly authorized replacing remote history.
- If combining multiple local projects into one remote repository, stage them in a temporary upload directory as subdirectories such as `apex/` and `evm/`, then push that clean staging repository.
- For a local directory that contains nested `.git` directories, do not push unresolved gitlinks unless submodules are intentional. Convert embedded repositories into normal source directories or explicitly configure submodules. Otherwise the remote can look complete while containing only pointers.
- Exclude machine/runtime noise from archives: `.DS_Store`, `__pycache__/`, `*.pyc`, transient runtime trace directories, sync logs, and other generated artifacts.
- Verification must inspect the remote, not just local push success: confirm repository privacy, root directory names, sample contents under each uploaded subtree, total tree count, and absence of excluded runtime/cache files.
- Clean up after upload: remove temporary directories and any temporary token-bearing remotes from local repositories.

## Minimal verification checklist

- GitHub API `/user` returns the expected account.
- Destination resolution is explicit: user/org/repository/subdirectory ambiguity has been checked and recorded.
- Target repository exists and `private=true`.
- Remote root/tree was inspected before writing; if prior content exists, the update path preserves it unless explicit overwrite authorization was given.
- Remote root contains the expected top-level project directories.
- Each top-level directory exposes expected source/documentation directories.
- Remote recursive tree has no runtime/cache artifacts that were meant to be excluded.
- Local temporary remotes containing credentials have been removed.
