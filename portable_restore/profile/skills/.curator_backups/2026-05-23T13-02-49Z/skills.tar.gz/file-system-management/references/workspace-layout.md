# Workspace Layout Reference (2026-05-17)

## ~/.hermes/ 根目录
Root = system config + runtime only. 46 items total.

### 系统配置
- config.yaml — Hermes Agent 主配置
- config.yaml.bak — 最近一次备份
- .env — API 密钥
- auth.json — 认证信息
- auth.lock
- openclaw.json — 苹果中枢调度配置
- openclaw.json.known-good — 已知可用版本
- SOUL.md — 系统人格
- channel_directory.json — 通道路由
- gateway_state.json — 网关运行状态
- gateway.lock / gateway.pid — 网关锁
- processes.json — 进程注册表
- feishu_seen_message_ids.json — 飞书消息去重
- .gateway-planned-stop.json — 计划停机标记
- .hermes_history / .update_check / .skills_prompt_snapshot.json — 系统运行时

### 系统数据库
- state.db (100MB) — 主状态/会话数据库
- kanban.db (100KB) — Kanban 看板数据库
- response_store.db (20KB) — 响应存储
- models_dev_cache.json (2MB) — 模型缓存

### 系统运行时目录
- sessions/ (61MB) — 会话记录
- skills/ (8MB) — Hermes Agent 技能库
- cron/ — 定时任务
- logs/ (2.2MB) — 日志
- memories/ — 用户记忆
- memory/ (292KB) — 工作记忆
- cache/ — 缓存
- audio_cache/ / image_cache/ — 媒体缓存
- sandboxes/ — 沙箱
- bin/ (9.9MB) — 二进制
- hooks/ — 钩子
- profiles/ — 配置档案
- pairing/ (20KB) — 配对信息
- tmp/ — 临时文件
- weixin/ (16KB) — 微信通信

### 代码
- hermes-agent/ (1GB) — Hermes Agent 完整仓库

## ~/.hermes/workspace/ — 工作空间
26项。所有工作文件在此。

### 文档
- AGENTS.md — 苹果中枢V6.0规则（73KB）
- MEMORY.md — 记忆索引（20KB）
- TOOLS.md — 工具目录（14KB）
- SOUL.md / USER.md / HEARTBEAT.md / IDENTITY.md — 系统人格/用户/心跳/身份
- session_state.json — 会话连续状态

### 办案
- 苹果中枢办案库/ (50MB) — **唯一案件目录**
  - 008 鑫来兴(虚假诉讼再审)
  - 009 滕云英+李洪礼(继承纠纷)
  - 010 A公司(合作模式风险分析)
  - 011 田小飞(销售有毒有害食品罪)
  - 013 尚永恒(工伤保险待遇纠纷)
  - 015 民邦人力(雇主责任险理赔争议)
  - 016 德比时代(竞业限制合同纠纷)
  - 016 民邦人力(雇主责任保险合同纠纷) — 同一编号两个不同案件
  - 017 民邦人力(雇主责任险理赔纠纷)
  - _存档/ — 001-007, 012, 014 已归档案件
  - 台账/ — 档案台账

### 知识
- 智库/ (13MB) — 法律知识库
  - 法律法规库/ (714部法条txt × 13分类)
  - 案例库/ — 最高法/最高检指导案例
  - 知识沉淀/ — 23条案件知识沉淀
  - law_kb.json / K流通知识索引.md
  - 对标分析/ 技能开发/ 技能图/ 经验库/ 知识库/ 种子文档/ 共享资料/ 法规效力状态标注方案.md
- 向量库/ (212MB) — 向量embedding
  - chroma_data/ (201MB)
  - knowledge.db (11MB, 1248条: 717法规+267最高法+255最高检+9法律知识)
- 开智/ (6.5MB) — 进化基因库
  - 01-进化规范/
  - 02-进化基因/ (C4-C17 基因文件)
  - 03-进化基因库/ (C18-C22 gene files, signals, 学习记录)
  - 04-进化基因库/ (C2-C11 手动周期全记录)
  - 05-分析报告/
  - 06-进化提案/ (approved + rejected)
  - 开智核心/ (APEX公式库, 进化执行规范)

### 系统
- config/ — MCP配置, superagent.yaml, router_config, skill_routing
- scripts/ (536KB) — 40个可执行脚本
- tools/ (72KB) — 工具脚本
- workflows/ (92KB) — 12个工作流定义
- standards/ (328KB) — 15个标准规范
- templates/ — 模板
- skills/ — 技能引用
- logs/ — 工作区日志
- memory/ — 工作区记忆

### 排队
- 任务队列/ — 24KB
- 审计队列/ — 4KB

### 归档
- 存档/ (128MB) — 迁移备份 (autoclaw聊天记录, workspace-git等)
- 监控日志/ — 监控快照
- 台账/ — 案件台账

### 不再存在的 (已删除)
- ~~办案库/ — 与苹果中枢办案库100%重复，删除~~ 
- ~~_存档/ — 与苹果中枢办案库/_存档/重复，删除~~
- ~~008-017 根层级案件目录 — 已全部在苹果中枢办案库/内，删除~~
- ~~迁移摘要.md — 迁入存档/迁移备份/~~
- ~~_tmp_formula_check.py / _tmp_r5_state_update.py — 临时文件，删除~~
- ~~子任务输出/ — 空目录，删除~~
- ~~.hermes/ .openclaw/ .opencode/ — 残留隐藏配置，删除~~
