# Workspace Cleanup / Asset Preservation Pattern

## Trigger

Use when the user asks to organize the workspace, merge/delete/keep files, or keep the workspace clean while preserving major data assets.

## Session-derived pattern

1. **Protect assets first**
   - Build an allowlist before moving anything.
   - Typical protected classes: `向量库`, `指导案例库`, `法律法规`, `苹果中枢办案库`, `开智/02-进化基因`, `开智/03-进化基因库`, `github-evolution/genes`.
   - For SQLite assets, verify readability and table/row counts.

2. **Classify before action**
   - Active asset: keep in place.
   - Historical/archive material: move to `workspace/存档/<topic>/<timestamp>/moved/` preserving relative path.
   - Junk: delete only if content class is clearly non-business, such as `.DS_Store` or editor temp files.

3. **One-time scripts**
   - Read or inspect before moving.
   - Old one-time evolution runners, reset helpers, `tmp_*` scripts, and obsolete R1-R5 dry-run state-machine prototypes should usually be archived, not deleted, because they may explain historical gene records.
   - Workspace root should not contain scattered one-time scripts. Root-level scripts are either moved to a functional directory if reusable or archived if historical.

4. **Verification gates**
   - Active `.DS_Store` count is zero.
   - Workspace root `.py` count is zero unless deliberately allowed.
   - Protected asset directories still exist and have nonzero expected content.
   - Evolution gene DB opens and expected tables return row counts.
   - Archived files no longer exist at their original active paths.

5. **Report format**
   - Use a short table: protected assets, deleted count, archived count, skipped/protected count, remaining second-pass items.
   - Explicitly state boundaries: what was not touched and why.

## Pitfalls

- Do not use broad glob deletion against `*.py`, `*.json`, or `*.sqlite3`.
- Do not delete historical one-off scripts if they may be evidence for previous runs; archive them.
- Search tools may treat file globs unexpectedly; verify candidates by path and content before acting.
