# Skills全平摊操作记录 (2026-05-17)

## 范围
将 `~/.hermes/skills/` 下所有分类子目录中的技能平移到根目录，彻底消除分类层级。

## 操作步骤

### Phase 1: 勘察
1. 列出所有分类目录：18个（apple/, creative/, devops/, github/, mlops/, research/ 等）
2. 列出所有子技能：共87个技能位于分类目录下
3. 检查名称冲突：87个技能名与51个已平摊的OpenClaw技能名**零冲突**

**工具**：`test -f "${dir}SKILL.md" && echo "skill" || echo "category"` 区分技能目录和分类目录
**检查冲突**：所有要移动的目录名与根目录现有项逐一比对

### Phase 2: 执行移动
```python
import shutil
for cat in categories:
    for item in os.listdir(cat_path):
        if os.path.isdir(item_path):
            shutil.move(item_path, os.path.join(skills_root, item))
    # Clean up empty category
    remaining = os.listdir(cat_path)
    for f in remaining:
        os.remove(os.path.join(cat_path, f))
    os.rmdir(cat_path)
```

**注意**：`os.path.isdir` 不判断符号链接，但无需特殊处理——技能目录都是实目录。
**注意**：删除空分类目录前，需要先删除 DESCRIPTION.md 等残留文件，否则 rmdir 会失败。
**注意**：`os.remove()` 不能删除目录——可以用 `shutil.rmtree()` 或先清理子文件再 `os.rmdir()`。

### Phase 3: mlops/ 嵌套结构特殊处理
mlops/ 有二级分类（evaluation/, inference/, models/, research/），需要先展开子分类再删除空壳。

### Phase 4: 引用路径检查
- 用户配置文件（AGENTS.md, TOOLS.md, config.yaml）——零引用
- hermes-agent/ 内部（docs, skills, tools）——有引用，但这是发行版代码，不修改
- skill 内部：（映射索引.md, hub SKILL.md, references）——需更新
- `grep -rl 'skills/{old-category}' ~/.hermes --include='*.md' --include='*.yaml' --include='*.py' --include='*.sh' --include='*.json' 2>/dev/null | grep -v '/node_modules/' | grep -v '/sessions/' | grep -v '/hermes-agent/' | sort`

### Phase 5: 终验
- 零分类目录残留：所有 `skills/*/` 下都有 SKILL.md
- 引用残留：`grep -rl 'skills/openclaw\|skills/openclaw-dept\|skills/openclaw-hub' [filters]` -> 零
- 技能数量和计算：51(old openclaw skills) + 87(category skills) = 138(+ 映射索引.md) = 139 skills

## 关键坑点

### Pipe-bleeding bug
当用 patch 修改 markdown 表中的单元格且 old_string 以 `||` 开头（空左侧单元格）时，patch 工具会添加多余的 `|` 前缀，导致表格列错位。
**解法**：第一次 patch 后手动检查 diff，用第二次 patch 修复多余的 `|`。

### 属于软件包的文件不要改
`hermes-agent/` 下的路径引用（docs 里的 skills/creative/xxx.md URL、skills_tool.py 里的注释）是 Hermes Agent 发行版的一部分，不代表用户文件的残留引用。用 grep 时务必用 `grep -v '/hermes-agent/'` 过滤。
