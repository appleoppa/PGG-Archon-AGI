# GitHub Factory Status

## Repository
- **Owner**: appleoppa
- **Repo**: hermes-github-evolution
- **Workflow**: `.github/workflows/evolve.yml`

## Inbox Directory
```
~/.hermes/workspace/github-evolution/inbox/
```

## Recent Results (as of 2026-05-21)
- `awakening_gate_20260520_023246.json` (latest)
- `awakening_gate_20260520_011920.json`
- `evolution_result_20260519_165543.json`

## Token Access
- GitHub token stored in GitHub Secrets (not in current environment)
- Current environment can READ inbox results without token
- GitHub Actions workflow uses token to push results

## Usage in 开智 Cycle
```python
INBOX_DIR = '~/.hermes/workspace/github-evolution/inbox/'
# Read latest results for evidence synthesis
```
