# EVM v1.2 Bug Fixes Detail

## Bug 1: 八卦多乘

**Problem**: Original formula multiplied 8 factors including Bagua, but the correct formula should only have 7 ancient factors.

**Root cause**: v1.1 code had:
```python
ancient_product = (
    self.TaoTeChing * self.IChing * self.HuangDi * 
    self.HeTuLuoShu * self.GanZhi * self.WuXing * self.Bagua  # BUG: 8 factors
)
```

**Fix**: Remove Bagua from multiplication:
```python
ancient_product = (
    self.TaoTeChing * self.IChing * self.HuangDi * 
    self.HeTuLuoShu * self.GanZhi * self.WuXing  # Correct: 7 factors
)
```

**Impact**: When all factors = 1.0, no visible difference. But when any ancient factor < 1.0, the bug causes incorrect EVM reduction.

## Bug 2: Defect Rate Simple Average

**Problem**: v1.1 used simple average `sum(defects) / 12`, ignoring the "short board" effect.

**Fix**: Implement penalty mechanism:
```python
avg_defect = sum(defect_values) / len(defect_values)
max_defect = max(defect_values)
# Non-linear penalty: short board affects more when > 0.5
max_penalty = 0.15 * (max_defect ** 1.5)
total_defect_rate = avg_defect * 0.5 + max_penalty
```

## Bug 3: Ancient Wisdom Cap at 1.0

**Problem**: `apply_ancient_wisdom()` had `min(1.0, new_value)`, preventing enhancement above 1.0.

**Fix**: Allow soft cap at 2.0:
```python
new_value = current * (1 + intensity * self.boost_coeff)
setattr(self, attr, min(2.0, new_value))  # Soft cap, not hard cap
```

## Verification

```python
# Base EVM should be 0.7691
E, V, M, A, Base = 0.92, 0.88, 0.95, 1.0, 1.0
modern = E * V * M * A * Base  # = 0.7691
ancient = 1.0 ** 6  # = 1.0 (7 factors)
EVM = modern * ancient * 1.0  # = 0.7691 ✓
```
