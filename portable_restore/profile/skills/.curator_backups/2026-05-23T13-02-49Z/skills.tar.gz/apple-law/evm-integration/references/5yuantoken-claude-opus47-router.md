# 5yuantoken Claude Opus 4.7 + 河图洛书 Router Integration

Session-derived provider details for adding Claude Opus 4.7 through 5yuantoken to the Hermes/河图洛书 stack.

## Verified provider facts

- Base URL for OpenAI-compatible calls: `https://5yuantoken.eu.cc/v1`
- Models endpoint: `https://5yuantoken.eu.cc/v1/models`
- Verified model id: `claude-opus-4-7`
- Recommended provider key: `claude_opus47_5yuantoken`
- Recommended env var: `CLAUDE_OPUS47_5YUANTOKEN_API_KEY`
- API mode: OpenAI-compatible `chat/completions`

## Safe key workflow

Ask the user to put the key in `~/.hermes/.env`; do not ask them to paste it into chat unless they explicitly choose that risk.

Suggested interactive shell pattern:

```bash
read -s CLAUDE_OPUS47_5YUANTOKEN_API_KEY
printf '\nCLAUDE_OPUS47_5YUANTOKEN_API_KEY=%s\n' "$CLAUDE_OPUS47_5YUANTOKEN_API_KEY" >> ~/.hermes/.env
chmod 600 ~/.hermes/.env
unset CLAUDE_OPUS47_5YUANTOKEN_API_KEY
```

Verify only key presence, never value.

## Super router placement

Recommended chain after integration:

```text
GPT5.5 主脑统筹
→ Claude Opus 4.7 深度反证
→ DeepSeek 快速反证
→ MiniMax 修复落地
→ GLM 旁证压缩
→ GPT5.5 主脑收束
```

When changing from five to six stages, update all coupled references:
- `HetuLuoshuSuperRouter.chain`;
- route function prompts/results keys;
- final `persist_gene()` references (`step6_主脑收束`, `step4_修复落地`);
- route metadata sequence text;
- status/check output expectations.

## Verification

1. Check `/v1/models` with the new key and confirm `claude-opus-4-7` appears.
2. Run syntax check on router script.
3. Run router `--check` to verify configured status.
4. Make a tiny real call such as `只回复：配置验证通过` and require non-empty user-facing text.

## Pitfalls

- 5yuantoken model id uses hyphens: `claude-opus-4-7`, not `claude-opus-4.7`.
- Use `/v1` base URL for OpenAI-compatible chat calls.
- Do not put `api_key: sk-...` in `config.yaml`; use `api_key_env: CLAUDE_OPUS47_5YUANTOKEN_API_KEY`.
- If a route chain is expanded but old step names remain in the execution body or persistence code, the router becomes inconsistent or errors later.