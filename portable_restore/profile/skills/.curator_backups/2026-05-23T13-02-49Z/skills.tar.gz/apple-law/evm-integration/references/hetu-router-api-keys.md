# 河图洛书 Router API Keys

## Environment Variable Names

| Provider | Model | Env Var |
|----------|-------|---------|
| 5yuantoken | gpt-5.5 | GPT55_5YUANTOKEN_API_KEY |
| DeepSeek | deepseek-v4-flash | DEEPSEEK_V4_FLASH_API_KEY |
| MiniMax | M2.7-highspeed | MINIMAX_M27_HIGHSPEED_API_KEY |
| Z.ai/GLM | glm-4.5-air | GLM45_AIR_API_KEY |

## API Endpoints (verified 2026-05-21)

| Provider | base_url | Full Path | Protocol |
|----------|----------|-----------|----------|
| 5yuantoken | `https://5yuantoken.eu.cc/v1` | `/chat/completions` | chat/completions |
| DeepSeek | `https://api.deepseek.com` | `/chat/completions` | chat/completions |
| MiniMax | `https://api.minimaxi.com/anthropic` | `/v1/messages` | anthropic messages |
| Z.ai/GLM | `https://open.bigmodel.cn/api/paas/v4` | `/chat/completions` | chat/completions |

> **DeepSeek**: base_url is `https://api.deepseek.com` (no `/v1` suffix). Full URL = `https://api.deepseek.com/chat/completions`. OpenAI-compatible format. Do NOT add `/v1` — that was the original bug causing all timeouts.
>
> **MiniMax**: base_url MUST end with `/anthropic` (not `/v1`). Router constructs full URL as `base_url + /v1/messages` = `https://api.minimaxi.com/anthropic/v1/messages`. Uses `x-api-key` header (NOT `Authorization: Bearer`).

## .env Loading

Keys are stored in `~/.hermes/.env` but Python does NOT auto-load them. The router now loads `.env` at module init. If running in a fresh subprocess, source `.env` first or set vars explicitly.

## Five-Stage Chain Roles

The 5yuantoken provider (gpt-5.5) returns garbled Chinese characters when using Python's `resp.json()` due to gzip compression.

**Wrong**:
```python
resp = requests.post(url, headers=headers, json=payload)
data = resp.json()  # Returns garbled Chinese
```

**Correct**:
```python
resp = requests.post(url, headers=headers, json=payload)
data = json.loads(resp.content)  # Parse bytes directly
```

## Five-Stage Chain Roles

| Stage | Role | Model |
|-------|------|-------|
| 1 | 主脑统筹 (Orchestration) | gpt-5.5 |
| 2 | 反证审错 (Counter-evidence) | deepseek-v4-flash |
| 3 | 修复落地 (Fix implementation) | MiniMax-M2.7 |
| 4 | 旁证压缩 (Side evidence) | glm-4.5-air |
| 5 | 主脑收束 (Final synthesis) | gpt-5.5 |
