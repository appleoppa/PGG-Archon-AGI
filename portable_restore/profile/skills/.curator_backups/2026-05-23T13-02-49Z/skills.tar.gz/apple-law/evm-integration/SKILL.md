---
name: evm-integration
version: 1.0.2
created: 2026-05-21
updated: 2026-05-21
description: EVM治理+河图洛书路由+GitHub工厂融入开智循环
purpose: EVM defect governance + 河图洛书 LLM router + GitHub factory integration
readiness_status: available
setup_needed: false
---

# EVM Integration Skill

## Trigger Conditions

- User asks to integrate EVM into the open-intelligence cycle
- User asks about 河图洛书 router or GitHub factory
- User says "落地必须要用" (must be actually used, not just documented)

## Core Components

### 1. EVM Formula (evm_formula.py)

**Location**: `~/.hermes/workspace/evm/evm_formula.py`

**Critical Bug Fixes (v1.2)**:

| Bug | v1.1 Problem | v1.2 Fix |
|-----|-------------|----------|
| 八卦多乘 | Multiplied 8 ancient factors (included Bagua) | Only 7 factors (TaoTeChing, IChing, HuangDi, HeTuLuoShu, GanZhi, WuXing) |
| Defect rate | Simple average | `avg × 0.5 + max^1.5 × 0.15` (短板 penalty) |
| Ancient wisdom cap | Hard cap at 1.0 | Soft cap at 2.0 |
| Boost coefficient | Fixed 0.1 | Configurable (default 0.15) |

**Formula**: `EVM = E×V×M×A×Base × 7古法 × (1 - defect_rate(含短板惩罚))`

**Defect → Ancient Wisdom Mapping**:
- ΔMem/ΔSoul → 黄帝内经
- ΔErr/ΔTok → 道德经
- ΔAgt/ΔRun → 易经
- ΔPan/ΔClw → 河图洛书
- ΔPrm/ΔNet → 天干地支
- ΔRes/ΔLog → 五行

### 2. 河图洛书 LLM Router (hetu_luoshu_llm_router.py)

**Location**: `~/.hermes/workspace/evm/hetu_luoshu_llm_router.py`

**4-Model Five-Stage Chain**:

| Step | Role | Model | Environment Variable |
|------|------|-------|---------------------|
| 1 | 主脑统筹 | gpt-5.5 | GPT55_5YUANTOKEN_API_KEY |
| 2 | 反证审错 | deepseek-v4-flash | DEEPSEEK_V4_FLASH_API_KEY |
| 3 | 修复落地 | MiniMax-M2.7-highspeed | MINIMAX_M27_HIGHSPEED_API_KEY |
| 4 | 旁证压缩 | glm-4.5-air | GLM45_AIR_API_KEY |
| 5 | 主脑收束 | gpt-5.5 | GPT55_5YUANTOKEN_API_KEY |

**API Endpoints (verified 2026-05-21)**:
- gpt-5.5: `https://5yuantoken.eu.cc/v1`
- deepseek: `https://api.deepseek.com`
- MiniMax: `https://api.minimaxi.com/anthropic` ← CORRECT (uses anthropic messages API)
- GLM: `https://open.bigmodel.cn/api/paas/v4`

> **MiniMax Critical Fix**: `base_url` must be `https://api.minimaxi.com/anthropic` NOT `/v1`. The working endpoint is `base_url + /v1/messages` = `https://api.minimaxi.com/anthropic/v1/messages`. The router uses anthropic messages mode for MiniMax.

**Critical Encoding Fix**: The 5yuantoken provider returns garbled Chinese when using `resp.json()`. Must use:
```python
data = json.loads(resp.content)  # NOT resp.json()
return data['choices'][0]['message']['content']
```

### Claude Opus 4.7 via 5yuantoken

Verified add-on provider for deep counter-evidence:
- provider key: `claude_opus47_5yuantoken`
- env var: `CLAUDE_OPUS47_5YUANTOKEN_API_KEY`
- base URL: `https://5yuantoken.eu.cc/v1`
- model: `claude-opus-4-7`
- mode: OpenAI-compatible `chat/completions`

If added to the super router, expand the five-stage chain to six stages: GPT5.5 → Claude Opus 4.7 → DeepSeek → MiniMax → GLM → GPT5.5. Update chain declaration, route prompts/results keys, persistence step references, and metadata together; do not only change the chain list. See `references/5yuantoken-claude-opus47-router.md`.

### 3. GitHub Factory (github_factory.py)

**Location**: `~/.hermes/workspace/evm/github_factory.py`
**Repo**: `appleoppa/hermes-github-evolution`
**Workflow**: `.github/workflows/evolve.yml`

Can read inbox results without GitHub token in current environment (token stored in GitHub Secrets):
```python
INBOX_DIR = '~/.hermes/workspace/github-evolution/inbox/'
```

### 4. Integrated Executor (oel_evm_integrated.py)

**Location**: `~/.hermes/workspace/evm/oel_evm_integrated.py`

Integrates all three systems into the open-intelligence cycle:

| Step | Gate | Component |
|------|------|-----------|
| 1 | 公式审错门 | EVM self-check |
| 2-4 | 序列代入 | Defect exposure |
| 5 | EVM缺陷治理门 | Ancient wisdom empowerment |
| 6-8 | 路由+学习+反证 | 河图洛书 + GitHub factory |
| 9 | 补齐+回测 | EVM backtest + verification |

## Execution

```bash
cd ~/.hermes/workspace/evm
python3 oel_evm_integrated.py --full  # Full cycle
```

## Pitfalls

1. **5yuantoken encoding**: Always use `json.loads(resp.content)` not `resp.json()`
2. **API key env vars must be loaded from `~/.hermes/.env`**: Keys are stored in `.env` but NOT automatically loaded by Python's `os.environ`. The router loads `.env` at module init — but if running in a fresh subprocess, set env vars explicitly or source `.env` first.
3. **MiniMax base_url**: Must be `https://api.minimaxi.com/anthropic` — NOT `/v1`. Router constructs endpoint as `base_url + /v1/messages`. Uses `x-api-key` header, not `Authorization: Bearer`.
4. **5yuantoken special headers**: This provider intercepts certain default request headers. Router sets `User-Agent: Mozilla/5.0...` and `X-Request-Id: hetu-luoshu-router`.
5. **DeepSeek base_url**: Must be `https://api.deepseek.com` — NO `/v1` suffix. Original timeout bug was caused by using `https://api.deepseek.com/v1/chat/completions`. Correct path is `https://api.deepseek.com/chat/completions`.
6. **EVM ancient factors**: Only 7, not 8 (Bagua is not included in multiplication)
7. **MiniMax/GLM empty-body trap**: Some reasoning models may return only `thinking`/`reasoning_content` when `max_tokens` is too low. A successful HTTP 200 is not enough. Router outputs must pass an effective-output gate: non-empty user-facing text with conclusion/evidence/defect/repair, otherwise retry with higher token budget, disable thinking where supported, or mark the step invalid.
8. **Route necessity gate**: Do not default every task into the multi-model chain. First judge complexity/risk/uncertainty. Low-risk simple tasks use the main model directly; high-risk, factual, legal, config, or evolution tasks enter GPT5.5 → DeepSeek → MiniMax → GLM → GPT5.5.

## Super Router Script

**Location**: `~/.hermes/workspace/evm/hetu_luoshu_super_router.py`

Use for real four-model self-evolution runs:
```bash
cd ~/.hermes/workspace/evm
python3 hetu_luoshu_super_router.py --check      # key/model status only, no secrets
python3 hetu_luoshu_super_router.py --persist    # run route and write evolution gene
```

Verification expectations:
- all four providers configured;
- all five stages return valid text, not only transport success;
- result JSON written under `router_runs/`;
- one cycle/gene/verification row written to `apex_evolution_genes.sqlite3` when `--persist` is used.
