# EVM Integration 当前状态 (2026-05-21 Updated)

## 执行结果

| 步骤 | 组件 | 状态 | 备注 |
|------|------|------|------|
| 1 | EVM自检 | ✅ 通过 | EVM=0.7691 |
| 2-4 | 序列代入 | ✅ 通过 | ΔMem=0.25, ΔErr=0.15 |
| 5 | 古法赋能 | ✅ 通过 | 因子 1.0→1.1234 |
| 6-8 | GitHub工厂 | ✅ 通过 | 读取3个inbox文件 |
| 6-8 | 河图洛书五段链 | ✅ 4/5成功 | gpt-5.5✅ MiniMax✅ GLM✅ DeepSeek🔴503超时 |
| 9 | 补齐+回测 | ✅ 通过 | EVM→0.8511 |

## ✅ 已修复项 (2026-05-21 本轮)

1. ✅ EVM公式v1.2（4个bug已修复）
2. ✅ GitHub工厂读取（无需token）
3. ✅ 5yuantoken编码问题（`json.loads(resp.content)`）
4. ✅ `.env`加载（路由器头部自动加载）
5. ✅ MiniMax endpoint（`https://api.minimaxi.com/anthropic`）
6. ✅ 5yuantoken header重写（User-Agent + X-Request-Id）
7. ✅ DeepSeek 503 retry（等待3秒后重试一次）

## DeepSeek 剩余问题

DeepSeek 返回 503 / read timeout 是其API服务自身不稳定，非配置错误。已在路由器加503 retry机制。超时不阻塞整体流程，可接受降级。

## 关键文件路径

| 文件 | 路径 |
|------|------|
| EVM核心引擎 | `~/.hermes/workspace/evm/evm_formula.py` |
| 河图洛书路由器 | `~/.hermes/workspace/evm/hetu_luoshu_llm_router.py` |
| GitHub工厂 | `~/.hermes/workspace/evm/github_factory.py` |
| 集成执行器 | `~/.hermes/workspace/evm/oel_evm_integrated.py` |
| .env | `~/.hermes/.env` |

## 执行结果

| 步骤 | 组件 | 状态 | 备注 |
|------|------|------|------|
| 1 | EVM自检 | ✅ 通过 | EVM=0.7691 |
| 2-4 | 序列代入 | ✅ 通过 | ΔMem=0.25, ΔErr=0.15 |
| 5 | 古法赋能 | ✅ 通过 | 因子 1.0→1.1234 |
| 6-8 | GitHub工厂 | ✅ 通过 | 读取3个inbox文件 |
| 6-8 | 河图洛书五段链 | 🔴 **失败** | 4个模型全部报 API key 缺失 |
| 9 | 补齐+回测 | ✅ 通过 | EVM→0.8511 |

## 🔴 卡点：环境变量未配置

当前执行环境中以下变量为空：

```
GPT55_5YUANTOKEN_API_KEY=        # gpt-5.5
DEEPSEEK_V4_FLASH_API_KEY=       # deepseek-v4-flash
MINIMAX_M27_HIGHSPEED_API_KEY=   # MiniMax-M2.7-highspeed
GLM45_AIR_API_KEY=               # glm-4.5-air
```

这些 key_env 名称定义在 `config.yaml` 的 providers 配置中，但当前 shell 环境里没有对应的环境变量。

## 已知修复项

1. ✅ EVM公式v1.2（4个bug已修复）
2. ✅ GitHub工厂读取（无需token）
3. ✅ 5yuantoken编码问题（`json.loads(resp.content)` 已应用）
4. ⏳ 4个API key环境变量注入（需要设置）

## 路由查找key的逻辑

`hetu_luoshu_llm_router.py` 第47-49行：
```python
api_key = cfg['api_key']  # 从模型配置中读取
if not api_key:
    return f"[错误] 未配置API key: {provider}"
```
cfg 是从 `os.environ.get('GPT55_5YUANTOKEN_API_KEY', '')` 获取的。

## 下一步

需要确认：API Key 是由 Hermes 系统统一注入（通过 gateway/profile 机制），还是需要手动 `export` 到 shell 环境。
