---
name: quantum-channel-router
description: 量子通道路由 — Rust 实现的多模型智能路由引擎，支持分级路由、健康检查、轨迹缓存
version: 1.2.0
author: Hermes Agent
trigger_conditions:
  - 用户下达任何涉及多步骤、复杂推理或法律分析的任务
  - 用户下达代码开发、分析、研究、写作或办案任务
  - 任何非纯聊天的实质性任务（任务涉及执行、生成、分析、研究）
  - 当当前模型能力不足或用户对输出质量不满时考虑切换模型
metadata:
  hermes:
    tags: [router, routing, llm, trajectory, cache, quantum, rust]
---

# 量子通道路由 (Quantum Channel Router)

## 架构概览

Rust 实现的 LLM 多模型路由引擎。核心路由由 Hermes 主脑决策，量子路由器作为多任务配套工具提供分级路由、健康监控和轨迹缓存。

**安装路径**: `~/.hermes/quantum-router/`
**CLI 命令**: `qr`

## ⚠️ 加载此 skill 时的强制指令

当你（Hermes Agent）加载这个 skill 时，必须遵守以下规则。

### 入口规则

**在接受用户任务后、开始执行前，先调用 `qr route "<任务描述>"` 决定使用哪个 LLM。** 这条绝对不能跳过。2026-05-22 因跳过被用户指出，已记入违规记录。

具体流程：
1. 解析用户任务 → 提取任务关键词
2. 调用 `terminal("qr route '<任务描述>'")` 获取 JSON 输出
3. 解析 JSON 中的 `selected`（provider 名）和 `tier`（分级）
4. **如果返回 cache 结果**（`source: "cache"`），直接复用缓存轨迹
5. **否则**按路由结果使用对应 provider 执行任务
6. 成功后调用 `qr cache set <fingerprint> "<trajectory_json>"` 存入轨迹

**不使用此 skill 时 → 用默认 LLM（当前 default profile 的模型，通常是 gpt-5.5）**

### 选型冲突规则

当 `qr route` 返回的 provider 与当前会话 model 不一致时，**不强制切换 provider**。
qr 的 health check 决策与 Hermes 实际路由是两条独立路径。qr 用作辅助决策参考：

| 场景 | 处理策略 |
|------|---------|
| qr 返回其他可用 provider | 将 qr 结果作为**建议**记录，本次继续使用当前会话 model |
| qr 返回同 provider 同 model | 继续使用当前会话，记录"路由匹配" |
| qr 全部 offline | 不更改选型，继续使用当前会话 model |

### 进化循环中的使用

在开智进化循环（manual-evolution-loop）中，`qr route` 在公式审错前执行。
当进行 APEX 三顺序代入（21354/12534/14325）时：

- **每遍必须产生**：代入点、触发判断、暴露信号、本遍观察
- **最少遍数**：每个顺序至少 **3遍**（用户确认的标准，低于此数会被退回）

## Web UI Profile 关系说明

量子路由是**我（Hermes Agent）自动调用的决策引擎**，与 Web UI 的手动 Profile 选择是两条独立路线：

| 路线 | 谁决定 | 使用场景 |
|------|--------|---------|
| Web UI Profile | 你手动切换到 gpt55 Profile | 你想固定用某个模型聊天 |
| 量子路由 `qr route` | 我自动按任务分类选 | 你说任务，我分配合适的 LLM |

**互不干扰**：Web UI 选了什么 Profile 不影响我调用 `qr route` 的能力。我可以在使用 gpt55 Profile 的 Web UI 会话中，仍然通过 `qr route` 为 subagent 选择其他 LLM。

## 分级路由 (A/B/C/D)

| 分级 | 用途 | 模型 | 说明 |
|------|------|------|------|
| **A** 🟢 | 基础通行 | MiniMax-M2.7-highspeed | 稳定低成本的默认通道 |
| **B** 🔵 | 高端推理 | gpt-5.5, deepseek-v4-flash | 复杂推理、分析、逻辑 |
| **C** 🟣 | 深度代码开发 | claude-opus-4-7 | 代码编写、重构、调试 |
| **D** ⚪ | 低成本处理 | glm-4.5-air | 翻译、格式化、摘要等简单任务 |

自动分类逻辑（关键词匹配）：
- **C-代码**: 代码/code/debug/compile/重构/refactor/Rust/python/java/写/编程/程序/implement/开发/函数/function/算法/algorithm
- **B-推理**: 推理/reason/分析/复杂/复杂推理/数学/math/逻辑/logic/研究/论证/策略/plan/设计/架构
- **D-廉价**: 简单/simple/翻译/format/格式化/draft/草稿/摘要/summary/列举/列出来
- **默认**: → A (MiniMax) 或降级到 D (GLM)

## CLI 命令

```bash
# 健康检查所有 LLM
qr health

# 按任务描述自动路由
qr route "写一个Rust HTTP服务器"

# 指定分级
qr tier C

# 轨迹缓存
qr cache set <fingerprint> "<trajectory_json>"
qr cache get <fingerprint>
qr cache stats

# 查看路由配置
qr config
```

## Agent 工作流集成（每次任务自动执行）

```python
from hermes_tools import terminal
import json

# 1. 路由决策
result = terminal(f"qr route '{task_description}'")
route = json.loads(result["output"])

if route.get("source") == "cache":
    # 缓存命中 → 直接复用轨迹
    trajectory = route["cached_trajectory"]
    # ...复用逻辑...
else:
    selected_provider = route["selected"]
    model = route["model"]
    tier = route["tier"]
    print(f"量子路由: {tier}级 → {selected_provider} ({model})")
    # ...按路由结果执行任务...

# 2. 成功执行后缓存
fp = terminal("python3 -c \"import hashlib; print(hashlib.sha256((task+tier).encode()).hexdigest())\"")
terminal(f"qr cache set {fp.strip()} '{json.dumps(trajectory)}'")
```

## 缓存架构

轨迹指纹 = SHA256(task + tier)

缓存位置：`~/.hermes/quantum-router/cache/<fingerprint>.json`

缓存条目包含：fingerprint, trajectory JSON, created timestamp, hit_count

## 核心公式

```
ΔG = (C_total · Λ_gene · Ω_entropy · τ_traj) / (H_info · t)
```

**τ_traj** = 完整轨迹生成效率系数，代表 Agent 一次性任务闭环能力。

## 故障排错

### 健康检查全报 auth_error（即使 Hermes 正常使用）

**根因**：Hermes profile 机制会改写 `$HOME` 环境变量（如 `/Users/appleoppa/.hermes/profiles/deepseek-v4/home/`），导致 qr 的 `load_env_keys()` 读取 `$HOME/.hermes/.env` 时路径不存在，拿不到 API key → 全报 auth_error。

**修复**：2026-05-22 已修改 `src/health.rs`，同时尝试 `$HOME` 和 `/Users/$USER` 两个路径读取 `.env`，自动去重。需重新编译并覆盖二进制：
```bash
cd ~/.hermes/quantum-router && cargo build --release
cp target/release/qr ~/.cargo/bin/qr
```

### MiniMax A-tier 持续 not_supported（2026-05-23 修复）

**现象**：qr health 对 MiniMax 始终返回 `not_supported`，导致 A-tier 任何路由都降级到 D-tier (GLM)。

**根因**：MiniMax 的 base_url 配的是 anthropic-compatible 端点 `https://api.minimaxi.com/anthropic`，这个端点**没有 `/models` 接口**。qr 的健康检查用 `GET {base_url}/models` → 404 → `not_supported`。

**修复**：`src/health.rs` 中对 MiniMax provider 改用 `POST https://api.minimaxi.com/v1/chat/completions` 发最小请求（`max_tokens:1`）。MiniMax 的 OpenAI-compatible 接口正常工作，anthropic 兼容接口没有 models/messages 端点。

```rust
// health.rs 中 MiniMax 专用处理
if is_minimax {
    let body = serde_json::json!({
        "model": p.model,
        "max_tokens": 1,
        "messages": [{"role": "user", "content": "hi"}]
    });
    let mm_url = "https://api.minimaxi.com/v1/chat/completions";
    req = c.post(mm_url).json(&body);
    req = req.header("Authorization", format!("Bearer {}", api_key));
}
```

**验证**：`qr health` 返回 `minimax_m27_highspeed: ok`，延迟 ~1s。`qr route "默认任务"` 返回 A-tier 选中 MiniMax，无降级。

**修复**：2026-05-23 修改 `src/health.rs`，对 MiniMax 改用 `POST https://api.minimaxi.com/v1/chat/completions`（OpenAI 兼容端点）发送最小请求 `{"model":"MiniMax-M2.7-highspeed","max_tokens":1,"messages":[{"role":"user","content":"hi"}]}`，Authorization: Bearer。verfiy_response后标记 ok 可用。

```bash
cd ~/.hermes/quantum-router && cargo build --release
cp target/release/qr ~/.cargo/bin/qr
```

### 5yuantoken 提供商健康检查返回 down（非 auth_error）

**根因**：5yuantoken 为第三方代理供应商，其 `/models` 端点在标准 curl 测试中正常返回 200，但 qr 的 reqwest Client 默认 headers 可能触发其防护机制返回 4xx。2026-05-23 两批进化共 26 轮中，批次 2 连续 8 轮（R1-R8）报告 "5yuantoken双DOWN"，但实际为临时服务中断，后自愈（`qr health` 恢复为 ok）。该标签已标记 24+ 轮，但属于环境事实而非可修复配置问题。

**诊断**：执行 `curl -s -o /dev/null -w '%{http_code}' "https://5yuantoken.eu.cc/v1/models" -H "Authorization: Bearer $KEY"`。若返回 200 则服务正常；若超时则供应商级中断。

**解决**：若持续不可用，用户需决策更换供应商或修改 reqwest Client default_headers。

### MiniMax 健康检查修复（2026-05-23）

**背景**：MiniMax M2.7 API 有两个协议入口：
- `https://api.minimaxi.com/anthropic/` — Anthropic 协议（`/messages` 和 `/models` 均返回 404）
- `https://api.minimaxi.com/v1/` — OpenAI-compatible 协议（`/chat/completions` 可用）

qr 代码原使用 `GET {base_url}/models` 做健康检查，MiniMax 的 base_url 指向 anthropic 端点 → 404 → `not_supported` → A-tier 持续断链。

**修复**（2026-05-23 `src/health.rs`）：对 MiniMax 单独使用 `POST https://api.minimaxi.com/v1/chat/completions` 发送最小请求（model=MiniMax-M2.7-highspeed, max_tokens=1, messages=["hi"]）测试 API 可用性。健康检查通过后 A-tier 恢复正常。

修复验证：
```bash
qr health | jq '.[] | select(.name=="minimax_m27_highspeed") | .status'
# 修复前: "not_supported"
# 修复后: "ok" (latency ~1s)

qr route "默认任务"
# → tier=A, selected=minimax_m27_highspeed, fallback=None
```

**如再次断链**：检查 `health.rs` 中 `mm_url` 常量是否仍为 `https://api.minimaxi.com/v1/chat/completions`。MiniMax 可能更新了 API 入口。重新编译：`cd ~/.hermes/quantum-router && cargo build --release && cp target/release/qr ~/.cargo/bin/qr`。

## 降级策略

当首选 LLM 不可用时，自动降级：A→D, B→A, C→B, D→A → 扫全部可用
