# OpenClaw Multi-Agent → Hermes SKILL.md Mapping

This reference documents the concrete mapping from OpenClaw AutoClaw's 14 sub-agent hierarchy to Hermes SKILL.md files + delegate_task dispatch. Used as an example for the multi-agent-replication skill.

## Architecture

```
OpenClaw                             Hermes
─────────                           ──────
main (苹果中枢) → dispatch tree     → apple-hub-orchestrator SKILL.md
├── an-guan (案件管理中心)          → agent-cms SKILL.md
├── min-shi (民事案件部)            → civil-litigation SKILL.md
│   ├── 01-contract-dispute        → migration/skills/civil/01* (reference)
│   ├── 02-tort-dispute            → migration/skills/civil/02*
│   ├── 03-construction            → migration/skills/civil/03*
│   ├── 04-labor-dispute           → migration/skills/civil/04*
│   ├── 05-property                → migration/skills/civil/05*
│   ├── 06-marriage-family         → migration/skills/civil/06*
│   └── 07-property-rights         → migration/skills/civil/07*
├── xing-shi (刑事案件部)          → criminal-defense SKILL.md
│   ├── 01-theft-fraud             → migration/skills/criminal/01*
│   ├── 02-traffic-accident        → migration/skills/criminal/02*
│   ├── 03-drug-related            → migration/skills/criminal/03*
│   ├── 04-violent-crime           → migration/skills/criminal/04*
│   └── 05-white-collar            → migration/skills/criminal/05*
├── fei-su (非诉业务部)            → non-litigation SKILL.md
├── zhi-xing (强制执行部)          → enforcement SKILL.md
│   ├── 01-property-investigation  → migration/skills/enforcement/01*
│   ├── 02-execution-objection     → migration/skills/enforcement/02*
│   └── 03-execution-appeal        → migration/skills/enforcement/03*
├── gu-wen (法律顾问部)            → legal-advisor SKILL.md
├── tui-yan (案件推演部)           → case-simulation SKILL.md
├── law (律法支持部)               → legal-support SKILL.md
├── wen-shu (文书机要部)           → document-review SKILL.md
├── zhi-nao (智脑知识部)           → knowledge-center SKILL.md
├── yun-wei (运行维护部)           → operations SKILL.md
├── xun-shi (苹果巡视组)           → inspection-team SKILL.md
├── shen-ji (苹果审计组)           → audit-team SKILL.md
└── jing-cai (体育大师)            → sports-master SKILL.md
```

## Department Timeout Mapping

| Department | timeout | Call Type |
|-----------|---------|-----------|
| law (legal-support) | 300s | Sync |
| xun-shi (inspection-team) | 300s | Parallel |
| shen-ji (audit-team) | 300s | Parallel |
| wen-shu (document-review) | 240s | Async |
| All others | 240s | Async/Sync |

## Dispatch Flow (from apple-hub-orchestrator)

```
Case Type → Department SKILL → delegate_task(skills=[department])
                                       ↓
                              Child session loads department SKILL.md
                                       ↓
                              Department executes its workflow
                                       ↓
                              If auxiliary help needed → REQ protocol
                                       ↓
                              xun-shi parallel inspection
                                       ↓
                              shen-ji final audit
                                       ↓
                              Return results to hub
```

## Key Transfer Rules (from AGENTS.md R rules)

- R4.1: Hub dispatches only, never self-executes
- R37: Criminal+detention<30d → red priority (interrupt non-urgent); any case+hearing/deadline<7d → yellow priority
- R46: Instinct self-awareness — if confidence <0.7, say "不确定"
- R55: Hub must NOT assign case numbers — only an-guan (agent-cms) does
- R31 B1/B2: Error memory solidification — record errors, auto-promote to permanent rule on 2nd recurrence

## File Preservation Priority (per agent directory)

```
[{agent}/workspace/]  → ~/.hermes/agents/{id}/workspace/
  SOUL.md              # Who this agent is
  MEMORY.md            # Memory index + error records
  AGENTS.md            # Behavioral rules
  IDENTITY.md          # Identity record
  HEARTBEAT.md         # Health status
  USER.md              # User profile
  TOOLS.md             # Tool usage guide
  SKILL.md             # Department-specific skill
  CLAUDE.md            # Additional instructions
  agent_manifest.json  # Agent manifest
  skills/知识路由/     # Knowledge routing rules
  config/              # MCP configuration

[{agent}/agent/]       → ~/.hermes/agents/{id}/agent/
  models.json          # Model configuration
  auth-profiles.json   # Authentication profiles

[{agent}/sessions/]    → ~/.hermes/agents/{id}/sessions/
  sessions.json        # Session index
  *.jsonl              # Session transcripts
```

## Hub Dispatch Templates

### New Case Flow
```
Step 1: an-guan → delegate_task(skills=[agent-cms]) + goal="申请案件编号"
Step 2: dept   → delegate_task(skills=[civil-litigation]) + goal="处理案件PGQ-XXX"
Step 3: xun-shi → delegate_task(skills=[inspection-team]) + goal="巡视效验节点①"
Step 4: shen-ji → delegate_task(skills=[audit-team]) + goal="审计审查"
```

### Quick Answer (轻桥层/Lightweight Bridge)
```
No delegate_task — hub answers directly if:
- Question ≤100 chars
- Simple legal judgement, no complex analysis
- No PGG case number involved
- Low risk
- User prefixed with "快问：" or "quick："
```
