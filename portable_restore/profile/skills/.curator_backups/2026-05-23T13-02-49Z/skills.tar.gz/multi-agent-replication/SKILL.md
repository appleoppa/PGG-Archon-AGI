---
name: multi-agent-replication
version: "1.0.0"
description: 将多智能体层级复制为Hermes SKILL.md
metadata:
  {
    "category": "openclaw",
    "tags": ["replication", "migration", "orchestration", "sub-agent", "delegate_task", "skill-mapping"],
    "patterns": ["role-to-skill", "hub-orchestrator", "dispatch-via-task"],
    "related_skills": ["subagent-driven-development", "apple-hub-orchestrator"]
  }
---

# Multi-Agent Replication

> Replicate an existing multi-agent hierarchy (N sub-agents + 1 hub) as Hermes SKILL.md files dispatched via delegate_task. The real value is the data, knowledge, rules, and configuration — not the framework.

## When to Use

Apply this skill when:
- You have an existing multi-agent system (OpenClaw, AutoGPT, CrewAI, etc.) that you want to replicate in Hermes
- The source system has N specialized sub-agents with distinct roles, rules, and knowledge
- You want to use Hermes-native constructs (SKILL.md + delegate_task) instead of spawning separate agent processes
- You need to preserve the sub-agents' rules, knowledge, and workflows — the "real wealth"

## The Replication Pattern

The core insight: **each sub-agent in the old system becomes a SKILL.md file in Hermes**. The SKILL.md carries the sub-agent's role, rules, dispatch instructions, and timeout config. A "hub orchestrator" SKILL.md acts as the unified entry point that dispatches work via `delegate_task(skills=[...])`.

### Three Layers

```
Layer 1: Hub Orchestrator SKILL.md
  → One skill that owns dispatch logic, knows all sub-skills
  → Loaded by the user-facing agent on startup

Layer 2: Sub-agent SKILL.md files (one per role)
  → Each carries the sub-agent's identity, rules, timeout, knowledge paths
  → Loaded by delegate_task child sessions before work begins

Layer 3: Data/Knowledge/Config on disk
  → Stored in ~/.hermes/workspace/ or ~/.hermes/migration/
  → Referenced by SKILL.md via relative paths
  → The "real wealth" — rules, knowledge, evolution data, configs
```

### Step-by-Step Process

#### Step 1: Audit the Source System

Before writing any SKILL.md, exhaustively catalog the source system:

```
Command: find /path/to/source -not -path '*/.DS_Store' -type f | wc -l
```

1. Count all files in the source
2. Group by category: agents/, skills/, config/, knowledge/, logs/, etc.
3. Identify each sub-agent's:
   - Role / purpose (1-2 sentence)
   - Rules / AGENTS.md content
   - Identity / SOUL.md definition
   - Memory / MEMORY.md index
   - Skills it owns
   - Workflows it can run
4. Identify the hub's dispatch algorithm (case routing rules, priority)

**Use iterative gap analysis** — don't assume the first pass is complete:
```bash
# Verify completeness: comm -23 compares source vs destination file lists
comm -23 <(find /source -type f | sort) <(find /destination -type f | sed 's|/dest/|/source/|' | sort)
```
Run this multiple times with increasingly detailed groupings to ensure nothing is missed.

#### Step 2: Map Each Sub-Agent to a SKILL.md

Each SKILL.md follows this structure:

```yaml
---
name: <skill-name>
version: "1.0.0"
description: <single-line description of this sub-agent's role>
metadata:
  {
    "openclaw": {
      "original_id": "<source agent ID>",
      "timeout": "<timeout in seconds>",
      "capabilities": ["<key capabilities>"]
    },
    "category": "<category>",
    "tags": ["<tags>"]
  }
---

# <Skill Name>

> <Role definition, 1-2 sentences>

## Role

What this sub-agent does, who it reports to, who it collaborates with.

## Rules

Key rules extracted from the source AGENTS.md, adapted for delegate_task context.

### Absolute Prohibitions
- Rule 1
- Rule 2

## Dispatch Instructions

How the hub should delegate to this skill. Include:
- When to dispatch (trigger conditions)
- What context to provide
- Expected output format
- Timeout

## Input/Output

What context the hub must provide, what deliverables to expect.

## Knowledge Paths

Relative paths to knowledge this sub-agent references:
- `../../../workspace/智库/` (read-only knowledge base)
```

**Frontmatter metadata matters** — it carries the original agent ID and timeout so the hub can query it programmatically.

#### Step 3: Create the Hub Orchestrator SKILL.md

The hub orchestrator is the user's primary entry point. It defines:

1. **Two processing paths**: quick-answer (轻桥层/lightweight bridge) vs full-process dispatch
2. **Routing table**: case type → sub-agent skill name
3. **Dispatch templates**: delegate_task invocation patterns for each flow
4. **Quality gates**: what to check before/after dispatch
5. **Absolute prohibitions**: what the hub must NOT do (e.g., self-execute, bypass case management)

```python
# Dispatch template
result = delegate_task(
    goal=f"Handle task: {description}",
    context=f"""Task details: {details}
Role-specific rules loaded via skills=[...]
""",
    skills=["<sub-agent-skill-name>"],
    toolsets=["terminal", "file", "web"]
)
```

#### Step 4: Migrate Data Separately from Framework

The user's priority: **data, rules, knowledge, configuration > framework**.

1. Copy all data files to ~/.hermes/workspace/ or ~/.hermes/migration/ FIRST
2. Create the SKILL.md files SECOND
3. Do NOT embed API keys, credentials, or instance-specific config in SKILL.md — those belong in Hermes config files or .env

#### Step 5: Verify Completeness with Multi-Pass Gap Analysis

After migration, run multi-pass verification:

```bash
# Pass 1: Total file count
find /source -type f | wc -l
find /dest -type f | wc -l

# Pass 2: Category-by-category count (use grouping)
find /source -path "*/agents/*" -type f | wc -l
find /dest -path "*/agents/*" -type f | wc -l

# Pass 3: Critical file existence check
for f in SOUL.md MEMORY.md AGENTS.md IDENTITY.md; do
  test -f "/dest/path/$f" && echo "$f=YES" || echo "$f=NO"
done

# Pass 4: Path-mapped diff (accounts for different directory structures)
comm -23 <(find /source -type f | sort) \
         <(find /dest -type f | sed 's|/dest/|/source/|' | sort) | head -50

# Pass 5: Content integrity check (size comparison)
for f in critical-files.txt; do
  src_size=$(wc -c < "/source/$f")
  dst_size=$(wc -c < "/dest/$f")
  test "$src_size" = "$dst_size" || echo "MISMATCH: $f"
done
```

**Key lesson**: Path-based comparison (comm -23) is unreliable when source and destination use different directory names. Always supplement with content-based verification (file size, or spot-check with md5).

## Department Storage Convention

Store the sub-agent SKILL.md files in a dedicated subdirectory under ~/.hermes/skills/:

```
~/.hermes/skills/
  openclaw/              # Original source skills (preserved as-is)
  openclaw-dept/         # Replicated sub-agent skills (one SKILL.md per sub-agent)
    agent-cms/
    civil-litigation/
    criminal-defense/
    ...
  openclaw-hub/          # Hub orchestrator skills
    apple-hub-orchestrator/
```

Data/knowledge/config goes under ~/.hermes/workspace/ or ~/.hermes/migration/:

```
~/.hermes/workspace/     # Active working data (cases, knowledge, evolution)
~/.hermes/migration/     # Archival copies (logs, cron history, team-rules, etc.)
~/.hermes/agents/        # Original agent session history and config
```

## Pitfalls

- **Don't just copy framework files** — the user's real wealth is in the data, rules, knowledge, and config. Prioritize those.
- **Don't miss sub-agent identity files** — SOUL.md, MEMORY.md, AGENTS.md, IDENTITY.md, HEARTBEAT.md, USER.md, CLAUDE.md are the sub-agent's "soul." Each one matters.
- **Don't skip secondary sub-agent skills** — min-shi had 7 sub-skills (contract-dispute, tort-dispute, etc.), xing-shi had 5, zhi-xing had 3. These are deep knowledge assets.
- **Don't assume a single pass is enough** — run gap analysis iteratively. The user will ask "还有吗" if you miss things.
- **Don't embed secrets in SKILL.md** — API keys, tokens, credentials belong in Hermes config or .env, never in skill files.
- **Don't upload deprecated/openclaw-specific template** — stay clean.

## References

- `references/openclaw-mapping.md` — Concrete mapping table showing the 14 sub-agent → SKILL.md mapping from the OpenClaw migration
