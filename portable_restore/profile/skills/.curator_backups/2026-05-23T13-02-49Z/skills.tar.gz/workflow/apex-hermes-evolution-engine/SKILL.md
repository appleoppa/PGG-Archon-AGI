---
name: apex-hermes-evolution-engine
description: Use when learning complex materials or improving Hermes workflows by turning real task traces, long context, search results, and subagent findings into verified reusable skills without fabricating external API or background evolution.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [apex, evolution, skills, memory, context, trajectory, subagents]
    related_skills: [manual-evolution-loop, hermes-evolution, search-skillbank, subagent-driven-development, file-system-management]
---

# APEX Hermes Evolution Engine

## Overview

本技能把 `/Users/appleoppa/Desktop/进化文件/` 的 14 份材料，加上 `/Users/appleoppa/Desktop/超级进化12-吞噬自进化.md`，融合为一个可执行的 Hermes 进化引擎。核心不是虚构“底层自动进化”或“多模型已调用”，而是把每次真实任务转成可验证、可复用、可审计的技能资产。

统一公式：

```text
真实上下文获取
→ 技能选择与任务拆解
→ 子智能体/工具执行
→ 结果验证与反幻觉审查
→ 价值感知压缩
→ 成功轨迹/失败轨迹沉淀
→ 技能库/记忆/规则更新
→ 下次任务复用
```

一句话：**检索获取事实，上下文提炼规则，记忆保存经验，轨迹驱动技能进化。**

## When to Use

使用场景：

- 用户要求“学习一批材料、举一反三、融会贯通、沉淀技能”。
- 长文档、复杂上下文、历史会话、项目轨迹需要提炼成可复用流程。
- 任务需要多 subagents 并行学习、审查、综合。
- 复杂检索、科研分析、系统优化、开智进化、技能库更新。
- 任务完成后出现可复用成功模式或高价值失败教训。

不要用于：

- 单句问答、简单翻译、一次性小修改。
- 无验证条件却要求声称“完整完成”的任务。
- 要求越权修改 Hermes / claw 核心、凭证、外部 API、长期后台服务的任务。
- 只凭愿景材料宣称已经实现 Rust/Go/C 底层能力或外部多模型调用。

## Core Principles

### 1. 技能化优先

复杂能力不要停留在临场随机推理，应拆成可触发、可执行、可验证的 Skill：

- 搜索技能：关键词扩写、实体溯源、时间限定、多源验证、上下文回溯。
- 上下文学习技能：从长材料中提炼原则、流程、触发条件、风险边界。
- 记忆技能：保存长期稳定、跨任务复用、可触发的信息。
- 轨迹技能：从成功和失败执行轨迹中提炼下一次可复用的路径。

### 2. Select-Read-Act-Review-Evolve

所有复杂任务采用统一骨架：

```text
Select：判断任务类型和应加载技能
Read：读取技能、文件、上下文、真实状态
Act：用工具或子智能体执行
Review：核验事实、输出、约束和副作用
Evolve：把可复用模式沉淀为技能、记忆或规则
```

### 3. 上下文学习目标是“生成技能”

读长文档不是只做摘要，而是生成可迁移的自然语言技能卡：

```text
输入材料
→ 多角度提问 / Challenger
→ 解题与规则抽取 / Reasoner
→ 质量审查 / Judge
→ 反例与跨场景重放 / Replay
→ 稳定规则压缩为 Skill
```

### 4. 全局轨迹优先

复杂任务开始前，先建立最小可执行全局轨迹：

```text
目标 → 约束 → 输入 → 工具 → 并行点 → 验证点 → 风险点 → 回退路径
```

但小任务不需要过度规划。

### 5. 价值感知压缩

压缩不是机械截断。保留优先级：

```text
用户目标 > 硬约束 > 文件路径/命令/API > 已验证结论 > 错误原因 > 中间过程
```

丢弃：重复解释、无效推理、过期截图、未验证噪声。

### 6. 子智能体结果必须回收

任何 subagent 结束后，主会话必须回收并索引：

```text
做了什么；
读了什么；
发现了什么；
修改了什么；
风险是什么；
可沉淀什么；
证据在哪里。
```

### 7. 进化必须受真实性边界约束

不得声称：

- 已调用 GPT / Claude / 外部多模型，除非有真实调用记录。
- 已长期后台持续学习，除非存在真实 cron / 服务 / 日志。
- 已修改 Hermes / claw 核心，除非实际改代码并验证。
- 已完成科研实验，除非真实执行并有数据。

## Workflow

### Step 1：真实性预检

开始前回答：

```text
目标是否清楚？
输入材料是否存在？
需要哪些技能？
是否适合委派 subagents？
有哪些风险边界？
完成标准是什么？
```

涉及文件时先 `search_files` / `read_file`。涉及当前事实、系统状态、时间、计算、git、进程时必须工具验证。

### Step 2：材料分簇

按主题把材料分成 2-4 组，适合并行处理：

```text
A. 检索 / 上下文学习 / 记忆
B. token / 上下文 / 轨迹压缩
C. 智能体训练 / 科研引擎 / 原生进化
D. 风险边界 / 反幻觉 / 工具能力
```

每组只给必要文件路径和输出要求，避免子智能体读无关材料。

### Step 3：子智能体并行学习

给每个 subagent 明确输出格式：

```text
1. 可复用原则
2. 可执行流程
3. 可落地到 Hermes 技能的条款
4. 风险边界
5. 建议更新/新建技能名
6. 文件变更情况
```

禁止子智能体直接改核心文件，除非任务明确要求并已授权。

### Step 4：主会话融合

融合时按 6 类输出归纳：

```text
核心公式
触发条件
标准流程
工具/子智能体使用规则
验证清单
风险与禁止项
```

优先更新已有技能；只有明显跨域、复用价值高、已有技能不能承载时，才新建综合技能。

### Step 5：写入技能或规则

选择沉淀位置：

| 内容 | 写入位置 |
|---|---|
| 可复用流程 | SKILL.md |
| 工具调用纪律 | TOOLS.md |
| 行为/团队/审查规则 | AGENTS.md |
| 长期稳定事实 | MEMORY.md |
| 用户偏好 | USER.md |
| 一次性过程 | 工作区归档，不进记忆 |

闭环要求：新建综合技能后，必须继续检查并联动已加载或相关 umbrella skills，避免新技能孤岛化；必要时生成 workspace 索引报告，记录源材料、子智能体分工、融合公式、落地文件和触发方式。

重要规则改写前必须备份；不得污染根目录。

### Step 6：验证

最低验证：

```text
文件是否存在？
frontmatter 是否合法？
描述是否不超过限制？
是否能被 skill_view / search_files 定位？
是否有虚构能力表述？
是否和已有技能明显重复？
```

### Step 7：真实性交付

交付时标注：

```text
真实性状态：完整完成 / 部分完成 / 草稿 / 模拟 / 未验证
依据：工具输出 / 文件路径 / 子智能体结果 / 测试结果
未完成：如有必须列出
风险：能力边界和未验证点
```

## Reusable Modules

### Module A：SearchSkill 增强

```text
问题分类 → 选择检索技能 → 生成检索计划 → 多源验证 → 冲突标注 → 输出依据 → 失败归因 → 搜索技能沉淀
```

### Module B：Context Skill Distillation

```text
长文档 → 提炼核心原则 → 生成挑战问题 → 尝试应用 → 审查反例 → 压缩成 Skill 条款
```

### Module C：Memory Consolidation

```text
捕获经验 → 重要性评分 → 稳定性检查 → 写入 memory/user/skill → 定期合并过时项
```

### Module D：Token Context Hygiene

```text
局部读取 → 并行摘要 → 保留目标/约束/证据 → 压缩工具输出 → 淘汰噪声 → 可恢复摘要
```

### Module E：Subagent Result Recovery

```text
分派前给上下文 → 子任务独立执行 → 五段式总结 → 主会话验证关键副作用 → 融合入最终结论
```

### Module F：APEX Agent Training Loop

```text
真实任务 → 轨迹捕获 → 自动验证 → 成功样本入库 → 失败样本反例化 → 技能更新 → 下次复用
```

### Module G：Research Engine

```text
问题定义 → 文献/代码/数据获取 → 假设生成 → 证据分级 → 实验/分析计划 → 执行与验证 → 不确定性声明
```

### Module H：TianGong GPT-Led Four-Core Orchestration

来自 `超级进化11-天工技能.md` 的深度吸收。TianGong 不是单一提示词，而是 GPT 主脑统筹下的四核执行治理层：把复杂任务压成“认知、规划、执行、验证、沉淀、进化”的可回放闭环。

核心公式：

```text
ΔG = (C_total · Λ_gene · Ω_entropy · τ_traj) / (H_info · t)

C_total：任务复杂度与协同成本
Λ_gene：可复用技能/基因的有效增益
Ω_entropy：轨迹稳定性与噪声抑制能力
τ_traj：完整轨迹生成效率
H_info：信息噪声、冗余与不确定性负载
t：总耗时
```

执行目标：

```text
max π_skill E[R_exec(τ) + λ · K_cache(τ)]

R_exec：执行成功率、合规率、验证通过率
K_cache：可沉淀知识缓存
λ：复用权重
```

四核分工：

| 核心 | Hermes 可执行含义 | 产物 | 边界 |
|---|---|---|---|
| evolver | 缺陷扫描、失败归因、轨迹回收、基因沉淀、回测指标 | 缺陷表、基因条款、复发防线 | 不能声称后台持续自进化，除非有真实 cron/日志 |
| autoresearch | 检索、读取、交叉验证、知识蒸馏 | 来源清单、证据分级、冲突处理 | 摘要不能替代原文证据 |
| openhands | 文件、终端、浏览器、沙箱等实际工具执行 | 文件变更、命令输出、运行结果 | 无工具记录时只能说规划执行 |
| superpowers | 澄清、设计、拆解、测试/验证、审查、交付 | 计划、状态机、验收报告 | 不能用流程名冒充测试已完成 |

GPT 主导规则：

1. 量子路由用于展开候选通道和路径；当用户要求“以 GPT 为主”时，必须用 GPT 通道作为主裁判。
2. 若 `qr route` 自动选到低阶通道，但健康检查显示 GPT 可用，应显式调用 `qr tier B` 或等效方式确认 GPT 通道，再由 GPT 主脑融合。
3. GPT 主脑负责最终路径选择、冲突消解、真实性边界、补齐落地和交付状态判断。
4. 子智能体只提供拆解、执行、验证、反证材料；不能替代主脑最终裁决。

触发条件：

- 用户要求“天工技能”“超级技能矩阵”“认知-规划-执行-进化闭环”。
- 用户明确要求“深度学习”“吸收融合”“以 GPT 为主”“调用量子路由 LLM 组合”。
- 任务同时需要检索、规划、执行、验证和进化沉淀。
- 当前能力不足，需要寻找真实开源项目或官方文档学习后再转化为本地技能。

标准状态机：

```text
received → scoped → gated → routed → planned → assigned → executing → verifying → audited → completed
                         ↘ blocked / repairing / failed / aborted
```

不可跳过状态：

- `scoped`：明确目标、边界、产物、验收标准。
- `gated`：检查工具需求、副作用、权限、真实性来源。
- `routed`：执行量子路由；GPT 主导时确认 B 级 GPT 通道可用性。
- `planned`：主路径、备选路径、风险点、验证方法。
- `verifying`：文件、命令、检索、测试或数据库读回验证。
- `audited`：高风险、系统规则、法律结论、进化沉淀必须反证审查。

门禁：

```text
G0 入口门禁：目标、范围、副作用、工具需求、验收标准、不确定性。
G1 计划门禁：主路径、备选路径、验证方法、风险点、产物定义。
G2 执行门禁：依赖齐全、输入存在、操作安全、可回滚、证据卡准备。
G3 验证门禁：按任务类型执行测试/读回/检索/构建/状态检查。
G4 交付门禁：需求覆盖、证据闭环、文件变更透明、风险披露、完成态准确。
```

证据卡最低字段：

```yaml
evidence_card:
  task_goal: ""
  route_decision:
    qr_route: ""
    gpt_tier_check: ""
    selected_main_path: ""
    backup_path: ""
  four_core_roles:
    evolver: ""
    autoresearch: ""
    openhands: ""
    superpowers: ""
  inputs:
    files_read: []
    commands_run: []
    sources_checked: []
  actions_taken: []
  outputs:
    files_created: []
    files_modified: []
    findings: []
  verification:
    checks_performed: []
    pass: true
    failures: []
  reality_gate:
    code_or_config_entry: ""
    run_record: ""
    reproducible_io_sample: ""
    latest_verification_time: ""
  unresolved_risks: []
```

真实性四件套：

任何“已支持 / 已实现 / 可自动执行 / 已集成”表述，必须同时满足：

1. 有实际代码入口或配置绑定。
2. 有一次真实运行记录。
3. 有可复现的输入输出样例。
4. 有最近一次验证时间。

少一项时，只能写成“流程目标”“设计意图”“可执行方案”“待验证能力”，不能写成已实现事实。

最小交付物：

```text
四核分工表 + GPT/量子路由记录 + 状态机节点 + 证据来源 + 执行结果 + 验证状态 + 可复用沉淀位置 + 边界声明
```

### Module K：Tiny Trainer / Predictive Quality Baseline

本模块来自 2026-05-23 的训练闭环落地。由于当前环境没有现成 sklearn/torch/xgboost/lightgbm/catboost，本模块采用纯标准库实现一个可训练、可预测、可回读的轻量基线，不冒充深度学习或完整 RL 训练。

组件：

- `/Users/appleoppa/.hermes/scripts/hermes_tiny_trainer.py`
- `/Users/appleoppa/.hermes/scripts/hermes_tiny_predict.py`
- `/Users/appleoppa/.hermes/workspace/agentic_rl/model/tiny_quality_model.json`
- `/Users/appleoppa/.hermes/workspace/agentic_rl/model/tiny_quality_eval.json`
- `/Users/appleoppa/.hermes/workspace/agentic_rl/model/tiny_quality_predictions.json`
- `references/evolution-pipeline-entrypoint.md`

能力：

1. 从 scored trajectory JSONL 学习一个小型质量分类器。
2. 输出可读回的 JSON 权重文件。
3. 对同一批轨迹进行预测，返回 high_quality / reject / review。
4. 生成独立评估文件，严格报告 accuracy，而不把训练结果吹成模型已成熟。

验收标准：

- 必须有模型文件、评估文件和预测文件。
- 模型必须能被读回并二次预测。
- 如果 accuracy 很低，仍然算“已训练出基线”，但不算“训练完成可上线”。
- 不能因为没有 ML 库就声称“无法训练”；应当退化到可执行基线。

边界：

- 这不是完整神经网络训练。
- 这不是 RL policy optimization。
- 这不是 Hermes 核心接管模块。
- 这只是把“训练”从口号变成了一个可运行、可评估、可预测的小闭环。

### Module L：Native Integration Boundary

本模块来自 2026-05-23 的“接进正式入口”需求。它明确：哪些能力可以直接接入 Hermes，哪些必须继续留在 workspace / scripts / cron sidecar。

已允许的接入方式：

- no-agent cron 调用 digest / export / score / train / predict
- workspace 产物作为报告和候选集
- skill/memory 仅在人工确认或 background review 后写入

暂不允许的接入方式：

- 直接替换 Hermes 主链路推理引擎
- 自动写 config / env / credential
- 自动删除技能
- 自动把预测器结果当成系统主判断

验收标准：

- 入口接入必须有读回验证。
- 入口接入必须保留回滚路径。
- 入口接入必须保留 dry-run。
- 没有这些门禁前，不算“正式接入 Hermes 核心”。

### Module M：Evaluation Center / Open-Source Devour Sandbox

用户将“评估中心”定义为 Hermes 的轨迹评分、训练、预测和评估流水线。涉及超级进化12、核心改造、自动吞噬外部开源项目时，必须先做真实性审计，再按低风险分层推进：只读采集 → 能力抽取 → 沙箱机制复现 → 评估中心接入 → 低风险能力固化 → 最后才考虑核心主链路改造。

关键边界：

- “只读采集 3 个 GitHub 项目”不能说成“已自动吞噬全球前三项目”。
- “安全接口层/sidecar”不能说成“Hermes 原生核心主链路已改造”。
- “训练链路跑通”不能说成“模型效果可上线”。
- “沙箱机制复现”不能说成“完整复刻外部项目”。

参考：`references/2026-05-23-super-evolution-12-eval-center-devour.md`。

## Common Pitfalls

本模块来自 2026-05-23 的“评估中心”和“超级进化12继续落地”。用户已将“评估中心”定义为固定别名：指 Hermes 的轨迹评分、训练、预测和评估流水线。

安全桥接层：

- `/Users/appleoppa/.hermes/scripts/hermes_eval_center.py status`
- `/Users/appleoppa/.hermes/scripts/hermes_eval_center.py audit`
- `/Users/appleoppa/.hermes/scripts/hermes_eval_center.py run`

用途：统一读取评估中心状态、模型评估、预测记录、开源吞噬报告和 cron 接入状态。它是原生核心改造前的安全接口层，不等同于已经修改 Hermes 主链路源码。

开源吞噬只读采集层：

- `/Users/appleoppa/.hermes/scripts/hermes_open_source_devour_scout.py --query "agent framework" --top 3`

用途：通过 GitHub 公共接口只读采集项目元数据、README 和 license，生成候选能力信号。它不 clone 仓库、不复制源码、不自动修改 Hermes 核心。

阶段边界：

```text
只读采集 → 许可证/README 审计 → 架构拆解 → 沙箱复现 → 能力抽取 → 技能/基因候选 → 核心接口化
```

禁止夸大：

- sidecar / cron / script adapter 不等于 Hermes 核心源码改造完成。
- GitHub 搜索和 README/license 审计不等于“自动吞噬全球开源前三项目完成”。
- 模型有训练文件不等于模型足够强或可作为主裁判。

详细会话记录见 `references/2026-05-23-evaluation-center-and-devour-scout.md`。


2. **只做摘要不做技能。** 用户要求“学习融会贯通”时，最终产物应是流程、条款、技能或规则，而非普通读书笔记。
3. **技能碎片化。** 不要一次创建很多窄技能；优先创建/更新一个能承载多模块的综合技能。
4. **子智能体结果不验证。** 子智能体自述不是事实证明；有文件写入、外部副作用时必须主会话复核。
5. **压缩丢掉目标。** token 优化不能牺牲用户目标、硬约束、路径、证据和风险边界。
6. **过度规划小任务。** 简单任务直接工具执行；复杂任务才走全局轨迹。
7. **用进化替代授权。** 核心代码、凭证、外部 API、长期后台进程、批量删除等高风险动作必须单独授权。
8. **新技能孤岛化。** 创建 class-level 技能后如果不 patch 相关旧技能、不写 workspace 索引，下一次任务很难触发和回查；参见 `references/2026-05-22-super-evolution-closure-gaps.md`。
9. **TianGong 愿景事实化。** 第11份“天工技能”材料应吸收为四核编排矩阵，而不是宣称已集成 GitHub 项目、xv 平台、claw 底层或 C/Rust/Go 原生能力；细节见 `references/2026-05-22-tiangong-four-core-orchestration.md`。

## Verification Checklist

- [ ] 已确认输入材料真实存在。
- [ ] 已按主题分簇，必要时使用 subagents 并行学习。
- [ ] 已输出可复用原则、流程、条款、风险边界。
- [ ] 已优先检查现有技能，避免重复造技能。
- [ ] 如写入文件，已备份重要文件或使用 skill_manage。
- [ ] 新建综合技能后，已检查并联动相关旧技能，避免技能孤岛。
- [ ] 必要时已生成 workspace 索引报告，方便回查源材料、子智能体结论和落地文件。
- [ ] 已验证技能 frontmatter、文件存在和可读取性。
- [ ] 未虚构外部模型、API、后台进程、底层代码实现。
- [ ] 已标注真实性状态和未验证点。

## Source Materials

本技能由以下当前材料融合而来。当前核验目录为 `/Users/appleoppa/Desktop/进化文件/`，共 14 份 Markdown；旧 `/Users/appleoppa/Desktop/超级进化/` 只作为历史路径线索，不作为当前完整清单。

- `/Users/appleoppa/Desktop/进化文件/超级进化1-河图洛书llm路由.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化2-github仓库.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化2.5-大佬指导.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化3-深度自进化.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化4-上下文学习新框架.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化5-记忆系统.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化5.5-未测试.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化6-token问题根治.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化7-个人智能体生态训练.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化8-科研统一引擎.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化8.5-经验（6-9）.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化9-原生进化核心公式释义.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化10-超级路由.md`
- `/Users/appleoppa/Desktop/进化文件/超级进化11-天工技能.md`
- `/Users/appleoppa/Desktop/超级进化12-吞噬自进化.md`

## Absorption Status Map

| 材料 | 当前吸收位置 | 状态 |
|---|---|---|
| 1 河图洛书 LLM 路由 | `quantum-channel-router`、`manual-evolution-loop`、EVM/河图洛书基因 | 已吸收为路由与反证门禁；外部多模型调用必须有真实调用证据 |
| 2 GitHub 仓库 | `manual-evolution-loop` GitHub 工厂门、`evm-integration`、基因库 GitHub runs | 部分吸收；已吸收为外部学习/回流门禁，不等同全部 GitHub 资源自动接管 |
| 2.5 大佬指导 | 本技能 TianGong 四核、子智能体回收、真实性边界 | 已吸收为编排原则；“永远不自己做任何工作/持续后台接管核心”不采纳为硬规则 |
| 3 SearchSkill | `search-skillbank`、本技能 Module A | 已吸收 |
| 4 上下文学习 | 本技能 Context Skill Distillation、Challenger/Reasoner/Judge | 已吸收为技能萃取流程；未实现 Rust 原生训练引擎 |
| 5 记忆系统 | memory 纪律、SWRs 框架、长期记忆边界 | 已吸收 |
| 5.5 Full Tool-Call | 本技能全局轨迹、量子路由轨迹缓存 | 部分吸收；作为规划目标和缓存策略，不等同所有任务一次性完成 |
| 6 token 问题 | token hygiene、局部读取、图片帧控制原则 | 部分吸收；坐标/截图底层校正未核验为已实现 |
| 7 个人智能体训练 | APEX Agent Training Loop | 概念吸收；SFT/RL/沙箱训练基础设施未实装 |
| 8 科研统一引擎 | Research Engine、TianGong 四核 | 方法吸收；不能宣称已能自动发表科研成果 |
| 8.5 经验 | 子会话回收、技能审计、能力审计、skill-gene 闭环 | 部分吸收；其中部分“已补完”需以本地代码/日志为准 |
| 9 原生进化公式 | 轨迹缓存、失败轨迹沉淀、技能更新 | 已吸收为运行原则；未宣称 CLAW 底层已原生改造 |
| 10 超级路由 | `quantum-channel-router` Rust CLI `qr` | 已吸收并落地为工具；A 通道当前 not_supported 时会降级 |
| 11 天工技能 | 本技能 TianGong 四核编排 | 已吸收为四核治理模型；不虚构 GitHub/xv/Claw 底层集成 |
| 12 吞噬自进化 | 本技能 Module I：吞噬式自进化 / Agentic RL 认知闭环 | 已吸收为“外部高价值能力→拆解→复刻→验证→技能/代码/基因沉淀”的流程；不宣称已自动吃透全球开源前三项目或完成 Rust/C/Go 集成 |
