# Session note: visible checkpoint loops and repair-first gate failures

Use this reference when executing or maintaining manual开智/反思循环.

## Durable corrections

- State downgrade is not the goal. It is only the honest label for the current evidence grade.
- If a gate fails, the agent should not stop after saying “证据不足.” It must diagnose and repair if the fix is within the 75% self-approval boundary.
- Repair-first loop: fail gate → locate cause → assess authority/risk/reversibility → repair if >75% → rerun the same gate → continue.
- Completion claims must never be based only on files, scripts, scores, state fields, generated summaries, or local simulations.
- A proper report should separate current state from highest supportable conclusion, then list satisfied gates, missing gates, repair actions, rerun result, and next gate.

## Stop conditions

Stop and ask the user only when:

- repair score is ≤75%;
- action is irreversible or materially destructive;
- action is outside authorization;
- action risks leaking secrets;
- required external conditions are objectively unavailable;
- user explicitly told the agent to stop.

## Pitfall to avoid

Do not turn the evidence-grade system into a passive failure reporter. The user expects normal system operation to be protected: honest downgrade first, then active repair and rerun.
