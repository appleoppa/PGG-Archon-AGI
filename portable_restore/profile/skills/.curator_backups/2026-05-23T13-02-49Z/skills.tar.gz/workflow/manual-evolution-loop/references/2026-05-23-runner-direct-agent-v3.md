# v3 Direct-Agent Runner Notes

## Context

This note captures the runner repair pattern discovered while executing a single controlled 开智进化循环 trial.

## What changed

- Replaced `hermes -z` subprocess execution with direct `AIAgent.run_conversation(...)`.
- Used the Hermes repo virtualenv Python to import Hermes source cleanly.
- Kept the business gate outside stdout and exit code.
- Required three independent evidence channels:
  - `body.md` written by the agent
  - SQLite deltas for `evolution_cycles` and `evolution_genes`
  - SQLite insertion of `verification_log`

## Verification pattern

A round is only considered complete when all of the following are true:

- agent call returned successfully
- `body.md` exists and includes `cycle_id`, `gene_id`, `数据库验证`, and `验证`
- DB snapshot delta shows +1 `evolution_cycles`
- DB snapshot delta shows +1 `evolution_genes`
- DB snapshot delta shows +1 `verification_log`
- a second DB readback confirms the verification log row was actually committed

## Practical pitfalls

- Do not rely on `exit_code` or terminal output as completion proof.
- Do not let a missing body file pass just because the agent returned content in memory.
- Do not stop after writing cycle/gene rows; write and verify `verification_log` too.
- If the runner logs runtime metadata, make sure provider objects are serialized safely.
- If Hermes source is imported from an external checkout, use that checkout's own Python environment.

## Minimal call shape

```python
from run_agent import AIAgent

agent = AIAgent(
    model="claude-opus-4-7",
    provider="custom",
    api_key=...
    base_url=...
    enabled_toolsets=["terminal", "file", "search", "skills", "session_search"],
    disabled_toolsets=["cronjob", "messaging", "clarify"],
    skip_memory=True,
    load_soul_identity=True,
    platform="cron",
)
result = agent.run_conversation(prompt, task_id="round_01")
```

## When to use

Use this pattern for cron, batch, and runner-style 开智 tasks where the user-visible completion must be backed by database proof, not just process exit.