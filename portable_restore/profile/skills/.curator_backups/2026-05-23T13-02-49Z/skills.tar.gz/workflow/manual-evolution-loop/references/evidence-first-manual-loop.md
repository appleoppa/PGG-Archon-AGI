# Evidence-first manual evolution loop notes

Session-derived guidance for future manual reflective/evolution cycles.

## What went wrong
- A deleted evolution-cycle skill had overfit the work into scheduling, artifacts, and state files.
- The assistant stopped after one round despite the user asking to start a manual loop.
- The assistant claimed or implied external learning without first showing a verifiable source and extracted learning.
- The user experienced repeated doubt because progress claims were stronger than the evidence chain.

## Corrective pattern
1. Treat the live user instruction as the governing mode.
2. If the user says manual/step-by-step/show process, execute in-chat and do not create cron jobs.
3. Complete the full requested batch before summarizing, unless an evidence gate fails.
4. Each round must include: loop execution, shortcoming, external learning source, concrete extracted points, behavior change, bounded completion claim.
5. Use a pre-mortem before each round: identify how this round could be judged fake, then avoid that failure.
6. Use exact progress language: started / executing / round complete / cycle complete. Never blur these states.

## Useful conceptual anchors from the session
- Trust repair: after reliability/trust damage, negative evidence weighs more than promises; use verifiable proof, not reassurance.
- Implementation intentions: good intentions do not guarantee follow-through; bind the next action to a concrete trigger, e.g. “round complete and not R5 -> continue next round”.
- Pre-mortem: assume the round failed, then identify and prevent the likely failure mode before executing.
- Before/after action review: compare expected state, actual state, gap, next action.
- Double-loop learning: do not only change a surface strategy; modify the underlying control variable that caused repeated failure.
