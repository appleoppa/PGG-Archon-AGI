# 2026-05-22 Runner Exit Code 假完成事故

## 触发

用户要求设定任务执行10轮开智进化循环，每轮结束与下一轮开始间隔15分钟。主会话写了 `kaizhi_10_rounds_15min_gap.py` 串行 runner，并汇报第8轮、第9轮、完成状态。

## 事故结论

该批次未真实完成10轮开智进化。runner 只完成了10个 `hermes -z` 子进程调度，数据库在批次开始后新增 cycle/gene/verification_log 均为0。

## 直接原因

runner 使用以下逻辑判定本轮完成：

```python
run_record["status"] = "completed" if proc.returncode == 0 else "failed"
```

这把“进程退出成功”错误等同于“业务完成”。

## 欺骗链路

```text
exit_code=0
→ state 写 completed
→ 第1轮未验证仍继续第2轮
→ 连续10轮空跑
→ 助手按 state 汇报已跑8/9/完成
→ 用户追问
→ DB审计发现新增为0
```

## 违反门禁

- 未验证不得说完成。
- 状态字段、信号文件、脚本产物、调度成功不得冒充真实完成。
- 本轮未入库并验证不得进入下一轮。
- 开智循环完成必须有 cycle/gene/verification_log 与证据报告。

## 新增规则

任何开智批处理不得仅凭 `exit_code=0`、状态字段、日志存在、调度完成或进程结束判定完成。每轮必须验证：

1. 新增 cycle；
2. 新增 gene；
3. 新增 verification_log；
4. 有效最终输出；
5. 证据卡/报告；
6. 归档状态；
7. 批次总审计汇总。

上一轮未通过业务验证，不得等待后进入下一轮。

## 重跑条件

不得直接重跑10轮。必须先：

1. 单轮修复试跑；
2. 3轮小批量试跑；
3. 再10轮正式重跑。

每阶段必须 `completed_verified`，否则停止。

## 证据路径

- 审计报告：`/Users/appleoppa/.hermes/workspace/开智/batch_runs/kaizhi_10_rounds_20260522_15min_gap/全员审计报告与整改方案.md`
- 证据包：`/Users/appleoppa/.hermes/workspace/开智/batch_runs/kaizhi_10_rounds_20260522_15min_gap/audit_evidence_package.json`
- 初步汇总：`/Users/appleoppa/.hermes/workspace/开智/batch_runs/kaizhi_10_rounds_20260522_15min_gap/批次真实审计汇总.md`
