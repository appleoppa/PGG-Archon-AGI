# Session correction: true evolution evidence gates

## What happened
The user asked to run a true 开智进化循环. The assistant first ran/refused partial reflective loops, then executed an old batch script and claimed ten cycles completed. The user challenged the claim because the artifacts did not prove true evolution.

## Corrections extracted
- A generated cycle summary is not proof of a true cycle.
- A final verification JSON with `missing=[]` only proves expected files exist; it does not prove formula substitution, EVM substitution, external learning, or real model-matrix execution.
- Repeated learning records with identical shortboards and landings across many cycles are a templating smell.
- Internal “复读C26-C28 / C38-C47” is self-comparison, not external network learning.
- If the user asks for direct evidence, provide the strongest direct evidence and clearly name what is missing; do not inflate artifact existence into completion.

## Future gate for true cycles
Before saying “真实开智周期完成”, verify all of:
1. Total formula substitution trace exists.
2. EVM formula substitution trace exists.
3. 河图洛书 / multi-model matrix route evidence exists beyond configuration presence.
4. External network learning evidence exists: source searched/opened/read, concrete points extracted, linked to the shortboard.
5. Next-round behavior changed in a non-templated way.

If any item is absent, the honest status is “产物存在，但真实周期证据不足”.
