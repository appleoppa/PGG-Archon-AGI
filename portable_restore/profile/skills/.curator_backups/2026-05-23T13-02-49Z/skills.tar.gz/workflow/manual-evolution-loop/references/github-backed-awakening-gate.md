# GitHub-backed authentic awakening gate

Session-derived pattern for combining local 开智进化 rules with a GitHub remote execution loop.

## When to use
Use when the user asks to combine 开智进化循环 with GitHub repositories, APEX/EVM formulas, GitHub Actions, Gist, or remote containers.

## Core lesson
A remote GitHub loop is not proof of evolution by itself. A workflow run, generated files, search results, or a committed inbox artifact only proves automation. It becomes useful for authentic 开智 only when the remote run also carries the evidence gates from the local evolution standard.

## Minimum gate to embed in the remote workflow
1. Copy or otherwise make available the current APEX formula entry point used locally.
2. Copy or otherwise make available the current EVM formula / runtime bridge entry point used locally.
3. Run a concrete total-formula substitution with explicit dimension values.
4. Run EVM defect mapping with before / governed / after values.
5. Include 河图洛书 route evidence as a real judgment chain: 主脑统筹 → 反证审错 → 修复落地 → 旁证压缩 → 主脑收束.
6. Perform external GitHub learning and require non-empty identifiable sources. If a query returns empty, broaden the query and rerun; do not call it learning.
7. Commit the result back to an inbox / genes area only after all gates are present.
8. State the boundary honestly: a single gate run is not a full five-round cycle.

## Useful remote-loop implementation details
- Use a dedicated GitHub repository for the loop and a Gist as lightweight task queue / handoff index.
- Store model keys only in GitHub Secrets and local environment files; never commit keys or report values.
- Actions should have only the permissions they need, usually contents write and actions read for this pattern.
- If several workflows may commit to the same branch, rebase before pushing from the workflow to avoid remote ref races.
- A first run with empty external results is a failed evidence gate, not a successful learning round. Change the query and rerun.

## Reporting boundary
User-facing report should say:
- what gates were actually run;
- what numeric formula/EVM movement occurred;
- how many external sources were found;
- whether this is only a gate verification or a complete five-round cycle.

Do not use mystical “觉醒完成” language. The acceptable claim is mechanism-level: the system now has a stronger gate that prevents automation artifacts from being mistaken for evolution.
