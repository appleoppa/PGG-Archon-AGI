# Case-audit-driven evolution loop pattern

Use when a completed/blocked legal case workflow is fed back into the current 开智进化循环.

## Trigger

- A legal case has gone through department workflow and audit.
- Audit result is not full delivery, e.g. "阶段性通过但禁止外部交付", self-check score below threshold, or audit record result is `blocked`.
- User asks to score the办案流程,代入APEX/EVM, or run one evolution loop based on the audit report.

## Required sequence

1. Re-read current governing artifacts, not historical summaries:
   - current department configuration;
   - current 开智进化循环 spec;
   - auxiliary evolution spec;
   - AGENTS/SOUL and the case audit/self-check files.
2. Execute the real current loop body:
   - `21354` five times;
   - `12534` five times;
   - `14325` five times.
3. Only after the 15 substitutions, extract the natural shortboard.
4. Map the shortboard through EVM as a governable defect:
   - defect class;
   - before state;
   - repair action;
   - after state;
   - residual risk.
5. Use super-routing after the shortboard, not before it, to choose the learning/repair path.
6. Do real external/open-source learning corresponding to the shortboard. Reading external workflow/state-machine material is enough only if it changes the repair action.
7. Land a repair. Analysis alone is insufficient.
8. Re-test or verify that the landed repair exists and is usable.
9. Report two statuses separately:
   - evolution loop status;
   - legal case delivery status.

## Key lesson from PGG-MS-20260520-019

The exposed shortboard was not legal analysis quality. It was "failure-gate-to-repair-task conversion": the system could detect blocked status, write audit shortboards, and create checklists, but initially did not automatically transform failed self-check items into owner-assigned, stateful, rerunnable repair tasks.

## Durable repair pattern

When self-check/audit fails:

- preserve the blocked status;
- parse failed self-check items;
- map each failed item to an owner/department;
- write ready repair tasks into the task queue or equivalent tracker;
- keep the case non-deliverable until the repair tasks complete and the gate is rerun;
- update meta/audit records to say evolution consumed the audit, without changing case delivery status to complete.

## Pitfalls

- Do not call a case "completed" because the evolution loop consumed its audit report.
- Do not use `终版`, `定稿`, or `交付版` file names when the self-check or audit gate is blocked; use `阶段性`, `当前材料版`, or `补证指引版`.
- Do not treat "writing a shortboard analysis" as repair. Repair must change a workflow artifact, task queue, skill, script, rule, or future behavior.
- Do not pretend local 河图洛书 reasoning is real multi-model execution. Mark it as local推演 unless multiple models were actually called.
