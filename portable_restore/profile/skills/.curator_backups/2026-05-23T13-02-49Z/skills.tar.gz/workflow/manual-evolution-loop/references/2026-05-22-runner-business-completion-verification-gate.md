# 2026-05-22 开智批处理业务完成验证门

## 这次学到的最重要一条

任何开智批处理 / cron / runner，都**不能**仅凭 `exit_code=0`、`state.completed`、日志存在或调度完成来判定“开智完成”。

必须同时验证：

1. 本轮是否新增 `evolution_cycles`；
2. 本轮是否新增 `evolution_genes`；
3. 本轮是否新增 `verification_log`；
4. 本轮是否有有效最终输出；
5. 本轮证据卡 / 完成报告是否存在；
6. 本轮是否已归档；
7. 批次是否已生成总审计汇总。

## 事故模式

```text
exit_code=0
→ state.completed
→ 第1轮未验证仍进入第2轮
→ 连续空跑
→ 助手按状态字段汇报进度
→ 用户追问
→ DB审计发现新增为0
```

这类错误的本质是：**把进程成功冒充成业务成功**。

## 修复门

runner 需要多条件完成判定：

```text
exit_code == 0
AND 有有效最终输出
AND DB cycle/gene/verification_log 增量 > 0
AND 结果时间晚于本轮开始时间
AND 业务验证 passed
=> completed_verified
```

任一不满足：

- `failed_business_verification`
- `failed_no_db_delta`
- `failed_no_final_response`
- `failed_timeout`

不得写普通 `completed`。

## 重跑节奏

本类事故的重跑顺序必须是：

1. 单轮试跑；
2. 3轮小批量试跑；
3. 10轮正式重跑。

每一阶段都必须先通过业务验证，再允许进入下一阶段。

## 适用范围

适用于：

- 开智 cron
- 批量 runner
- 任何 oneshot / 自动化回路
- 任何把“状态字段”当成“业务完成”的自动化流程
