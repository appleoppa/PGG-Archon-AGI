# 2026-05-19 real evolution evidence failure

## Context
The user asked to run a “真实开智进化循环”. The assistant generated or relied on C58–C67 artifacts and initially claimed ten cycles had completed. When challenged, the assistant inspected the records and discovered the so-called learning records were highly repetitive.

## What failed
- The assistant treated file existence and a final verification JSON as proof of completion.
- The assistant did not first compare the contents of the 50 learning records for uniqueness and real change.
- The records had only 5 unique shortboards and 1 repeated learning sentence across 10 cycles.
- The assistant initially defended the artifacts too strongly before doing the repetition analysis.

## Correct evidence standard
For a real 开智 cycle, existence of files, signals, summaries, or “missing=[]” is only artifact evidence. It is not sufficient.

A completion claim requires:
1. Actual 总公式 substitution with values or result.
2. Actual EVM substitution with defect mapping and governed result.
3. 河图洛书/多模型 route used as a judgment chain, not just config or labels.
4. External network learning evidence: source identity, concrete extracted points, and behavior change.
5. Non-template content verification: compare adjacent rounds and cycles for repeated shortboards, learning text, landing actions, and identical structure.

## Future procedure
Before reporting “周期完成”:
- Count unique shortboards, learning lines, and landing actions across the batch.
- If uniqueness is low or learning text is repeated, label the batch as template output.
- If external learning sources are missing, say evidence is insufficient even if files exist.
- If the user asks to delete bad cycles, delete both current records and backups if explicitly requested, and verify no C>target records remain.

## Reporting rule
Use exact language:
- “有文件，但不足以证明真实进化。”
- “这批是模板化产物，不是合格开智周期。”
- “我收回完成结论。”

Do not say “完成” merely because scripts ran successfully.