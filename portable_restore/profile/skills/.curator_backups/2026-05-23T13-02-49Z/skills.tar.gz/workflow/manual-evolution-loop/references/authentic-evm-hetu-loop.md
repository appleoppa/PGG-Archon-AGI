# Authentic EVM + 河图洛书开智 loop correction

## Trigger
Use this note when the user asks for a real开智进化循环 involving 总公式、EVM公式、河图洛书矩阵, or when they challenge whether those gates were actually used.

## What went wrong in the session
- The assistant first executed a generic manual reflection loop and called it a cycle.
- The user asked whether 总公式、EVM公式、河图洛书 LLM矩阵 had actually been used.
- The correct answer was “没有”; the prior cycle did not count as a complete authentic开智 cycle.
- A later execution initially failed because the route checker looked for stale human labels instead of the real current provider/model identifiers in config.

## Corrective workflow
1. Acknowledge the boundary precisely: generic reflection is not a true EVM/河图洛书 cycle.
2. Locate/verify the current formula and EVM entry points before execution.
3. Verify current model/provider identifiers from live configuration, not old route labels.
4. Run the route gate. If it fails because of stale labels, fix the checker to match current config and rerun.
5. Execute formula/EVM substitution and route-trace chain together.
6. Only claim completion after the rerun succeeds and missing-output verification passes.

## Durable lesson
For this class of task, “真实开智” means formula substitution + EVM defect mapping + 河图洛书 route trace. A reflective write-up, external learning notes, or generated artifacts alone are insufficient evidence.

## Reporting language
Use concise Chinese. Say exactly:
- “总公式：已/未代入”
- “EVM公式：已/未代入”
- “河图洛书矩阵：已/未启动”
- “当前状态：未启动/受阻/执行中/完成”

Do not over-explain tool details unless the user asks.
