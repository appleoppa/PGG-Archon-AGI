# 2026-05-22 任务入口先决条件排序门

## 触发信号

执行一轮开智进化循环时，同时命中多条强制入口：

- `manual-evolution-loop` 要求先加载当前开智规范并按完整闭环执行。
- `quantum-channel-router` 要求任务开始前执行 `qr route`。
- 第21轮沉淀的任务入口迁移门要求识别最近沉淀能力是否应迁移。

本轮暴露的问题不是“没有规则”，而是多个强制入口并列时缺少可回放排序。

## 可复用规则

复杂任务开始前采用轻量排序门：

```text
识别任务类型与强制触发词
→ 加载匹配 skill / 规范
→ 执行已加载 skill 声明的任务前动作
→ 进入任务本体流程
→ 证据卡记录 entry_prerequisites
```

开智循环触发时的最小顺序：

```text
加载 manual-evolution-loop
→ 读取现行开智规范
→ 检查是否命中 quantum-channel-router
→ 命中则在公式审错前执行 qr route
→ 再进入公式审错与三顺序代入
```

## 证据卡字段

建议在过程证据中加入：

```json
{
  "entry_prerequisites": [
    "load manual-evolution-loop",
    "read current spec",
    "load quantum-channel-router if matched",
    "run qr route before formula audit if matched"
  ],
  "unexecuted_prerequisites": [],
  "boundary": "未命中的前置动作不强行执行；不可用时写明原因"
}
```

## 反证边界

- 不要全量扫描所有 skill，避免入口膨胀。
- 不要把所有任务都强制量子路由；只处理已命中或已加载 skill 声明的前置动作。
- 不要扩展成复杂状态机；规则级排序门和证据字段即可。
- 未完成前置动作时，不得标注“完整完成”。

## 验收指标

- 任务执行前能看到任务类型、命中 skill/规范、前置动作顺序。
- 开智循环中，公式审错前能看到规范读取和已命中的路由动作。
- 证据卡包含 `entry_prerequisites`。
- 任一强制入口未完成时，交付状态降级为部分完成或未验证。
