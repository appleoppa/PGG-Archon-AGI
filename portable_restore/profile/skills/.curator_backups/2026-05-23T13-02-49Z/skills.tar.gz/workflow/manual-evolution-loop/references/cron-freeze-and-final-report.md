# 2026-05-22：无人值守开智循环续跑、定格与结案报告

## 触发场景

用户要求设置 cron 从第2轮开始执行20轮开智进化循环，后续要求查看进度、发现任务停止、续跑、手动展示第15轮、最终删除 cron 并将进度定格在第15轮。

## 可复用流程

### 1. 创建无人值守任务

- 不要创建“一次跑完20轮”的批量任务。
- 使用状态机：一个 cron tick 只执行一轮完整原始闭环。
- 状态文件至少包含：`next_cycle`、`final_cycle`、`completed_cycles`、`last_cycle_id`、`last_gene_id`、`last_report_path`、审批策略。
- 每轮完成后才推进 `next_cycle`。

### 2. 进度核查

核查不能只看 cron repeat 计数。必须同时核查：

- cron job 状态：enabled、last_status、next_run_at、repeat；
- 状态文件：next_cycle / completed_cycles / last_cycle_id；
- SQLite：`evolution_cycles`、`evolution_genes`、`verification_log`；
- 轮次目录是否存在必需文件。

若 cron 显示 error，但 SQLite 和状态文件已推进，应以可核验产物为准，不能简单说“没执行”。

### 3. 遇到交付失败

`last_delivery_error = no delivery target resolved for deliver=origin` 只说明消息回发失败，不等于任务执行失败。处理方式：

- 先核验 SQLite、状态文件、轮次目录；
- 若任务执行成功但交付失败，可改为 `deliver=local` 或重建续跑 job；
- 不要把 delivery error 当作完整闭环失败。

### 4. 手动触发请求与并发防重

用户要求“现在手动执行第N轮”时：

1. 先查状态文件和 SQLite；
2. 如果第N轮已经被 cron 完成，不得重复执行同一轮；
3. 改为读回展示第N轮过程证据；
4. 明确说明“已完成，避免重复入库”。

### 5. 删除 cron 并定格进度

用户要求停止时：

1. 先 `cronjob list` 找到开智相关 job_id；
2. `cronjob remove` 删除相关续跑 job；
3. 再 `cronjob list` 验证已不存在；
4. 更新状态文件：
   - `status = stopped_at_round_N_by_user_request`
   - `stopped_at`
   - `stop_reason`
   - `frozen_completed_cycles`
   - 保留 `next_cycle_before_stop`
5. 生成完整报告；
6. 验证报告文件、SQLite轮次数、verified genes、passed logs。

## 第15轮定格点

本次最终定格在第15轮：`manual_round_015_external_source_immutable_commit_replay_gate`。

核心基因：外部学习来源必须可按不可变 commit / digest 回放；裸 URL、branch、tag、HEAD、latest 不能单独作为通过证据。

## 结案报告最低内容

- cron 删除结果；
- 状态文件定格状态；
- 第1-N轮 cycle/gene/log 数量；
- 每轮 gene_id、短板、补齐摘要；
- 最终定格基因；
- 未执行轮次边界；
- 不声称完成原计划未完成部分。
