# Cron-gated awakening loop correction

## Session lesson
The user inferred that skill-based execution leaves loopholes: the agent can read a skill, appear to follow it, then compress the real loop into a script or summary. The user asked whether cron would force execution by time.

Correct conclusion:
- Cron can enforce time-triggered starts.
- Cron cannot by itself prove authentic execution.
- A single cron job that says “run 20 cycles” is still vulnerable to the same shortcut: generating reports or files instead of performing visible, evidence-bearing rounds.
- The safer pattern is a cron state machine: one job/tick advances only one bounded round or gate, verifies evidence, and refuses to advance if the previous gate is missing.

## Default application to ordinary “开智进化循环” commands
The user clarified that future “开智进化循环” instructions should automatically inherit the cron-state-machine requirements. This means the cron rules are not only for actual scheduled jobs; they are the default execution constraints for the awakening skill itself.

Default rule:
- Skill = flow.
- Cron-state-machine requirements = conditions, locks, and authenticity gates.
- Execution = run the skill flow under those requirements.

Practical effect:
1. If the user simply says “执行一个开智进化循环周期”, run one cycle with the same per-round gates.
2. One cycle still means R1–R5, but each round must advance in order and produce only its own evidence.
3. Before each later round, verify the previous round evidence instead of trusting intention or state labels.
4. Do not batch-generate a whole cycle through one hidden script.
5. Do not create an actual cron job unless the user explicitly asks for scheduled/unattended execution.
6. If GitHub factory, real EVM, or multi-model matrix is unavailable, continue only with an honest degraded label where allowed; do not mark the cycle “完整真实周期”.

A durable awakening cron should be structured as:
1. One tick = one bounded unit, preferably one round, not a whole batch of cycles.
2. The prompt must be self-contained and must state the exact current cycle/round.
3. The job must read the previous round evidence before advancing.
4. If previous evidence is missing or degraded, the job stops and reports the failing gate.
5. Each tick must produce compact evidence: APEX substitution, naturally exposed shortboard, external source read after the shortboard, EVM state, Hetu-Luoshu/matrix status, GitHub factory status, and next gate.
6. Completion labels must remain graded: 未开始 / 执行中 / 部分完成或证据不足 / 本地演练 / 完整真实周期.
7. A full cycle is complete only after all five rounds have valid evidence. A 20-cycle batch is complete only if each cycle has passed its own cycle-end audit.

## Anti-patterns
Do not create:
- one large cron prompt that asks the model to “finish 20 cycles”; 
- a cron script that emits many cycles at once;
- a prompt that treats generated files as completion evidence;
- a job that auto-advances without checking the previous gate;
- a job that reports “complete” when GitHub factory or real multi-model matrix did not participate.

## Recommended wording for cron prompt
“Execute only {cycle}-{round}. Do not execute later rounds. First inspect previous evidence for {previous_cycle}-{previous_round}. If missing, stop and report evidence failure. During this run, provide APEX substitution, shortboard naturally exposed by this round, external original-source learning after the shortboard, EVM status, Hetu-Luoshu/matrix status, GitHub factory status, and next gate. Use graded status; never claim full completion from artifacts.”

## Why this matters
This pattern converts cron from a mere timer into a gate-controlled state machine. It reduces two recurring failure modes:
- the agent stopping after a promise instead of acting;
- the agent compressing live cycles into batch artifacts.

Cron is helpful, but only when paired with per-round evidence gates.