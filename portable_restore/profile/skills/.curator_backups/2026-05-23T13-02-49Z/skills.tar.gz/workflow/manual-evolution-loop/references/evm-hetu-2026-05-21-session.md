# EVM v1.2 + 河图洛书路由 2026-05-21 Session 覆写

> 覆写时间: 2026-05-21 14:00
> 原因: 之前摘要记录gpt-5.5 API key已配置，但实查发现当前环境4个API key全部为空。

## 1. EVM v1.2 Bug修复 (状态: 已完成)

| # | Bug | 影响 | 修复 |
|---|-----|------|------|
| 1 | 八卦多乘 | v1.1代码乘8因子而非7古法 | 移除Bagua乘法 |
| 2 | 缺陷率简单平均 | 短板影响被稀释 | `avg×0.5 + 0.15×max^1.5` |
| 3 | 古法cap@1.0 | 无法强化 | 软上限2.0 |

## 2. 5yuantoken API 编码问题 (状态: 已修复)

**问题**: `resp.json()` 导致UTF-8内容乱码

**修复**:
```python
# 错误（乱码）:
data = resp.json()

# 正确:
data = json.loads(resp.content)
content = data['choices'][0]['message']['content']
```

## 3. 河图洛书路由 API Key 状态 (当前实查)

| 角色 | 模型 | 环境变量 | 当前值 |
|------|------|---------|--------|
| 中宫主脑 | gpt-5.5 | GPT55_5YUANTOKEN_API_KEY | 🔴 空 |
| 反证审错 | deepseek-v4-flash | DEEPSEEK_V4_FLASH_API_KEY | 🔴 空 |
| 修复执行 | MiniMax-M2.7-highspeed | MINIMAX_M27_HIGHSPEED_API_KEY | 🔴 空 |
| 旁证压缩 | glm-4.5-air | GLM45_AIR_API_KEY | 🔴 空 |

**关键发现**: `config.yaml` providers中定义了key_env名称，但当前执行环境中这4个变量全部为空。

## 4. 本轮执行结果 (实查)

```
步骤1 EVM自检: ✅ EVM=0.7691
步骤2-4 序列代入: ✅ ΔMem=0.25, ΔErr=0.15 → EVM=0.7419
步骤5 古法赋能: ✅ 黄帝内经+道德经 → 因子1.1234 → EVM=0.8334
步骤6-8 GitHub工厂: ✅ 读取3个inbox文件
步骤6-8 河图洛书五段链: 🔴 全部4个模型报"未配置API key"
步骤9 补齐+回测: ✅ EVM→0.8511
```

## 5. 待确认问题

API Key由谁管理?
- Hermes统一注入 → 检查gateway/profile机制
- 手动export → 在shell配置中设置
- 5yuantoken特殊header → 已知问题，尚无完整解决方案
