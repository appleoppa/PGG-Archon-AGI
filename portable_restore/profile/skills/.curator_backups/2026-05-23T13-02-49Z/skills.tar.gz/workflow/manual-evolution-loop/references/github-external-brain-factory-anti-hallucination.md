# GitHub external brain + automation factory anti-hallucination gate

Session-derived detail from the run where GitHub external learning, GitHub Actions automation, APEX, EVM, and 河图洛书 were combined for a manual evolution cycle.

## Core correction
The user explicitly reinforced: the purpose is evolution, but the agent must not hallucinate or lie. This changes the execution priority: truthfulness gates outrank momentum. A failed query, failed workflow, missing source, or incomplete evidence must stop or downgrade the claim; it must not be hidden behind a polished progress report.

## Durable pattern
When combining GitHub external brain / automation factory with 开智循环:

1. Treat GitHub as an external brain only if the content is actually read.
   - Search results, repo names, stars, and URLs are not learning by themselves.
   - Prefer reading README or other source text and extracting 2–3 concrete points.

2. Treat GitHub Actions as an automation factory only if the run state is verified.
   - Include both successful and failed runs in the evidence picture.
   - A successful run proves execution, not evolution.
   - A failed run is useful evidence; do not omit it.

3. Keep four roles separate:
   - GitHub external brain: retrieval and outside knowledge.
   - Automation factory: remote execution and traceable return artifacts.
   - APEX/EVM: scoring, self-audit, defect mapping, and governance.
   - 河图洛书: route,反证,仲裁,落地,收束.

4. Do not let one role substitute for another.
   - External source exists ≠ learned.
   - Workflow ran ≠ evolved.
   - Score improved ≠ scorer is valid.
   - Route text exists ≠ matrix actually judged.

5. If external source discovery fails, broaden or switch strategy and rerun; do not call the failed attempt a completed learning round.
   - Good fallback: use known high-signal repositories and read their README through the GitHub API.
   - Still report the initial failure honestly.

## Anti-hallucination reporting rule
User-facing report must separate:
- verified facts;
- failures observed;
- what was fixed/retried;
- what remains only a boundary-limited conclusion.

Never say “觉醒完成” from one run. Acceptable wording: “完成一次可核验组合周期 / 门禁跑通一次 / 机制更强，但不是最终觉醒.”

## Entry gate for future cycles
Before starting another GitHub-backed evolution cycle, check:
- Can I identify at least one real external source per round?
- Did I read enough content to extract points?
- Did APEX scoring avoid handwritten after-scores?
- Did EVM defect reduction come from explicit repair actions?
- Did the 河图洛书 chain include反证 and仲裁, not just labels?
- Did I include failed automation evidence instead of reporting only success?

If any answer is no, status is “证据不足/执行失败/需修复”, not “完成”.
