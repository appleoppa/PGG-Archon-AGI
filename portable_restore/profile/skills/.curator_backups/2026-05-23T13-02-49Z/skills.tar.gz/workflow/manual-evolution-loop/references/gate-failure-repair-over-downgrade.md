# Gate failure repair over downgrade

Session lesson: the user corrected the prior framing that evidence downgrading is enough. For awakening/evolution loops, downgrading is only the honesty layer. The operational goal is to keep the system running by repairing recoverable failures under the 75% self-approval rule.

## Durable rule
When an awakening/evolution gate fails:
1. Mark the evidence level honestly, but do not stop there.
2. Diagnose the concrete failing condition.
3. Decide whether the fix is in-scope, reversible, low risk, and likely to restore the authorized loop.
4. If the self-approval score is above 75%, apply the fix without asking the user.
5. Rerun the same gate immediately.
6. Continue only after verification passes.
7. Stop for user approval only when the fix is destructive, irreversible, out of scope, credential-leaking, security-weakening, or genuinely impossible with available context.

## Pitfall to avoid
Do not convert “no false completion claims” into passive blocking. The user does not want an agent that accurately reports failure and then stops. The desired behavior is: truthful status → repair → rerun → restored operation.

## Acceptable wording
- “当前证据等级已降级，但我会先修复可修门禁并重跑。”
- “这不算完整完成；我已定位到可修原因，按75%规则修复后重新验证。”

## Unacceptable wording
- “证据不足，所以结束。”
- “门禁失败，等待用户决定是否修复。”
- “降级后汇报完成。”

## Relation to evidence-first rule
Evidence-first prevents false completion claims. Repair-first prevents evidence-first from becoming a dead stop. Both must run together.