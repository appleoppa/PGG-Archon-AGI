# Global Standard Replacement

## Use When

The user asks to:
- remove old rules globally
- stop carrying historical workflow baggage forward
- replace a canonical spec across workspace + skills + cron prompts
- keep user assets and evolution genes, while clearing old entrypoints

## Principle

Do not patch one line and assume the system is clean. Treat this as a canonical-entry migration.

## Procedure

1. Locate all active entrypoints:
   - workspace canonical spec
   - active skill entrypoints
   - cron prompts/jobs
   - root rule files and mirrors
2. Identify the white list:
   - user profile / memory
   - evolution gene database
   - verified current canonical spec
3. Back up before change:
   - copy current active files to `workspace/存档/<topic>/<timestamp>/`
4. Choose one canonical source:
   - one active spec wins
   - mirrored copies are either synced byte-for-byte or clearly marked archive-only
5. Overwrite active entrypoints:
   - update the canonical spec
   - shrink skills so they point to the canonical spec instead of re-embedding old history
   - update cron prompts or job text that still references old flow
6. Clean old active references:
   - search only active paths
   - anything matching old loop/round/state-machine language must be removed or demoted to archive
7. Verify:
   - active paths return zero old-prompt hits
   - canonical spec copies match byte-for-byte
   - backups exist
   - user assets and gene DB remain intact

## Pitfalls

- A Documents copy and a workspace copy can drift by one byte and still create a dual-source bug.
- Historical cron output is evidence, not an execution source.
- A skill with many historical references can re-import old rules even if the main spec is fixed.
- Archive-only references are fine; active references are the problem.

## Verification Checklist

- [ ] One active canonical spec only
- [ ] Mirrored copies match or are clearly archive-only
- [ ] Skills point to the canonical spec, not a historical bundle
- [ ] Cron prompts/job text use current gate wording
- [ ] Active search hits for old loop language are zero
- [ ] User profile, memory, and gene DB preserved
