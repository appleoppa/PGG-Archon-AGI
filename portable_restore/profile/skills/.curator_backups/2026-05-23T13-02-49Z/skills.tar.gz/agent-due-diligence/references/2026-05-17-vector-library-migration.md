# 2026-05-17 向量库迁移与虚假判例 — 典型尽职调查失败案例

## 背景
从 OpenClaw/AutoClaw 向 Hermes 迁移过程中，向量库被错误放置并产生一系列后续错误。

## 时间线

| 时间 | 事件 | 错误类型 |
|------|------|---------|
| 迁移阶段 | 向量库数据复制到 `migration/向量库/` 而非 `workspace/向量库/` | 路径规划错误 |
| C19R4自动进化 | 扫描 AGENTS.md 知识路由路径，发现 `workspace/向量库/` 不存在，创建空骨架（`.gitkeep`+空chroma_data/） | 未全量扫描workspace |
| C19R4 | 标记"P4已修复" | 虚假确认 |
| 用户质询 | "你扫描全部文件了吗" | 触发修复 |
| 最终 | false判例数据(5465条HuggingFace分类数据集)被清理，骨架被替换 | 数据质量未审核 |

## 根源

1. **仅检查配置声明的路径** — AGENTS.md里知识路由指向 `workspace/向量库/`，该路径不存在就认为"没有向量库"
2. **没检查`workspace/智库/`下的实际目录** — 真正的判例索引在 `workspace/智库/判例库/vector_index/`
3. **没检查`migration/`备份目录** — 真正的chroma数据在 `migration/向量库/`
4. **迁移后未验证目标路径内容** — 仅确认文件数，未确认文件在正确位置
5. **判例数据内容未审核** — 看到数量（5465条）和文件存在就报告"判例库正常"，不检查数据来源和质量

## 交付渠道规则（用户明确）

- 电脑端指令 → 电脑端交付（对话内）
- 飞书手机端指令 → 飞书手机端交付
- 特别要求可覆盖上述规则

## 最终清理（2026-05-17）

被删除的资源：
- `workspace/智库/判例库/`（3.9MB，5465条虚假判例索引+架构文档）
- `workspace/向量库/`（212MB，chroma向量库+knowledge.db+脚本）
- `migration/向量库/`（222MB，备份）
- `scripts/seed_cases.py`, `reimport_cases.py`, `case_library.py`
- `tools/chroma_start.sh`

引用的清理：
- `skills/知识路由/SKILL.md` × 13份（workspace+12部门分支） — 移除判例库检索、向量库初始化
- `standards/core/07_vector_memory_standard.md` — 移除向量库路径引用
- `workflows/` 2份 — 标记已删除
- `scripts/` 3份 — 标记DEPRECATED
- `MEMORY.md` — 清除路径引用
- `auto-evolution-state.json` — 标注P4修复为错误
- `GENE-R65-C19R4.json` — 标注该轮修复已撤回
