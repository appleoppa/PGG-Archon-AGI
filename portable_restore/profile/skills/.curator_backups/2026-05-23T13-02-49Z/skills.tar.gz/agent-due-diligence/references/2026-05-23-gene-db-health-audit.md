# 进化基因库健康审计方法（2026-05-23实证）

## 场景

开智进化循环第21轮中，发现进化基因库（apex_evolution_genes.sqlite3）中38/42条基因（90%）状态为"active"但从未闭环验证。只有4条被标记为"verified"。

## 审计SQL

```sql
-- 1. 状态分布
SELECT status, COUNT(*) FROM evolution_genes GROUP BY status;

-- 2. 最新基因（验证最近10条入库记录）
SELECT gene_id, defect_name, status, severity_rank 
FROM evolution_genes 
ORDER BY gene_id DESC LIMIT 10;

-- 3. 早期未闭环基因（验证round 1-15的基因从未验证）
SELECT gene_id, defect_name, status, severity_rank 
FROM evolution_genes 
WHERE status='active' AND gene_id LIKE 'G%'
ORDER BY RANDOM() LIMIT 3;

-- 4. 周期状态概览
SELECT cycle_id, theme, status, evidence_grade 
FROM evolution_cycles 
ORDER BY cycle_id DESC LIMIT 5;

-- 5. 验证日志总览
SELECT result, COUNT(*) FROM verification_log GROUP BY result;
```

## 抽样回测方法

对于active状态的基因，不要全量验证（token成本高）。采用**分批抽样回测**：

每轮开智循环入库后，执行：
1. 计算当前active基因总数（例如N=38）
2. 按10%比例抽样（ceil(N*0.1)≈4条）
3. 对每条抽样基因：
   - 读取repair_mechanism字段（修复机制描述）
   - 检查对应skill/配置/规则是否已落实该修复
   - 若已解决→标记status=verified，记录verification_log
   - 若未解决→标记status=reopen，本轮优先处理
4. 连续5轮后覆盖率可达~50%

## 生命周期

```
active（新入库）→ 抽样回测命中 
  ├→ verified（fix已落地验证通过）
  └→ reopen（fix未落地，需要本轮优先补齐）
```

## 2026-05-23实证结果

- 总基因数：42
- active：38
- verified：4（GENE-0011~0014）
- 回测抽样：3条（G02/G05/G10）
- 全部3条仍为active，未闭环
- 验证结论：基因库缺少回测闭环机制，修复记录存在但落地未验证
- 入库基因：GENE-0017（gene_backtest_closed_loop）

## 边界

- 抽样回测不能替代全量验证
- severity_rank=1的基因（如格式/风格类）不一定需要回测
- 每次回测后应记录到verification_log以便追踪
