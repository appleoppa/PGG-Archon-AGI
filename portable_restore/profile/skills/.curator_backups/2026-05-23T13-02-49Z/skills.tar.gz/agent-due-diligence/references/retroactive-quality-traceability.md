# Retroactive Quality Traceability

## Problem

When a quality gate is established (e.g., "all entries must have `absorbed_knowledge >= 200 chars`"), pre-existing entries written before the gate was created may violate the new threshold.

**Bad options:**
- Leave them unaddressed → quality gate is bypassed, system accumulates low-quality entries
- Retire them all → lose high-value entries that were just concisely written
- Upgrade them all → excessive effort for low-severity entries

## Solution: Severity-Based Classification

Use the entry's severity rank to decide disposition:

| Severity | Absorbed Knowledge | Action |
|----------|-------------------|--------|
| ≥3 (high/critical) | < threshold | **UPGRADE** — expand content to meet the new threshold. These are genuinely important entries that warrant the effort. |
| ≤2 (low/medium) | < threshold | **RETIRE** — mark as retired with reason. Low-priority entries that don't justify expansion effort. |
| Any | ≥ threshold (met) | **KEEP** — no action needed. |

**One-time pass.** This traceability runs exactly once, after which ALL entries either meet the gate or are retired. Future entries must meet the gate at creation time.

## Verifiable Metrics

Track before/after:

```
Before: Active=N1 (X%), Retired=N2, Verified=N3, Total=N_total
After:  Active=N4 (Y%), Retired=N5, Verified=N6, Total=N_total (+new gene)
```

Goal: Active ratio (active/total) should drop significantly (ideally below 50% if many low-quality entries existed).

## Known Patterns

1. **Quality gate without retroactive clause** (anti-pattern): Gate established but pre-existing entries untouched → gate is symbolic. The system claims quality control while carrying hundreds of sub-standard entries.

2. **Blind mass retirement** (anti-pattern): All pre-existing entries retired regardless of severity → loss of high-severity knowledge that would be valuable if expanded.

3. **Severity-based triage** (verified pattern from round 3): Use the severity_rank that already exists on each entry. Severity was assigned at creation time for a reason — it captures the entry's importance independent of its content length.

## Empirical Results (2026-05-23 Round 3)

| Metric | Before | After |
|--------|--------|-------|
| Total genes | 45 | 46 (+1 new) |
| Active | 16 (35.6%) | 9 (19.6%) |
| Retired | 19 | 27 (+8) |
| Low-quality active (<200 chars) | 13 | 0 |

- 5 genes upgraded (severity ≥3): absorbed_knowledge expanded from 49-147 chars to 200+ chars
- 8 genes retired (severity ≤2): closed with `retired_via_quality_traceability_round3`
- 1 new gene added for this round's traceability mechanism itself
- Active ratio dropped from 35.6% to 19.6%

## When This Applies

- Any database or registry where a content quality gate is introduced after entries already exist
- Knowledge bases, gene registries, skill libraries, or case databases
- Not for ephemeral/cache data or data that will be replaced wholesale

## Boundary

- Severity-based triage assumes severity was assigned correctly at creation. If severity is inflated, low-importance entries may be incorrectly upgraded instead of retired.
- "One-time pass" works if new entries are strictly gated going forward. If the gate is later revised upward, a new traceability round is needed.
- The pattern only addresses content growth metrics. It doesn't verify that the expanded content is _correct_ — upgrades expand quantity but don't automatically improve quality.
