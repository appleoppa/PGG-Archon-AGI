# 进化基因质量审计SQL参考

> 供 agent-due-diligence 在开智进化循环中使用
> 创建：2026-05-23 R5 | 参考：skill-evolver GT验证理念 + CoEvoSkills共进化验证

## 使用场景

在开智进化循环的"基因质量检查"阶段执行。以下SQL查询每轮执行一次，结果写入state文件的evidence_summary。

## 审计查询集

### Q1: 质量底线检查 — 低质量活跃基因

```sql
SELECT COUNT(*) FROM evolution_genes 
WHERE status='active' AND (LENGTH(absorbed_knowledge) < 200 OR LENGTH(repair_mechanism) < 100);
```

- 若 > 0 → 标记为低质量基因，需立即升级或retire
- 目标：0

### Q2: MAPE速率平衡

```sql
SELECT status, COUNT(*) FROM evolution_genes GROUP BY status ORDER BY COUNT(*) DESC;
```

- 计算 active% = active / total
- 若 active% > 80% → 需回测≥3个最旧active基因
- 或者 active/(active+verified) > 3:1 → 解析率不足

### Q3: 底部3 ak_len 边际检查

```sql
SELECT gene_id, LENGTH(absorbed_knowledge) FROM evolution_genes 
WHERE status='active' ORDER BY LENGTH(absorbed_knowledge) ASC LIMIT 3;
```

- 若全部 < 300 → 触发迭代升级协议（每次升级3个，再查，最多3轮）
- 若 ≥2/3 < 300 → 建议预防性升级
- 连续2+轮同一底部3且LENGTH值差异≤5字符 → 平衡态，跳过

### Q4: 底部3 rm_len 边际检查（独立于Q3）

```sql
SELECT gene_id, LENGTH(repair_mechanism) FROM evolution_genes 
WHERE status='active' ORDER BY LENGTH(repair_mechanism) ASC LIMIT 3;
```

- 若全部 < 300 → 触发迭代升级协议
- 若 ≥2/3 < 300 → 建议预防性升级
- 与Q3并行执行，互不依赖

### Q5: 平衡态检测

```sql
SELECT gene_id, LENGTH(absorbed_knowledge) as ak_len, LENGTH(repair_mechanism) as rm_len 
FROM evolution_genes WHERE status='active' ORDER BY ak_len ASC LIMIT 3;
```

- 将结果与前轮state文件中的底部3数据比对
- 连续2+轮无变化 → `quality_equilibrium: true`

### Q6: 审计顺序验证

```sql
-- 在基因INSERT后执行，验证新基因内容
SELECT gene_id, LENGTH(absorbed_knowledge), LENGTH(repair_mechanism) 
FROM evolution_genes ORDER BY rowid DESC LIMIT 5;
```

- 必须在 INSERT → SELECT+LENGTH验证 → Q3/Q4/Q5 的顺序执行
- 不可在INSERT前使用旧快照运行Q3/Q4

## Python执行模板

```python
import sqlite3

db_path = "/Users/appleoppa/.hermes/workspace/开智/02-进化基因/apex_evolution_genes.sqlite3"
conn = sqlite3.connect(db_path)
c = conn.cursor()

# 批量执行审计查询
queries = {
    "low_quality_active": "SELECT COUNT(*) FROM evolution_genes WHERE status='active' AND (LENGTH(absorbed_knowledge) < 200 OR LENGTH(repair_mechanism) < 100)",
    "status_counts": "SELECT status, COUNT(*) FROM evolution_genes GROUP BY status ORDER BY COUNT(*) DESC",
    "bottom_3_ak": "SELECT gene_id, LENGTH(absorbed_knowledge) FROM evolution_genes WHERE status='active' ORDER BY LENGTH(absorbed_knowledge) ASC LIMIT 3",
    "bottom_3_rm": "SELECT gene_id, LENGTH(repair_mechanism) FROM evolution_genes WHERE status='active' ORDER BY LENGTH(repair_mechanism) ASC LIMIT 3",
}

results = {}
for name, sql in queries.items():
    c.execute(sql)
    results[name] = c.fetchall()
    print(f"{name}: {results[name]}")

conn.close()
```

## 安全注意事项

- 使用参数化查询避免SQL注入（Python sqlite3的`?`占位符）
- 不使用终端`sqlite3`的shell转义（中文引号可能静默失败）
- 每次UPDATE后必须用SELECT+LENGTH读回验证，不信任rowcount
- 注意审计顺序：INSERT → SELECT验证 → Q3/Q4/Q5检查
