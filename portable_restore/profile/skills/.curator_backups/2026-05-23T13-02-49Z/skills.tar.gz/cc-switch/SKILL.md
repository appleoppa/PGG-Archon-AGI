---
name: cc-switch
description: 管理Claude Code/Codex等AI Agent供应商
trigger: User mentions CC Switch, asks to install it, configure a provider, add an API endpoint, or switch between providers.
---

# CC Switch — Install & Configure

## Finding the Latest Release

GitHub Releases pages often have massive release notes that bury the download assets. **Do not rely on browser navigation alone** — use the GitHub API for a clean listing:

```
curl -s https://api.github.com/repos/farion1231/cc-switch/releases/latest
```

Parse with Python/jq to extract `tag_name` and all `assets[].browser_download_url`. This is much faster and more reliable than scrolling through the release notes page.

Alternatively, the browser tool works but expect to scroll past hundreds of lines of release notes before reaching the "Assets" section.

## macOS Installation

1. Download the `.dmg` from the latest release assets
2. Mount and copy:
```
hdiutil attach /path/to/CC-Switch-*.dmg -nobrowse
cp -R "/Volumes/CC Switch/CC Switch.app" /Applications/
hdiutil detach "/Volumes/CC Switch"
```
3. Launch from Applications or via `open /Applications/CC\ Switch.app`

## Provider Configuration via SQLite

CC Switch stores all data in **`~/.cc-switch/cc-switch.db`** (SQLite).

### Database Schema (relevant tables)

**`providers`** table:
- `id` TEXT — UUID
- `app_type` TEXT — one of: `claude`, `codex`, `gemini`, `hermes`, `openclaw`
- `name` TEXT — display name
- `settings_config` TEXT — JSON blob with provider-specific config
- `is_current` BOOLEAN — 1 = active provider
- `sort_index` INTEGER — ordering
- `category` TEXT — e.g. "custom", "official"

**`provider_endpoints`** table:
- `provider_id` TEXT — FK to providers.id
- `app_type` TEXT — FK to providers.app_type
- `url` TEXT — endpoint URL

### settings_config JSON Format by app_type

**hermes** (OpenAI-compatible):
```json
{
  "name": "provider-name",
  "base_url": "https://example.com/v1",
  "api_key": "sk-...",
  "model": "gpt-5.5",
  "models": [{"context_length": 1000000, "id": "gpt-5.5"}],
  "_cc_source": "custom_providers"
}
```

**claude** (Anthropic-compatible):
```json
{
  "env": {
    "ANTHROPIC_BASE_URL": "https://api.example.com/anthropic",
    "ANTHROPIC_AUTH_TOKEN": "sk-...",
    "ANTHROPIC_MODEL": "model-name",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "model-name",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "model-name",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "model-name"
  },
  "config": {}
}
```

**codex** (OpenAI):
```json
{
  "auth": {"OPENAI_API_KEY": "sk-..."},
  "config": "model_provider = \"provider_name\"\nmodel = \"gpt-5-codex\"\n..."
}
```

**openclaw** (OpenAI-compatible):
```json
{
  "baseUrl": "https://api.example.com/v1",
  "apiKey": "sk-...",
  "api": "openai-completions",
  "models": [{"id": "model-name", "name": "Display Name", "contextWindow": 200000, "cost": {"input": 0.001, "output": 0.004}}]
}
```

### Adding a New Provider

1. Generate a UUID for the provider ID: `uuidgen`
2. Insert into `providers` table with the correct `settings_config` JSON
3. Insert into `provider_endpoints` if needed
4. Optionally set `is_current = 1` to activate immediately

Example (Hermes, OpenAI-compatible):
```sql
INSERT INTO providers (id, app_type, name, settings_config, category, sort_index, is_current)
VALUES (
  '$(uuidgen)',
  'hermes',
  'My Provider',
  '{"name":"My Provider","base_url":"https://api.example.com/v1","api_key":"sk-...","model":"gpt-5.5","models":[{"context_length":1000000,"id":"gpt-5.5"}],"_cc_source":"custom_providers"}',
  'custom',
  99,
  0
);
```

## Pitfalls

- The CC Switch app must NOT be running when you write to the SQLite database directly — it holds a lock and writes may be overwritten on next save.
- Always set `is_current` on only one provider per app_type at a time. The app enforces this but direct SQL writes do not.
- The `api_key` field in `settings_config` is shown as `***` in CC Switch's UI after save; direct DB insertion requires the real value.
- After adding a provider via DB, restart the target CLI tool (Claude Code, Codex, etc.) for changes to take effect. Claude Code is the only exception that supports hot-switching.
- The `_cc_source` field with value `custom_providers` marks providers as user-created in the UI.

## Verification

After adding a provider, open CC Switch and verify:
- The provider appears in the provider list for the correct app
- Click "Enable" to activate it
- Run the CLI tool and confirm it connects

To test an OpenAI-compatible endpoint directly:
```bash
curl -s https://api.example.com/v1/models \
  -H "Authorization: Bearer sk-..." \
  | python3 -m json.tool
```
