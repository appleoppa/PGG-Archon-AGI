# CC Switch SQLite Schema

Location: `~/.cc-switch/cc-switch.db`

## providers

| Column | Type | Notes |
|--------|------|-------|
| id | TEXT (PK) | UUID |
| app_type | TEXT (PK) | claude, codex, gemini, hermes, openclaw |
| name | TEXT | Display name |
| settings_config | TEXT | JSON blob |
| website_url | TEXT | Optional |
| category | TEXT | e.g. custom, official |
| created_at | INTEGER | Unix timestamp |
| sort_index | INTEGER | Display ordering |
| notes | TEXT | Optional |
| icon | TEXT | Optional |
| icon_color | TEXT | Optional |
| meta | TEXT | Default '{}' |
| is_current | BOOLEAN | 1 = active |
| in_failover_queue | BOOLEAN | 0 |
| cost_multiplier | TEXT | Default '1.0' |
| limit_daily_usd | TEXT | Optional |
| limit_monthly_usd | TEXT | Optional |
| provider_type | TEXT | Optional |

## provider_endpoints

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER (PK, AI) | |
| provider_id | TEXT | FK -> providers.id |
| app_type | TEXT | FK -> providers.app_type |
| url | TEXT | The API endpoint URL |
| added_at | INTEGER | Unix timestamp |

## proxy_config

Per-app_type proxy settings with auto-failover, circuit breaker, health monitoring config.

## proxy_request_logs

Usage/cost tracking per request.

## usage_daily_rollups

Daily aggregated usage statistics per (date, app_type, provider_id, model).

## model_pricing

Custom per-model pricing overrides.

## providers (indexed)

Index on (app_type, in_failover_queue, sort_index) for failover ordering.

Full schema can be dump via: `sqlite3 ~/.cc-switch/cc-switch.db ".schema"`
