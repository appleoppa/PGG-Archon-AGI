---
name: user-reporting-preferences
description: 中文简洁汇报：表格/字段、精确状态、证据等级
---

# User Reporting Preferences — Compact

## Use When

Progress, status, audit, summary, delivery, or user-facing result.

## Style

- Chinese, concise, direct.
- Default: table with status/data/evidence/next step.
- Feishu/mobile: if tables render poorly, use compact field blocks.
- For Feishu legibility, avoid dense stacked tables. Prefer visual hierarchy: one conclusion block, 2-4 short sections, bullets, clear spacing, and only one small table when it genuinely improves comparison.
- When the user criticizes formatting as messy or unattractive, immediately switch to a cleaner layered layout and preserve the lesson here rather than only in memory.
- Avoid command/path/tool details unless needed as evidence.
- When sharing local file references in Feishu, do not assume angle-bracket Markdown paths or `path:line` text will be clickable. Prefer a clean labeled link only when the platform supports it; otherwise provide the exact plain path in a separate `文件路径:` field and avoid claiming “可点击” unless verified.
- If the user reports a link/button/message is not clickable, first switch to a simpler Feishu-safe format: title line + plain path/code block + short instruction, rather than resending the same Markdown shape.
- Treat token/context as a user-facing resource: if the user asks about progress/status/context, return only key fields unless detail is requested.
- Never imply completion from artifacts, status files, or partial runs alone.

## Five Principles

| Principle | Output |
|---|---|
| 目标明确化 | 目标、验收、边界 |
| 流程标准化 | 步骤、状态、门禁 |
| 责任具体化 | 谁/哪个部门/哪个系统负责 |
| 信息透明化 | 数据、证据等级、状态字段 |
| 资源配置最优化 | 资源、理由、替代方案 |

## Default Skeleton

| 项目 | 内容 |
|---|---|
| 当前状态 | 未开始/执行中/部分完成/完成/证据不足 |
| 核心数据 | 数量、比例、前后变化 |
| 证据等级 | 已核验/部分核验/未核验 |
| 风险边界 | 不能夸大的部分 |
| 下一步 | 如果未完成，下一步动作 |

## Quality Gate

- Is there exact status?
- Are data and evidence visible?
- Is the completion boundary clear?
- Is the answer shorter than the work deserves but not empty?
